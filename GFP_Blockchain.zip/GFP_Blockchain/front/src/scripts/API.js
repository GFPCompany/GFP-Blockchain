import axios from "axios";
import {md5,sha256} from 'crypto-hash';

const API_LINK = "http://192.168.1.64:8920"

const delay_t = ms => new Promise(
    resolve => setTimeout(resolve, ms)
);

async function GetData(url,data,method="post"){
    if(method === "post"){
        const response = await axios.post(url,data,{ContentType:"text/plain"})
        return response.data
    }
    else{
        const response = await axios.get(url,data)
        return response.data
    }

}
async function Auth(data,URL){
    const response = await axios.post(URL,data)
    return response.data
}
async function GetUserInfo(token){
    return await GetData(API_LINK+"/api/user/info",{"token":token})
}
async function GetBlocks(){
    return await GetData(API_LINK+"/blockchain/get_blocks",{},"get")
}
async function GetUsersCount(){
    return await GetData(API_LINK+"/api/users/count",{},"get")
}
async function RegistrationUser(data){
    return await GetData(API_LINK+"/api/user/register",data)
}
async function AuthUser(data){
    const response = await GetData(API_LINK+"/api/user/auth",data)
    return response
}
async function GetKeys(data){
    return await GetData(API_LINK+"/api/user/keys",data)
}
async function CreateKeys(data){
    return await GetData(API_LINK+"/api/user/keys/create",data)
}
async function DeleteKeys(data){
    return await GetData(API_LINK+"/api/user/keys/delete",data)
}
async function GetIncomeTransactions(data){
    return await GetData(API_LINK+"/api/payment/transactions/income",data)
}
async function CreateTransaction(data){
    return await GetData(API_LINK+"/api/payment/transaction/create",data)
}
async function GetExpensesTransactions(data){
    return await GetData(API_LINK+"/api/payment/transactions/expenses",data)
}
async function ImportKey(data){
    return await GetData(API_LINK+"/api/user/keys/import",data)
}
async function GetBlock(data){
    return await GetData(API_LINK+"/api/blockchain/block",data)
}
export {delay_t,
    Auth,
    GetUserInfo,
    GetData,
    GetBlocks,
    GetUsersCount,
    RegistrationUser,
    AuthUser,
    GetKeys,
    CreateKeys,
    DeleteKeys,
    GetIncomeTransactions,
    CreateTransaction,
    GetExpensesTransactions,
    ImportKey,
    GetBlock
}