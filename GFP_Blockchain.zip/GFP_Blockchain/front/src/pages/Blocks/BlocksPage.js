import React, {useState} from 'react';
import axios from 'axios';
import './style_0.css'
import Header from "../../components/Header";
import withRouter from "../../components/navigate_router/navigate_router";
import {Link, Navigate} from "react-router-dom";
import {GetBlocks} from "../../scripts/API";

var GET_BLOCKS_LINK = 'http://192.168.1.64:8920/blockchain/get_blocks'

class BlocksPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            blocks_hash: [],

            token: (this.props.location.state) ? ((this.props.location.state.token) ? (this.props.location.state.token): '') : '',

            isAuthorized: (this.props.location.state) ? (!!(this.props.location.state.token)) : false,
        };

        this.LoadBlocks = this.LoadBlocks.bind(this)
    }
    async LoadBlocks(){
        var response = await GetBlocks()
        response = response.blocks
        this.setState({blocks_hash: response})
        setInterval(async () => {

            if(window.location.pathname === '/blocks'){
                var req = await GetBlocks()
                response = req.blocks
                this.setState({blocks_hash: response})
            }

        }, 1000);
    }

    render() {
        return (
            <div className="page" onLoad={this.LoadBlocks}>
                <Header isAuthorized={this.state.isAuthorized} token={this.state.token}/>
                <div className={"content"}>
                    <div className="blocks-ares">
                        {
                            this.state.blocks_hash.map((b,index) => {
                                return (
                                    <Link to={"/blocks/"+b} key={index} state={{token: this.state.token, isAuthorized: this.state.isAuthorized}}>
                                        <div className={"block-card"} key={b}>
                                            <div className="top">
                                                <span>Block #{index}</span>
                                            </div>
                                            <div className="bottom">
                                                <span>{b}</span>
                                            </div>
                                        </div>
                                    </Link>
                                )
                            })
                        }
                    </div>

                </div>
            </div>
        );
    }
}
export default withRouter(BlocksPage)