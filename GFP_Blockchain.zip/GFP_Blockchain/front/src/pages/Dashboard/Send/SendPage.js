import React from 'react';
import withRouter from "../../../components/navigate_router/navigate_router";
import Header from "../../../components/Header";
import "./SendPageStyle_0.css"
import {
    CreateTransaction,
    delay_t,
    GetExpensesTransactions,
    GetIncomeTransactions,
    GetKeys
} from "../../../scripts/API";
import ToastList from "../../../components/Toast/ToastList";
import {pem as Base58} from "node-forge";
function hex2a(hex) {
    var str = '';
    for (var i = 0; i < hex.length; i += 2) {
        var v = parseInt(hex.substr(i, 2), 16);
        if (v) str += String.fromCharCode(v);
    }
    return str;
}
function hexToBytes(hex) {
    let bytes = [];
    for (let c = 0; c < hex.length; c += 2)
        bytes.push(parseInt(hex.substr(c, 2), 16));
    return bytes;
}
class SendPage extends React.Component {
    positions = {
        "top-right": "Top-right",
        "top-left": "Top-left",
        "bottom-right": "Bottom-right",
        "bottom-left": "Bottom-left",
    };

    showToast = (message, type) => {
        const toast = {
            id: Date.now(),
            message,
            type,
        };

        this.setState({toasts: [...this.state.toasts, toast]});

        if (this.state.autoClose) {
            setTimeout(function (){
                delay_t(this.state.autoCloseDuration);
                this.removeToast(toast.id)
            }.bind(this), this.state.autoCloseDuration);
        }
    };

    removeToast = (id) => {
        this.setState({toasts: this.state.toasts.filter((toast) => toast.id !== id)});
    };

    removeAllToasts = () => {
        this.setState({toasts: []});
    };
    constructor(props) {
        super(props);
        var token = '';
        if (!this.props.location.state) {
            token = this.pickToken();
        }
        else {
            token = this.props.location.state.token
        }
        this.state = {
            token: token,

            isAuthorized: (token) ? (!!(token)) : false,
            api_auth_response: {},
            toasts: [],
            autoClose: true,
            autoCloseDuration: 2000,
            position: "bottom-right",
            public_keys: [],

            account_division: '',
            account_division_name: '',
            account_division_balance: 0,

            transactions: [],

            isModalOpen: true,
        }
        this.HandleSendClick = this.HandleSendClick.bind(this)
        this.LoadKeys = this.LoadKeys.bind(this)
        this.OpenModal = this.OpenModal.bind(this)
    }
    componentDidMount() {
        if(this.state.token===''){
            this.pickToken()
        }
        this.LoadKeys()
    }
    async LoadKeys() {
        var income = await GetIncomeTransactions({token: this.state.token})
        var expenses = await GetExpensesTransactions({token: this.state.token})
        const response = await GetKeys({
            token: this.state.token
        })
        for(var i = 0; i < response.data.public_keys.length; i++){
            var k=response.data.public_keys[i]

            k.balance = 0
            var my_utxo_txid = []
            for(var j=0;j<income.data.transactions.length;j++){
                for(var l=0;l<income.data.transactions[j].outputs.length;l++){
                    if(k.key === income.data.transactions[j].outputs[l].lock){
                        k.balance += income.data.transactions[j].outputs[l].amount
                        break
                    }
                }
            }
            for(var j=0;j<expenses.data.transactions.length;j++){
                for(var l=0;l<expenses.data.transactions[j].inputs.length;l++){
                    for(var n=0;n<my_utxo_txid.length;n++){
                        if(expenses.data.transactions[j].outputs[l].lock !== response.data.public_keys[i]){
                            k.balance -= expenses.data.transactions[j].outputs[l].amount
                            break
                        }
                        if (expenses.data.transactions[j].outputs[l].lock === response.data.public_keys[i]){
                            k.balance += expenses.data.transactions[j].outputs[l].amount
                            break
                        }
                    }
                }
            }
            console.log(k.balance)
        }
        console.log(response.data.public_keys)
        this.setState({
            public_keys: response.data.public_keys,
            account_division: (response.data.public_keys.length!==0) ? (response.data.public_keys[0].key) : (''),
            account_division_name: (response.data.public_keys.length!==0) ? (response.data.public_keys[0].name) : (''),
            account_division_balance: (response.data.public_keys.length!==0) ? (response.data.public_keys[0].balance) : (0),
        })

    }
    SetAccountDivision(value) {
        this.setState({
            account_division_key: value,
        })
        for(let i=0;i<this.state.public_keys.length;i++){
            if(this.state.public_keys[i].key === value){
                this.setState({
                    account_division: this.state.public_keys[i].key,
                    account_division_balance: this.state.public_keys[i].balance
                })
                console.log(this.state.account_division_balance)
                break
            }
        }
        this.CloseModal()
    }

    async HandleSendClick() {
        const address = document.getElementById("create-transaction-address-input").value
        const amount = document.getElementById("create-transaction-amount-input").value
        const fee = document.getElementById("create-transaction-fee-input").value

        if (!address || !amount || !fee){
            this.showToast("Please enter all fields", "failure")
            return
        }
        if (fee>amount){
            this.showToast("Invalid fee", "failure")
            return
        }
        if(!address.startsWith("6U")){
            this.showToast("Invalid address.\nAddress must start with '6U'", "failure")
            return
        }
        if(!amount.match(/^\d+$/)){
            this.showToast("Invalid amount", "failure")
            return
        }
        if(!fee.match(/^\d+$/)){
            this.showToast("Invalid fee", "failure")
            return
        }
        if(Number(amount)+Number(fee) > this.state.account_division_balance){
            this.showToast("Insufficient balance", "failure")
            return
        }
        this.showToast("Sending...", "success")

        var data = {
            token: this.state.token,
            data:{
                address: address,
                amount: amount,
                fee: fee,
                account_division: this.state.account_division
            }
        }

        const response = await CreateTransaction(data);
        this.showToast("Sent Transaction, server response: "+JSON.stringify(response), "success")

    }

    CloseModal() {
        this.setState({isModalOpen: false})
    }

    OpenModal() {
        this.setState({isModalOpen: true})
    }
    pickToken(){
        if(document.cookie!=null && document.cookie!==''){
            console.log("cookie")
            var cookie_data = JSON.parse(document.cookie)
            if(cookie_data.token){
                return cookie_data.token
            }
        }
        return ''
    }

    render() {
        console.log(this.props.searchParams.has("key"))
        if(this.state.isAuthorized) {
            //set cookie token
            if (document.cookie === '' || document.cookie === undefined) {
                document.cookie = "{}"
            }
            if (!JSON.parse(document.cookie).token && this.state.token !== '') {
                var cookie_data = JSON.parse(document.cookie)
                cookie_data["token"] = this.state.token
                document.cookie = JSON.stringify(cookie_data)
            }
        }
        return (
            <div className="page">
                <Header token={this.state.token}/>

                <div className="content">
                    <div className="page-header">
                        <span>Send</span>
                    </div>
                    <div className="send-card">

                        <div className="card-header">
                            <span>Create Transaction</span>
                        </div>
                        <div className="card-body">

                            <div className="input-group">
                                <span className="input-group-addon">Address</span>
                                <input type="text"
                                       id="create-transaction-address-input"
                                       placeholder="recipient"
                                       value={(this.props.searchParams.has("key")) ? (this.props.searchParams.get("key")) : (undefined)}
                                />
                                <span className="paste">Paste</span>
                            </div>
                            <div className="input-group">
                                <span className="input-group-addon">Amount</span>
                                <input type="text" id="create-transaction-amount-input" placeholder="amount"/>
                            </div>

                            <div className="input-group">
                                <span className="input-group-addon">Fee</span>
                                <input type="text" id="create-transaction-fee-input" placeholder="fee" value={0}  onChange={()=>{}}/>
                            </div>
                            <div className="input-group">
                                <div>
                                    <span className="input-group-addon">From</span>
                                </div>
                                <div>
                                    <div className="address-current" onClick={() => this.OpenModal()}>
                                        <span>{this.state.account_division_name}</span>
                                        <span> </span>
                                        <span>{this.state.account_division_balance}</span>
                                        <span> </span>
                                        <span>GFP</span>
                                    </div>
                                </div>

                            </div>

                            <div className="button-group">
                                <div className="button" onClick={() => this.HandleSendClick()}>
                                    <span>Send</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <ToastList data={this.state.toasts} position="bottom-right" removeToast={this.removeToast}/>
            <Modal title={"Select Account Division"} isOpen={this.state.isModalOpen} onClose={() => this.CloseModal()} children={(
                <div className="modal-body">
                    <div className="addresses">
                        {
                            (this.state.public_keys.length>0) ? (
                                this.state.public_keys.map((key) => (
                                    <div className="container" key={key.key} onClick={() => this.SetAccountDivision(key.key)}>
                                        <div className="address" >{key.name}</div>
                                        <div className="balance">
                                            <span>{key.balance}</span>
                                            <span> </span>
                                            <span>GFP</span>
                                        </div>
                                    </div>

                                ))
                            ) : (<div>You haven't any key</div>)
                        }
                    </div>
                </div>
            )}/>
            </div>
        )
    }
}
const Modal = ({ isOpen, onClose, children ,title}) => {
    if (!isOpen) return null;

    return (
        <div
            style={{
                position: "fixed",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                background: "rgba(0, 0, 0, 0.5)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
            }}
        >
            <div
                style={{
                    display: "inline-block",
                    background: "white",
                    margin: "auto",
                    padding: "2%",
                    border: "2px solid #000",
                    borderRadius: "10px",
                    boxShadow: "2px solid black",
                }}
                className={"modal-container"}
            >
                <div className="modal-header">
                    <span className={"modal-title"}>{title}</span>
                    <div className={"close-modal"} onClick={onClose}>
                        <span>Close</span>
                    </div>
                </div>
                {children}
            </div>
        </div>
    );
};
export default withRouter(SendPage)