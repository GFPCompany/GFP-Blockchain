import React from "react";
import Header from "../../../components/Header";
import withRouter from "../../../components/navigate_router/navigate_router";
import "./TransactionsPageStyle_0.css"
import {GetExpensesTransactions, GetIncomeTransactions} from "../../../scripts/API";

class TransactionsPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            token: (this.props.location) ? ((this.props.location.state.token) ? (this.props.location.state.token): '') : '',

            isAuthorized: (this.props.location) ? ((this.props.location.state.token) ? true: false) :false,
            transactions: [],
        }

        this.GetTransactions = this.GetTransactions.bind(this)
    }
    async GetTransactions(){
        this.setState({
            transactions: []
        })
        var response = await GetIncomeTransactions({token: this.state.token})
        var txs = []
        for (var i = 0; i < response.data.transactions.length; i++){
            response.data.transactions[i].type_name = "income"
            txs.push(response.data.transactions[i])
        }
        response = await GetExpensesTransactions({token: this.state.token})
        for (var i = 0; i < response.data.transactions.length; i++){
            response.data.transactions[i].type_name = "expenses"
            txs.push(response.data.transactions[i])
        }
        txs.concat(response.data.transactions)
        txs.sort((a, b) => b.timestamp - a.timestamp)
        this.setState({
            transactions: txs
        })
    }

    componentDidMount() {
        this.GetTransactions()
    }
    render() {
        console.log(this.state.transactions.length)
        return (
            <div className="page">
                <Header token={this.state.token}/>
                <div className="content">
                    <div className="page-header">
                        <span>Transactions</span>
                    </div>

                    <div className="transactions-list">
                        {
                            (this.state.transactions.length > 0) ?

                                (
                                    (this.state.transactions.map((transaction) => {
                                        return (<TransactionItem key={transaction.txid} transaction={transaction}/>)
                                    }))
                                )

                                :
                                (<div>No transactions</div>)
                        }
                    </div>
                </div>
            </div>
        );
    }
}
function TransactionItem(transaction) {
    transaction = transaction.transaction
    transaction.inputs_sum = 0
    transaction.outputs_sum = 0


    if(typeof transaction.tx_type === "string"){
        transaction.tx_type = Number("0x"+transaction.tx_type)
    }
    for(var i = 0; i < transaction.outputs.length; i++){

        transaction.outputs_sum += transaction.outputs[i].amount
    }
    for (var i = 0; i < transaction.inputs.length; i++){

        transaction.inputs_sum += transaction.inputs[i].amount
    }
    if(Number(transaction.tx_type) === 1 || transaction.tx_type==="0001"){

        transaction.inputs_sum = 0;
    }
    console.log(transaction)
    var date = new Date(transaction.timestamp*1000)
    var date_str = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+date.getDate() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();

    return(
    <div className="transaction-item">
        <div className="value">
            <span className="value-text txid">{transaction.txid}</span>
        </div>

        <div className="value">
            <span className="value-text">{date_str}</span>
        </div>
        <div className="value">
            <span className="value-text">{(transaction.tx_type === 0) ? "P2PKH" : (transaction.tx_type === 1) ? "Coinbase" : "Unknown"}</span>
        </div>
        <div className="value">
            <span className={(transaction.type_name === "income") ? ("value-text-incoming") : ("value-text-expenses")}>{(transaction.type_name === "income") ? "Income" : "Expenses"}</span>
        </div>

        <div className="value">
            <span className="value-text">{transaction.outputs_sum}</span>
            <span>&nbsp;</span>
            <span className="currency-text">GFP</span>
        </div>
    </div>)
}
export default withRouter(TransactionsPage);