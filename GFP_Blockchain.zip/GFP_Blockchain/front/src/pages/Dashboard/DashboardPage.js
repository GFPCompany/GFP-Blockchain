import React from 'react';
import Header from "../../components/Header";
import withRouter from "../../components/navigate_router/navigate_router";
import {Link, Navigate} from "react-router-dom";
import "./DashboardPageStyle_0.css"
import {GetBlocks, GetExpensesTransactions, GetIncomeTransactions, GetKeys} from "../../scripts/API";


class DashboardPage extends React.Component {

    constructor(props) {
        super(props);
        console.log("DASHBOARD PROPS: ",this.props)
        this.state = {
            token: (this.props.location.state.token) ? this.props.location.state.token: '',

            isAuthorized: !!(this.props.location.state.token),

            redirect: false,


        }
    }
    componentDidMount() {
        if(!this.state.isAuthorized) {
            this.setState({
                redirect: true
            })
        }
    }

    render() {
        if (this.state.redirect) {
            return (
                <Navigate to="/login" state={{token: ''}}/>
            );
        }
        return (
            <div className="page">
                <Header isAuthorized={true} token={this.state.token} />
                <div className="content">
                    <h1 className={"base-white-text"}>Dashboard</h1>
                    <div className="card-box">
                        <DashboardBalanceCard token={this.state.token}/>
                        <DashboardTransactionsCard token={this.state.token}/>
                        <DashboardReceiveCard token={this.state.token}/>


                    </div>
                </div>
            </div>
        )
    }
}
class DashboardBalanceCard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            token: this.props.token,
            totalBalance: 0,
            income: 0,
            expenses: 0
        }
        this.GetBalance = this.GetBalance.bind(this)
        this.GetBalanceManager = this.GetBalanceManager.bind(this)
    }
    async GetBalance(){
        var keys = await GetKeys({token: this.state.token})
        var publicKeys = []
        for (var i = 0; i < keys.data.public_keys.length; i++){
            publicKeys.push(keys.data.public_keys[i].key)
        }
        var balance = 0;
        var income_b = 0;
        var expenses_b = 0;
        var income = await GetIncomeTransactions({token: this.state.token})
        var expenses = await GetExpensesTransactions({token: this.state.token})

        for(var i = 0; i < income.data.transactions.length; i++){
            for( var j = 0; j < income.data.transactions[i].outputs.length; j++){
                for(var k = 0; k < publicKeys.length; k++){
                    if(income.data.transactions[i].outputs[j].lock === publicKeys[k]){
                        balance += income.data.transactions[i].outputs[j].amount
                        income_b += income.data.transactions[i].outputs[j].amount
                    }
                }
            }
        }

        for (var i = 0; i < expenses.data.transactions.length; i++) {
            for( var j = 0; j < expenses.data.transactions[i].outputs.length; j++){
                for(var k = 0; k < publicKeys.length; k++){
                    if(expenses.data.transactions[i].outputs[j].lock !== publicKeys[k]){
                        //balance -= expenses.data.transactions[i].outputs[j].amount
                        expenses_b += expenses.data.transactions[i].outputs[j].amount
                        break
                    }
                     if (expenses.data.transactions[i].outputs[j].lock === publicKeys[k]){
                        balance += expenses.data.transactions[i].outputs[j].amount
                        income_b += expenses.data.transactions[i].outputs[j].amount
                         break
                    }
                }
            }
        }

        return {"balance": balance, "income": income_b, "expenses": expenses_b}
    }
    async GetBalanceManager(){
        var data = await this.GetBalance();
        this.setState({
            totalBalance: data["balance"],
            income: data["income"],
            expenses: data["expenses"]
        })
        setInterval(async () => {
            if(window.location.pathname === '/dashboard' && window.location.active){
                data = await this.GetBalance();
                if(this.state.totalBalance !== data[0] || this.state.income !== data[1] || this.state.expenses !== data[2]){
                    this.setState({
                        totalBalance: data["balance"],
                        income: data["income"],
                        expenses: data["expenses"]
                    })
                }

            }

        }, 10000);
    }
    componentDidMount() {
        this.GetBalanceManager()
    }

    render() {
        return (
            <div className="balance-card card">
                <div className="top">
                    <div className="card-header">
                        Balance
                    </div>
                    <div className="val">
                        <span className="value">{this.state.totalBalance}</span>
                        <span> </span>
                        <span className="unit currency-text">GFP</span>
                    </div>
                </div>
                <div className="bottom">
                    <div className="left">
                        <div className="img-container">
                            <div className="img-container"></div>
                        </div>
                        <div className="text">
                            <span className="hint megium-white-text">Income</span>
                        </div>
                        <div className="val">
                            <span className="value unit-white-text">{this.state.income}</span>
                            <span> </span>
                            <span className="unit unit-white-text currency-text">GFP</span>
                        </div>
                    </div>
                    <div className="v-line"></div>
                    <div className="right">
                        <div className="img-container">
                            <div className="img-container">
                            </div>
                        </div>
                        <div className="text">
                            <span className="hint megium-white-text">Expenses</span>
                        </div>
                        <div className="val">
                            <span className="value unit-white-text">{this.state.expenses}</span>
                            <span> </span>
                            <span className="unit unit-white-text currency-text">GFP</span>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
class DashboardTransactionsCard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            token: this.props.token,
            transactions: [],
        }
        this.GetTransactions = this.GetTransactions.bind(this)
    }
    async GetTransactions(){
        this.setState({
            transactions: []
        })
        var response = await GetIncomeTransactions({token: this.state.token})
        var txs = []
        for (var i = 0; i < response.data.transactions.length; i++){
            response.data.transactions[i].type_name = "income"
            txs.push(response.data.transactions[i])
        }
        response = await GetExpensesTransactions({token: this.state.token})
        for (var i = 0; i < response.data.transactions.length; i++){
            response.data.transactions[i].type_name = "expenses"
            txs.push(response.data.transactions[i])
        }
        txs.concat(response.data.transactions)
        txs.sort((a, b) => b.timestamp - a.timestamp)
        txs = txs.slice(0, 5)
        this.setState({
            transactions: txs
        })
    }
    componentDidMount() {
        this.GetTransactions()
    }

    render() {
        return (
            <div className="transactions-card card">
                <div className="top">
                    <div className="card-header">
                        <span>Last 5 Transactions</span>
                    </div>
                    <div className="see-more">
                        <span className={"see-more"}><Link to={"/user/transactions"} state={{token: this.state.token}} className={"see-more"}>See more</Link></span>
                    </div>
                </div>
                <div className="bottom">
                    <div className="transactions-list">
                        {
                            (this.state.transactions.length > 0) ? (
                                this.state.transactions.map((transaction) => {
                                    if (transaction.type_name === "income") {
                                        return (
                                            <div className="transaction" key={transaction.txid}>
                                                <div className="type">
                                                    <div className="img-container-income"></div>
                                                </div>
                                                <div className="val">
                                                    <span className="value unit-white-text">{transaction.outputs[0].amount}</span>
                                                    <span>&nbsp;</span>
                                                    <span className="unit unit-white-text currency-text">GFP</span>
                                                </div>
                                                <div className="val">
                                                    <span>{(transaction.tx_type===1) ? "Coinbase" : "P2PKH"}</span>
                                                </div>
                                            </div>
                                        )
                                    }
                                    if (transaction.type_name === "expenses") {
                                        return (
                                            <div className="transaction" key={transaction.txid}>
                                                <div className="type">
                                                    <div className="img-container-expenses"></div>
                                                </div>
                                                <div className="val">
                                                    <span className="value unit-white-text">{transaction.outputs[0].amount}</span>
                                                    <span>&nbsp;</span>
                                                    <span className="unit unit-white-text currency-text">GFP</span>
                                                </div>
                                                <div className="val">
                                                    <span>{(transaction.tx_type===1) ? "Coinbase" : "P2PKH"}</span>
                                                </div>
                                            </div>
                                        )
                                    }
                                })
                            ) : (
                                <div className="no-transactions">
                                    <span>No transactions</span>
                                </div>
                            )
                        }
                    </div>
                </div>
            </div>
        )
    }
}
class DashboardReceiveCard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            token: this.props.token,
            publicKeys: [],
            modalIsOpen:false,
            modalPublicKeyQR: null,
            current_key:null
        }
        this.LoadKeys = this.LoadKeys.bind(this)
        this.HandlePublicKeyClick = this.HandlePublicKeyClick.bind(this)
    }
    async LoadKeys(){
        const response = await GetKeys({token: this.state.token})
        this.setState({
            publicKeys: response.data.public_keys
        })
    }
    componentDidMount() {
        this.LoadKeys()
    }
    HandlePublicKeyClick = (qr,key) => {
        this.setState({
            modalIsOpen: true,
            modalPublicKeyQR: qr,
            current_key: key
        })
    }

    render() {
        return (
            <div className="receive-card card">

                {(this.state.modalIsOpen) ? (
                    <div
                        onClick={() => this.setState({modalIsOpen: false})}
                        style={{
                            position: "fixed",
                            top: 0,
                            left: 0,
                            width: "100%",
                            height: "100%",
                            background: "rgba(0, 0, 0, 0.8)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                        }}
                    >
                        <div onClick={()=>{}}
                            style={{
                                background: "white",
                                margin: "auto",
                                padding: "2%",
                                border: "2px solid #000",
                                borderRadius: "10px",
                                boxShadow: "2px solid black",
                            }}
                        >
                            <div className="modal-body">
                                <div className="modal-header">
                                    <p style={{
                                        fontSize: "20px",
                                        fontFamily: "Mona-Sans",
                                        width: "200px",
                                    }}>Show this QR code
                                        to receive GFP</p>
                                </div>
                                <div className="modal-qr">
                                    <img src={"data:image/png;base64," + this.state.modalPublicKeyQR} height={"200px"} width={"200px"}/>
                                </div>
                                <div className="copy-button" onClick={() => navigator.clipboard.writeText(this.state.current_key)}>
                                    <span>Copy Key</span>
                                </div>
                                <div className="info">
                                    <span style={{
                                        fontSize: "14px",
                                        fontFamily: "Mona-Sans"
                                    }}>Press this window to close</span>
                                </div>
                            </div>
                        </div>
                    </div>
                ): null}

                <div className="top">
                    <div className="card-header">
                        <span>Receive</span>
                    </div>
                    <div className="see-more">
                        <span><Link className={"see-more"} to={"/user/keys"} state={{token: this.state.token}} style={{textDecoration: "none"}}>See more</Link></span>
                    </div>
                </div>
                <div className="bottom">
                    <div className="keys">
                        {
                            (this.state.publicKeys.length > 0) ?
                                this.state.publicKeys.map((key, index) =>
                                    <div className="key" key={index} onClick={() => this.HandlePublicKeyClick(key.qrcode,key.key)}>{key.key}</div>)
                                :
                                <div className="key">
                                    <span className="white-text">
                                        You don't have any keys
                                    </span>
                                </div>
                        }
                    </div>
                </div>
            </div>
        )
    }
}
const Modal = ({ isOpen, onClose, children }) => {
    if (!isOpen) return null;

    return (
        <div
            onClick={onClose}
            style={{
                position: "fixed",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                background: "rgba(0, 0, 0, 0.5)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
            }}
        >
            <div
                style={{
                    background: "white",
                    height: 150,
                    width: 240,
                    margin: "auto",
                    padding: "2%",
                    border: "2px solid #000",
                    borderRadius: "10px",
                    boxShadow: "2px solid black",
                }}
            >
                {children}
            </div>
        </div>
    );
};

export default withRouter(DashboardPage)