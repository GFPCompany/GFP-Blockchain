import React from "react";
import {Navigate} from "react-router-dom";
import withRouter from "../../../components/navigate_router/navigate_router";
import Header from "../../../components/Header";
import "./KeysPageStyle_0.css"
import {AuthUser, CreateKeys, DeleteKeys, GetKeys, ImportKey} from "../../../scripts/API";
import create_icon from "../img/create-icon.svg";
import "./modal-style_0.css"
class KeysPage extends React.Component{
    constructor(props) {
        super(props);
        console.log("KeysPage PROPS: ",this.props)
        this.state = {
            token: (this.props.location) ? ((this.props.location.state.token) ? (this.props.location.state.token): '') : '',

            isAuthorized: (this.props.location) ? ((this.props.location.state.token) ? true: false) :false,

            redirect: false
        }
    }
    componentDidMount() {
        if(!this.state.isAuthorized) {
            this.setState({
                redirect: true
            })
        }
    }

    render(){
        if(this.state.redirect){
            return(
                <Navigate to="/" state={{token: ''}}/>
            )
        }
        return(
            <div className={"page"}>
                <Header token={this.state.token}/>
                <div className="content">
                    <div className="page-header">
                        <span>Keys</span>
                    </div>
                    <KeysListBox token={this.state.token}/>
                </div>
            </div>
        )
    }
}
class KeysListBox extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            token: this.props.token,
            public_keys: [],
            createKeyModalisOpen:false,
            importKeyModalisOpen:false
        }
        this.LoadKeys = this.LoadKeys.bind(this)
        this.CloseCreateKeyModal = this.CloseCreateKeyModal.bind(this)
        this.ShowCreateKeyModal = this.ShowCreateKeyModal.bind(this)
        this.CreateKeyPair = this.CreateKeyPair.bind(this)
        this.DeleteKeyPair = this.DeleteKeyPair.bind(this)
    }
    async LoadKeys() {
        const response = await GetKeys({
            token: this.state.token
        })

        if (response.status === "ok") {
            this.setState({
                public_keys: response.data.public_keys
            })
        }

    }
    componentDidMount() {
        this.LoadKeys()
    }
    CloseCreateKeyModal(){
        this.setState({
            createKeyModalisOpen: false
        })
    }
    ShowCreateKeyModal(){
        this.setState({
            createKeyModalisOpen: true
        })
    }
    ShowImportKeyModal(){
        this.setState({
            importKeyModalisOpen: true
        })
    }
    CloseImportKeyModal(){
        this.setState({
            importKeyModalisOpen: false
        })
    }
    async CreateKeyPair(){
        const key_pair_name = document.getElementById("create-key-name-input").value
        console.log(key_pair_name)
        const response = await CreateKeys(
            {
                token: this.state.token,
                data:{
                    name: key_pair_name
                }
            }
        )
        this.LoadKeys()
        this.CloseCreateKeyModal()
    }
    async ImportKeyHandler(){
        var key = document.getElementById("import-key-input").value
        var response = await ImportKey(
            {
                token: this.state.token,
                data:{
                    key: key
                }
            }
        )
        this.LoadKeys()
        this.CloseImportKeyModal()
    }
    async DeleteKeyPair(key){
        const response = await DeleteKeys(
            {
                token: this.state.token,
                data:{
                    key: key
                }
            }
        )
        this.LoadKeys()
    }
    render(){
        return(
            <div className="keys-list-box">
                <div className="keys-list">

                    {
                        (this.state.public_keys.length > 0) ?(
                            this.state.public_keys.map((key, index) =>
                                <div className={"key-list-item "+index} key={index}>
                                    <div className="name">
                                        <span>{key.name}</span>
                                    </div>
                                    <div className="address">
                                        <span>{key.key}</span>
                                    </div>
                                    <div className="created-at">
                                        <span>{key.created_at}</span>
                                    </div>
                                    <div className="delete-button" onClick={() => this.DeleteKeyPair(key.key)}>
                                        <span>Delete</span>
                                    </div>
                                </div>
                            )
                        ):(<div className={"key-list-item"}><span className={"no-key"}>You haven't any key</span></div>)
                    }
                    <div className="buttons-group">
                        <div className="create-key-button" onClick={() => this.ShowCreateKeyModal()}>
                            {/*<img src={create_icon} height={"30px"} width={"30px"}/>*/}
                            <span>Create Key</span>
                        </div>
                        <div className="import-key-button" onClick={() => this.ShowImportKeyModal()}>
                            <span>Import Key</span>
                        </div>
                    </div>
                </div>
                <Modal
                           onClose={() => this.setState({createKeyModalisOpen: false})}
                           isOpen={this.state.createKeyModalisOpen}
                           title={"Create Key"}
                           children={(
                               <div>
                                   <div className="create-key-form">
                                       <div className="name">
                                           <input type="text" placeholder="Name" className={"modal-input"} id={"create-key-name-input"}/>
                                       </div>
                                       <div className="submit-button" onClick={() => this.CreateKeyPair()}>
                                           <span>Create</span>
                                       </div>
                                   </div>
                               </div>
                           )}
                />
                <Modal onClose={() => this.setState({importKeyModalisOpen: false})}
                       isOpen={this.state.importKeyModalisOpen} title={"Import Key"}
                       title={"Create Key"}
                       children={(
                           <div className={"import-key-form"}>
                               <div className="name">
                                   <input type="text" placeholder="PrivateKey" className={"modal-input"} id={"import-key-input"}/>
                               </div>
                               <div className="submit-button" onClick={() => this.ImportKeyHandler()}>
                                   <span>Import</span>
                               </div>
                           </div>
                       )
                }
                />
            </div>
        )
    }
}
const Modal = ({ isOpen, onClose, children ,title}) => {
    if (!isOpen) return null;

    return (
        <div
            style={{
                position: "fixed",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                background: "rgba(0, 0, 0, 0.5)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
            }}
        >
            <div
                style={{
                    display: "inline-block",
                    background: "white",
                    height: 150,
                    margin: "auto",
                    padding: "2%",
                    border: "2px solid #000",
                    borderRadius: "10px",
                    boxShadow: "2px solid black",
                }}
                className={"modal-container"}
            >
                <div className="modal-header">
                    <span>{title}</span>
                    <button onClick={onClose}>X</button>
                </div>
                {children}
            </div>
        </div>
    );
};

export default withRouter(KeysPage)