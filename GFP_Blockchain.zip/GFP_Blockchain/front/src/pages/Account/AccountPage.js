import React from 'react';
import Header from "../../components/Header";
import withRouter from "../../components/navigate_router/navigate_router";
import {GetUserInfo} from "../../scripts/API";
class AccountPage extends React.Component {
    constructor(props) {
        super();

        this.state = {
            isAuthorized: props.location.state.isAuthorized,
            token: props.location.state.token,

            user_info: {}
        }
        this.LoadUserInfo = this.LoadUserInfo.bind(this);

    }
    async LoadUserInfo() {
        var user_info = await GetUserInfo(this.state.token);
        console.log(user_info)
        this.setState({user_info: user_info.data.user_info});
    }

    render() {
        return (
            <div className="page" onLoad={this.LoadUserInfo}>

                <Header token={this.props.location.state.token}/>

                <div className="content">
                    <p><span className={"base-white-text"}>Your first name is: {this.state.user_info.first_name}</span></p>
                    <p></p>
                    <p><span className={"base-white-text"}>Your last name is: {this.state.user_info.last_name}</span></p>
                    <p></p>
                    <p><span className={"base-white-text"}>Your last surname is: {this.state.user_info.sur_name}</span></p>
                    <p></p>
                    <p><span className={"base-white-text"}>Your registered at: {this.state.user_info.created_at}</span></p>
                </div>
            </div>
        );
    }
}
export default withRouter(AccountPage)