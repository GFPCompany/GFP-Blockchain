import React from "react";
import {Navigate} from "react-router-dom";
import Header from "../../components/Header";
import withRouter from "../../components/navigate_router/navigate_router";
import "./LogoutPageStyle_0.css"

class LogoutPage extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            clicked: false,
            token: (this.props.location.state) ? ((this.props.location.state.token) ? (this.props.location.state.token): '') : '',
        }
    }
    onClicke = () => {
        document.cookie = "{}"
        this.setState({clicked: true})
    }

    render() {
        if (this.state.clicked){
            return (
                <Navigate to="/" state={{deauth: true}}/>
            )
        }
        return (
            <div className={"page"}>
                <Header token={this.state.token}/>
                <div className="content">
                    <h1 className={"base-white-text"}>Logout</h1>
                    <div className="logout" onClick={() => this.onClicke()}>
                        <span>Logout & Reset cookies</span>
                    </div>
                </div>

            </div>
        );
    }
}

export default withRouter(LogoutPage)