import React from 'react';
import './LoginStyle_0.css';
import logo from '../../logo.svg'
import axios from "axios";
import Header from "../../components/Header";
import ToastList from "../../components/Toast/ToastList";
import {Navigate, useNavigate} from "react-router-dom";
import withRouter from "../../components/navigate_router/navigate_router";
import {AuthUser} from "../../scripts/API";
const sha256 = require("sha256");

const API_AUTH_LINK = 'http://192.168.1.64:8920/api/user/auth'
const delay_t = ms => new Promise(
    resolve => setTimeout(resolve, ms)
);

class LoginPage extends React.Component {
    positions = {
        "top-right": "Top-right",
        "top-left": "Top-left",
        "bottom-right": "Bottom-right",
        "bottom-left": "Bottom-left",
    };

    showToast = (message, type) => {
        const toast = {
            id: Date.now(),
            message,
            type,
        };

        this.setState({toasts: [...this.state.toasts, toast]});

        if (this.state.autoClose) {
            setTimeout(function (){
                delay_t(this.state.autoCloseDuration);
                this.removeToast(toast.id)
            }.bind(this), this.state.autoCloseDuration);
        }
    };

    removeToast = (id) => {
        this.setState({toasts: this.state.toasts.filter((toast) => toast.id !== id)});
    };

    removeAllToasts = () => {
        this.setState({toasts: []});
    };

    handleDurationChange = (event) => {
        this.setState({autoCloseDuration: event.target.value});
    };

    handleAutoCloseChange = () => {
        this.setState({autoClose: !this.state.autoClose});
        this.removeAllToasts();
    };

    handlePositionChange = (event) => {
        this.setPosition(event.target.value);
    };

    async getDataAxios(data:Object){
        const response =
            await axios.post(API_AUTH_LINK,data)
        this.setState({api_auth_response: response.data})
        return response.data
    }

    async CheckUser(){
        const username = document.getElementById('signin-username-input').value
        const password = document.getElementById('signin-password-input').value
        const response = await AuthUser({
            username: username,
            password_hash: await sha256(password)
        })
        console.log(response)
        if (response.status==="ok"){
            this.showToast("Login successful", "success")
            var token = response.data.token
            this.setState({
                token: token,
                isAuthorized: true
            })

        }
        else if (response.api_err_code===0x02 || response.api_err_code===0x01){
            this.showToast("Invalid username or password", "failure")
        }
    }
    constructor() {
        super();
        this.state = {
            api_auth_response: {},
            toasts: [],
            autoClose: true,
            autoCloseDuration: 2000,
            position: "bottom-right",

            token: (this.props) ? ((this.props.location.state.token) ? (this.props.location.state.token): '') : '',

            isAuthorized: (this.props) ? ((this.props.location.state.token) ? true: false):false,
        };
    }
    componentDidMount()
    {
    }

    render() {
        if (this.state.isAuthorized){
            return (
                <Navigate to="/" state={{token: this.state.token}}/>//>
            )
        }
        return (
            <div className="page">

                <Header/>
                <div className="content">
                    <div className="form-header">
                        <span>Sign in to Wallet</span>
                    </div>
                    <div className="login-form">

                        <div className="login-section">
                            <div className="hint">
                                <span>Username or email address</span>
                            </div>
                            <div className="input">
                                <input type="text" id="signin-username-input"/>
                            </div>
                        </div>
                        <div className="password-section">
                            <div className="hint">
                                <span>Password</span>
                            </div>
                            <div className="input">
                                <input type="password" id="signin-password-input"/>
                            </div>
                        </div>
                        <div className="signin-button-section">
                            <div id="signin-button" onClick={this.CheckUser.bind(this)}>
                                <span>Sign in</span>
                            </div>
                        </div>
                    </div>
                    <div className="registration">
                        <span>New to GFP Wallet? <a className="link" href="/registration">Sign up</a></span>
                    </div>
                </div>
                <div className="side-info">
                    <ToastList data={this.state.toasts} position="bottom-right" removeToast={this.removeToast}/>
                </div>
            </div>
        );
    }
}

export default withRouter(LoginPage)