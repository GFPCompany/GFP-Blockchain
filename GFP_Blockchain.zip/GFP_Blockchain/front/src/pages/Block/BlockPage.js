import React from "react";
import "./BlockPage_style_0.css"
import withRouter from "../../components/navigate_router/navigate_router";
import Header from "../../components/Header";
import {GetBlock} from "../../scripts/API";


class BlockPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            token: (this.props.location.state.token) ? this.props.location.state.token: '',

            isAuthorized: !!(this.props.location.state.token),

            block_hash:this.props.params.block_hash,
            block: {},
        }
        this.LoadBlock = this.LoadBlock.bind(this);
    }
    async LoadBlock(){
        var response = await GetBlock({"data":{"block_hash":this.state.block_hash}});
        this.setState({block: response.data.block});
    }
    componentDidMount() {
        this.LoadBlock()
    }

    render() {
        return (
            <div className="page">
                <Header token={this.state.token}/>
                <div className="content">
                    <div className="page-header">
                        <span>Block</span>
                    </div>
                    <div className="block-card-1">
                        <div className="left">
                            <div className="container-header">
                                <span>Details</span>
                            </div>
                            <div className="container-body">
                                <div className="value">
                                    <div className="hint">
                                        <span>Height</span>
                                    </div>
                                    <div className="val">
                                        <span>{this.state.block.height}</span>
                                    </div>
                                </div>
                                <div className="value">
                                    <div className="hint">
                                        <span>Hash</span>
                                    </div>
                                    <div className="val hash">
                                        <span>{this.state.block.hash}</span>
                                    </div>
                                </div>
                                <div className="value">
                                    <div className="hint">
                                        <span>Size</span>
                                    </div>
                                    <div className="val">
                                        <span>{this.state.block.size}&nbsp;Bytes</span>
                                    </div>
                                </div>
                                <div className="value">
                                    <div className="hint">
                                        <span>Previous Block</span>
                                    </div>
                                    <div className="val hash">
                                        <span>{this.state.block.prev_hash}</span>
                                    </div>
                                </div>
                                <div className="value">
                                    <div className="hint">
                                        <span>Timestamp</span>
                                    </div>
                                    <div className="val">
                                        <span>{this.state.block.timestamp}</span>
                                    </div>
                                </div>
                                <div className="value">
                                    <div className="hint">
                                        <span>Transactions Count</span>
                                    </div>
                                    <div className="val">
                                        <span>{this.state.block.txs_count}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="right">
                            <div className="container-header">
                                <span>Transactions</span>
                            </div>
                            <div className="container-body">
                                {
                                    (this.state.block.txs_count > 0) ? (
                                        (
                                            this.state.block.txs.map((tx) => {
                                                return (
                                                    <div className="tx-item">
                                                        <div className="value" key={tx}>
                                                            <div className="val hash">
                                                                <span>{tx}</span>
                                                            </div>
                                                        </div>
                                                        <table>
                                                            <tbody>
                                                            <tr>
                                                                <td>
                                                                    <div className="value">
                                                                        <div className="hint">
                                                                            <span>Amount</span>
                                                                        </div>
                                                                        <div className="val">
                                                                            <span>{tx}</span>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                )
                                            })
                                        )
                                    ) : ( <div className="value">No transactions</div> )
                                }

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default withRouter(BlockPage)