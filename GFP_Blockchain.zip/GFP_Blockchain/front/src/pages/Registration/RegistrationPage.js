import React, {useState} from "react";
import Header from "../../components/Header";
import "./RegistrationStyle_0.css"
import {delay_t, GetData, RegistrationUser} from "../../scripts/API";
import Toast from "../../components/Toast/Toast";
import ToastList from "../../components/Toast/ToastList";
import {Navigate} from "react-router-dom";
const sha256 = require("sha256");
class RegistrationPage extends React.Component {


    positions = {
        "top-right": "Top-right",
        "top-left": "Top-left",
        "bottom-right": "Bottom-right",
        "bottom-left": "Bottom-left",
    };

    showToast = (message, type) => {
        const toast = {
            id: Date.now(),
            message,
            type,
        };

        this.setState({toasts: [...this.state.toasts, toast]});

        if (this.state.autoClose) {
            setTimeout(function (){
                delay_t(this.state.autoCloseDuration);
                this.removeToast(toast.id)
            }.bind(this), this.state.autoCloseDuration);
        }
    };

    removeToast = (id) => {
        this.setState({toasts: this.state.toasts.filter((toast) => toast.id !== id)});
    };

    removeAllToasts = () => {
        this.setState({toasts: []});
    };

    handleDurationChange = (event) => {
        this.setState({autoCloseDuration: event.target.value});
    };

    handleAutoCloseChange = () => {
        this.setState({autoClose: !this.state.autoClose});
        this.removeAllToasts();
    };

    handlePositionChange = (event) => {
        this.setPosition(event.target.value);
    };

    RegistrationCheck=()=> {


        const username = document.getElementById('registration-username-input').value
        const password = document.getElementById('registration-password-input').value
        const repeat_password = document.getElementById('registration-repeat-password-input').value

        //check username as number
        if (username.match(/^[0-9]+$/)){
            console.log("Username should contain letters")
            this.showToast("Username should contain letters", "failure")
            return
        }

        if (password !== repeat_password){
            console.log("Passwords are not equal")
            this.showToast("Passwords are not equal", "failure")
            return
        }
        this.Registration()
    }
    async Registration() {
        console.log("clled")
        const username = document.getElementById('registration-username-input').value
        const password = document.getElementById('registration-password-input').value
        const repeat_password = document.getElementById('registration-repeat-password-input').value

        const first_name = document.getElementById('registration-first-name-input').value
        const middle_name = document.getElementById('registration-middle-name-input').value
        const last_name = document.getElementById('registration-last-name-input').value

        var data = {
            username: username,
            password_hash: await sha256(password),
            first_name: first_name,
            sur_name: middle_name,
            last_name: last_name
        }
        data = await RegistrationUser(data)
        console.log(data)
        if(data.api_err_code===0x0003){
            this.showToast("Username already exists", "failure")
            return
        }
        else if(data.status==="ok"){
            this.showToast("Registration successful, now you will be redirected", "success")
            this.setState({token: data.token})
            setTimeout(()=>{
                this.setState({redirect: true})
            },1000)
        }
    }
    constructor(props) {
        super(props);
        this.state = {
            show_notification: false,
            toasts: [],
            autoClose: true,
            autoCloseDuration: 2000,
            position: "bottom-right",

            token: '',

            redirect: false
        }

    }
    render() {
        if(this.state.redirect){
            return(
                <Navigate to={"/"} state={{token: this.state.token}}/>
            )
        }
        return (
            <div className="page">
                <div className="header"></div>
                <Header/>
                <div className="content">
                    <div className="form-header">
                        <span>Sign up</span>
                    </div>
                    <div className="registration-form">

                        <div className="form">

                            <div className="hint">
                                <span>Username</span>
                            </div>
                            <div className="input">
                                <input type="text" id="registration-username-input"/>
                            </div>
                            <div className="hint">
                                <span>Password</span>
                            </div>
                            <div className="input">
                                <input type="password" id="registration-password-input"/>
                            </div>
                            <div className="hint">
                                <span>Repeat password</span>
                            </div>
                            <div className="input">
                                <input type="password" id="registration-repeat-password-input"/>
                            </div>
                            <div className="hint">
                                <span>First name</span>
                            </div>
                            <div className="input">
                                <input type="text" id="registration-first-name-input"/>
                            </div>
                            <div className="hint">
                                <span>Middle name</span>
                            </div>
                            <div className="input">
                                <input type="text" id="registration-middle-name-input"/>
                            </div>
                            <div className="hint">
                                <span>Last name</span>
                            </div>
                            <div className="input">
                                <input type="text" id="registration-last-name-input"/>
                            </div>

                            <div id="registration-button" onClick={this.RegistrationCheck}>
                                <span>Registration</span>
                            </div>

                        </div>


                    </div>
                </div>
            <div className="side-info">
                <ToastList data={this.state.toasts} position="bottom-right" removeToast={this.removeToast}/>
            </div>

            </div>
        );
    }

}
export default RegistrationPage