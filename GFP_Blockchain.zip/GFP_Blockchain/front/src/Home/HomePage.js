import React from 'react'
import Header from "../components/Header";
import withRouter from "../components/navigate_router/navigate_router";
import {GetUserInfo, GetUsersCount} from "../scripts/API";
import "../styles/global_text_0.css"
import {Link, Navigate} from "react-router-dom";
class HomePage extends React.Component {
    constructor(props) {
        super(props);
        var token = '';
        if (!this.props.location.state) {
            token = this.pickToken();
        }
        else {
            token = this.props.location.state.token
        }
        console.log("TOKEN: ",token)

        this.state = {
            token: token,

            isAuthorized: (token) ? (!!(token)) : false,

            deauth: (this.props.location.state) ? ((this.props.location.state.deauth) ? (this.props.location.state.deauth): false) : false,

            username:"",

            data:{
                users_count:0
            }
        }
        this.LoadUserInfo = this.LoadUserInfo.bind(this)
        this.HandleUsersCount = this.HandleUsersCount.bind(this)
        this.pickToken = this.pickToken.bind(this)

    }
    componentDidMount() {
        if(this.state.token===''){
            this.pickToken()
        }
        this.HandleUsersCount()
    }
    pickToken(){
        if(document.cookie!=null && document.cookie!==''){
            console.log("cookie",document.cookie)
            try{
                var cookie_data = JSON.parse(document.cookie)
                if(cookie_data.token){
                    return cookie_data.token
                }
            }
            catch (e){

            }
        }
        return ''
    }
    async LoadUserInfo(){
        var username = await GetUserInfo(this.state.token)
        username = username.data.user_info.username
        this.setState({username:username})
    }
    async HandleUsersCount(){
        var users_count = await GetUsersCount()
        users_count = users_count.users_count
        this.setState({data:{users_count:users_count}})
    }

    render() {
        console.log("Rendering Home",this.state)

        if(this.state.isAuthorized) {
            //set cookie token
            if(document.cookie==='' || document.cookie===undefined){
                document.cookie = "{}"
            }
            if(!JSON.parse(document.cookie).token) {
                var cookie_data = JSON.parse(document.cookie)
                cookie_data["token"] = this.state.token
                document.cookie = JSON.stringify(cookie_data)
            }
            console.log("giving to header",this.state.token)
            return (
                <div className="page" onLoad={this.LoadUserInfo}>

                    <Header token={this.state.token}/>
                    <div className="content">
                        <h1 className={"base-white-text"}>Welcome to GFP BlockChain</h1>
                        <p className={"base-white-text"}>GFP BlockChain is an open-source, decentralized blockchain that created for support Open Source community.</p>
                        <p className={"base-white-text"}>You are currently logged in as <span className={"base-blue-text"}>{this.state.username}</span></p>
                        <p className={"base-white-text"}>With us <span className={"base-blue-text"}>{this.state.data.users_count}</span> users are currently registered</p>
                    </div>
                </div>
            );
        }
        return (
            <div className="page">
                <Header/>
                <div className="content">
                    <h1 className={"base-white-text base-white-blinking-text"}>Welcome to GFP BlockChain</h1>
                    <p className={"base-white-text base-white-blinking-text"}>GFP BlockChain is an open-source, decentralized blockchain that created for support Open Source community.</p>
                    <p className={"base-white-text base-white-blinking-text"}>With us <span className={"base-blue-text"}>{this.state.data.users_count}</span> users are currently registered</p>
                    <p></p>
                    <p className={"base-white-text"}><Link className={"base-blue-text"} style={{textDecoration:"none"}} to="/login">Login</Link> to view more info</p>
                </div>
            </div>
        );

    }
}
export default withRouter(HomePage)