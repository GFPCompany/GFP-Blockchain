import React from "react";
import "./HeaderStyle_0.css"
import {Link} from "react-router-dom";
import {GetUserInfo} from "../scripts/API";
class Header extends React.Component {
    constructor(props) {
        super(props);
        console.log("HEADER PROPS: ",this.props)
        this.state = {
            token: (this.props.token) ? this.props.token : '',

            isAuthorized: !!(this.props.token),

            username:""
        }

        this.LoadUserInfo = this.LoadUserInfo.bind(this)
    }
    async LoadUserInfo(){
        var username = await GetUserInfo(this.state.token)
        this.setState({username:username.data.user_info.username})
    }
    componentDidMount() {
    }

    render() {
        console.log("RENDERING HEADER: ",this.state.isAuthorized)
        if(this.state.isAuthorized){
            return (
                <div className="header" onLoad={this.LoadUserInfo}>
                    <div className="header-content">
                        <div className="logo">
                            <img src="/gfplogo.png" height="20" width="20"/>
                        </div>
                        <div className="links">
                            <Link to={"/"} state={{token: this.state.token, isAuthorized: this.state.isAuthorized}}>Home</Link>
                            <div className="links-container">
                                <div className="name">
                                    Data
                                </div>
                                <div className="links-menu-box">
                                    <Link to="/blocks" state={{token: this.state.token, isAuthorized: this.state.isAuthorized}}>Blocks</Link>
                                </div>
                            </div>
                            <div className="links-container">
                                <Link className={"menu-link"} to={"/dashboard"} state={{token: this.state.token, isAuthorized: this.state.isAuthorized}}>Dashboard</Link>
                                <div className="links-menu-box">
                                    <Link to={"/user/keys"} state={{token: this.state.token}}>Keys</Link>
                                    <Link to={"/user/send"} state={{token: this.state.token}}>Send</Link>
                                    <Link to={"/user/receive"} state={{token: this.state.token}}>Receive</Link>
                                    <Link to={"/user/transactions"} state={{token: this.state.token}}>Transactions</Link>
                                </div>
                            </div>


                            <Link to={"/account"} state={{token: this.state.token, isAuthorized: this.state.isAuthorized}}>Account</Link>
                        </div>
                        <div className="account-authorized">
                            <div>
                                <span className={"header-username"}>{this.state.username}</span>
                            </div>
                        </div>
                        <div className={"links"}>
                            <Link className={"link"} to={"/logout"} state={{token: this.state.token, isAuthorized: this.state.isAuthorized}}>Logout</Link>
                        </div>
                    </div>
                </div>
            )
        }
        return (
            <div className="header">
                <div className="header-content">
                    <div className="logo">
                        <img src="/gfplogo.png" height="60" width="60"/>
                    </div>
                    <div className="links">
                        <Link to={"/"}>Home</Link>
                        <a className="link" href="/blocks">Blocks</a>
                    </div>
                    <div className="account">
                        <a className="link" href="/login">Sign in</a>
                        <a className="link" href="/registration">Sign up</a>
                    </div>
                </div>
            </div>
        );
    }
}

export default Header