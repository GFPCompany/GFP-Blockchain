import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Routes, Route, useNavigate, useNavigation} from 'react-router-dom';
import BlocksPage from "./pages/Blocks/BlocksPage";
import LoginPage from "./pages/Login/LoginPage";
import HomePage from "./Home/HomePage";
import RegistrationPage from "./pages/Registration/RegistrationPage";
import AccountPage from "./pages/Account/AccountPage";
import DashboardPage from "./pages/Dashboard/DashboardPage";
import LogoutPage from "./pages/Logout/LogoutPage";
import KeysPage from "./pages/Dashboard/Keys/KeysPage";
import SendPage from "./pages/Dashboard/Send/SendPage";
import TransactionsPage from "./pages/Dashboard/Transactions/TransactionsPage";
import BlockPage from "./pages/Block/BlockPage";
function App() {
  return (
      <BrowserRouter>
        <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path={"/blocks"} element={<BlocksPage />}/>
            <Route path={"/blocks/:block_hash"} element={<BlockPage />}/>
            <Route path={"/login"} element={<LoginPage/>}/>
            <Route path={"/registration"} element={<RegistrationPage />}/>
            <Route path={"/account"} element={<AccountPage />}/>
            <Route path={"/dashboard"} element={<DashboardPage />}/>
            <Route path={"/logout"} element={<LogoutPage />}/>
            <Route path={"/user/keys"} element={<KeysPage />}/>
            <Route path={"/user/send"} element={<SendPage />}/>
            <Route path={"/user/transactions"} element={<TransactionsPage />}/>
            <Route path="*" element={<HomePage />} />
        </Routes>
      </BrowserRouter>
  );
}

export default App;
