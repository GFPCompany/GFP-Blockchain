import datetime
import json
import time

from libs.gfp_library_0 import sha256

CONFIG = {
    "start_bytes":b"?<--",
    "end_bytes":b"-->.",
    "checksum_size":4
}

PARITY = {
    "start_bytes":4,
    "operation":4,
    "size":4,
    "data":"size",
    "checksum":4,
    "end_bytes":4
}
class DMTP_Message:
    def __init__(self):
        self.start_bytes = CONFIG["start_bytes"]
        self.end_bytes = CONFIG["end_bytes"]
    def build(self,operation:bytes,data:bytes,token:bytes = b""):
        message = b""
        message += self.start_bytes
        message += int(operation.hex(),16).to_bytes(4,byteorder="big")
        message += len(data).to_bytes(4,byteorder="big")
        message += data
        message += b"\x00"*(64-len(token))+token
        message += bytes.fromhex(sha256(data))[:4]
        message += self.end_bytes
        return message
    def parse(self,packet):
        data = {
            "operation":int(packet[4:8].hex(),16),
            "size":int(packet[8:12].hex(),16),
            "data":packet[12:12+int(packet[8:12].hex(),16)],
            "token":packet[12+int(packet[8:12].hex(),16):12+int(packet[8:12].hex(),16)+64],
            "checksum":packet[-8:-4],
        }
        return data

class DMTP_packet_PING:
    def __init__(self):
        self.operation = bytes.fromhex("1000")
    def build(self):
        self.data = b""
        self.message = DMTP_Message().build(self.operation, self.data)
        return self.message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        return data
class DMTP_packet_PONG:
    def __init__(self):
        self.operation = bytes.fromhex("1001")
    def build(self):
        self.data = b""
        self.message = DMTP_Message().build(self.operation, self.data)
        return self.message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        return data
class DMTP_packet_GETADDR:
    def __init__(self):
        pass
    def build(self,token:bytes = b""):
        self.operation = bytes.fromhex("1004")
        self.data = b""
        self.message = DMTP_Message().build(self.operation, self.data,token)
        return self.message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        return data
class DMTP_packet_ADDR:
    def __init__(self):
        pass
    def build(self,address,token:bytes = b""):
        address = [json.loads(i) for i in list(set([json.dumps(a) for a in address]))]
        data = b""
        data += len(address).to_bytes(2,byteorder="big")
        for i in address:
            data += i["ip"].to_bytes(16,byteorder="big")
            data += i["port"].to_bytes(2,byteorder="big")
        operation = bytes.fromhex("1005")
        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)["data"]
        address = []
        address_count = int(data[0:2].hex(),16)
        print(address_count)
        data = data[2:]
        for i in range(0,address_count):
            offset = i*18
            address.append({
                "ip":int.from_bytes(data[offset:offset+16],"big"),
                "port":int.from_bytes(data[offset+16:offset+18],"big")
            })
        return address
class DMTP_packet_VERSION:
    def __init__(self):
        pass
    def build(self,software_version:bytes,address:bytes,port:bytes,services:bytes,height:bytes,token:bytes=b""):
        self.operation = bytes.fromhex("1002")
        self.data = b"\x00"*(4-len(software_version))+software_version
        self.data += b"\x00"*(16-len(address))+address
        self.data += b"\x00"*(2-len(port))+port
        self.data += b"\x00"*(8-len(services))+services
        self.data += b"\x00"*(8-len(height))+height
        self.message = DMTP_Message().build(self.operation, self.data,token)
        return self.message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        data = {
            "data":{
                "software_version": int(data["data"][0:4].hex(), 16),
                "address": int(data["data"][4:20].hex(), 16),
                "port": int(data["data"][20:22].hex(), 16),
                "services": int(data["data"][22:30].hex(), 16),
                "height": int(data["data"][30:38].hex(), 16)
            },
            "token":data["token"]
        }

        return data
class DMTP_packet_VERACK:
    def __init__(self):
        pass
    def build(self,token:bytes = b""):
        self.operation = bytes.fromhex("1003")
        self.data = b""
        self.message = DMTP_Message().build(self.operation, self.data,token)
        return self.message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        return data
class DMTP_packet_VERDEC:
    def __init__(self):
        pass
    def build(self,token:bytes = b""):
        self.operation = bytes.fromhex("1010")
        self.data = b""
        self.message = DMTP_Message().build(self.operation, self.data,token)
        return self.message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        return data
class DMTP_packet_INV:
    def __init__(self):
        pass
    def build(self,objects_type:int,objects:list,token:bytes = b""):
        self.operation = bytes.fromhex("1007")
        self.data = b""
        self.data += objects_type.to_bytes(2,byteorder="big")
        for i in objects:
            self.data += bytes.fromhex(i)
        self.message = DMTP_Message().build(self.operation, self.data,token)
        return self.message
    def parse(self,packet):
        packet = DMTP_Message().parse(packet)["data"]
        data = {
            "objects_type": int(packet[0:2].hex(),16),
            "objects": []
        }
        for i in range(2,len(packet),32):
            data["objects"].append(packet[i:i+32].hex())
        return data
class DMTP_packet_GETDATA:
    def __init__(self):
        pass
    def build(self,objects_type:int,objects:list,token:bytes = b""):
        self.operation = bytes.fromhex("1006")
        self.data = b""
        self.data += objects_type.to_bytes(2,byteorder="big")
        for i in objects:
            self.data += bytes.fromhex(i)
        self.message = DMTP_Message().build(self.operation, self.data,token)
        return self.message
    def parse(self,packet):
        packet = DMTP_Message().parse(packet)["data"]
        data = {
            "objects_type": int(packet[0:2].hex(),16),
            "objects": []
        }
        for i in range(2,len(packet),32):
            data["objects"].append(packet[i:i+32].hex())
        return data
class DMTP_packet_TX:
    def __init__(self):
        pass
    def build(self,transaction:bytes,token:bytes = b""):
        self.operation = bytes.fromhex("1010")
        self.data = transaction
        self.message = DMTP_Message().build(self.operation, self.data,token)
        return self.message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        return data
