from libs.beauti_cli import printWarning
from libs.gfp_library_0 import *
from objects.transaction import *

CONFIG = {
    "start_bytes":b"?<--",
    "end_bytes":b"-->."
}

class DMTP_Message:
    def __init__(self):
        self.start_bytes = CONFIG["start_bytes"]
        self.end_bytes = CONFIG["end_bytes"]
    def build(self,operation,data,token):
        message = b""
        message += self.start_bytes
        message += int(operation.hex(),16).to_bytes(4,byteorder="big")
        message += len(data).to_bytes(4,byteorder="big")
        message += data
        message += b"\x00"*(16-len(token))+token
        message += bytes.fromhex(sha256(data))[:4]
        message += self.end_bytes
        return message
    def parse(self,packet):
        out = {
            "operation": int(packet[4:8].hex(), 16),
            "size": int(packet[8:12].hex(), 16),
            "data": packet[12:12+int(packet[8:12].hex(), 16)],
            "token": packet[12+int(packet[8:12].hex(), 16):12+int(packet[8:12].hex(), 16)+16],
            "checksum": packet[-8:-4],
        }
        if sha256(out["data"])[:8] == out["checksum"].hex():
            return out
        else:
            printWarning("CHECKSUM ERROR")
            print(sha256(out["data"])[:8],out["checksum"].hex())
            return False

class DMTP_packet_PING:
    def build(self,token):
        operation = bytes.fromhex("0000")
        data = b""
        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        return DMTP_Message().parse(packet)
class DMTP_packet_PONG:
    def build(self,token):
        operation = bytes.fromhex("0001")
        data = b""
        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        return DMTP_Message().parse(packet)

class DMTP_packet_VERSION:
    def build(self,software_version:int,protocol_version:int,address:int,port:int,services:int,height:int,token:bytes = b""):
        operation = bytes.fromhex("0002")
        data = b""
        data += software_version.to_bytes(4,byteorder="big")
        data += protocol_version.to_bytes(4,byteorder="big")
        data += address.to_bytes(16,byteorder="big")
        data += port.to_bytes(2,byteorder="big")
        data += services.to_bytes(16,byteorder="big")
        data += height.to_bytes(8,byteorder="big")
        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        out = {
            "software_version": int(data["data"][:4].hex(), 16),
            "protocol_version": int(data["data"][4:8].hex(), 16),
            "address": int(data["data"][8:24].hex(), 16),
            "port": int(data["data"][24:26].hex(), 16),
            "services": int(data["data"][26:42].hex(), 16),
            "height": int(data["data"][42:50].hex(), 16),
        }
        out = {
            "data": out,
            "token": data["token"],
            "checksum": data["checksum"]
        }
        return out
class DMTP_packet_VERACK:
    def build(self,token:bytes = b""):
        operation = bytes.fromhex("0003")
        data = b""
        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        return data
class DMTP_packet_VERDEC:
    def build(self,token:bytes = b""):
        operation = bytes.fromhex("0004")
        data = b""
        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        return data

class DMTP_packet_GETADDR:
    def build(self,token:bytes = b""):
        operation = bytes.fromhex("0005")
        data = b""
        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        return data
class DMTP_packet_ADDR:
    def build(self,address,token:bytes = b""):
        operation = bytes.fromhex("0006")
        data = b""
        data += len(address).to_bytes(4,byteorder="big")
        for i in address:
            data += i["ip"].to_bytes(16,byteorder="big")
            data += i["port"].to_bytes(2,byteorder="big")
            if type(i["token"]) == bytes:
                i["token"] = i["token"]
            else:
                i["token"] = bytes.fromhex(i["token"])
        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        data = DMTP_Message().parse(packet)
        out = {
            "address_count": int(data["data"][:4].hex(), 16),
            "address": []
        }
        for i in range(out["address_count"]):
            offset = i*18
            out["address"].append({
                "ip": int.from_bytes(data["data"][offset+4:offset+16+4],"big"),
                "port": int.from_bytes(data["data"][offset+16+4:offset+18+4],"big"),
                "token": data["data"][offset+18+4:offset+18+4+16]
            })
        out = {
            "data": out,
            "token": data["token"],
            "checksum": data["checksum"]
        }
        return out

class DMTP_packet_INV:
    def build(self,objects_type:int,objects:list,token:bytes = b""):
        operation = bytes.fromhex("2000")
        data = b""
        data += objects_type.to_bytes(4,byteorder="big")
        data += len(objects).to_bytes(4,byteorder="big")
        for i in objects:
            if type(i)==str:
                data += bytes.fromhex(i)
            elif type(i)==bytes:
                data += i
            else:
                print(type(i))
                raise ValueError("Invalid object type")

        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        packet = DMTP_Message().parse(packet)
        data = {
            "objects_type": int(packet["data"][:4].hex(),16),
            "objects_count": int(packet["data"][4:8].hex(),16),
            "objects": []
        }
        offset = 8
        for i in range(data["objects_count"]):
            offset += i*32
            data["objects"].append(packet["data"][offset:offset+32])
        data = {
            "data": data,
            "token": packet["token"],
            "checksum": packet["checksum"]
        }
        return data
class DMTP_packet_GETDATA:
    def build(self,objects_type:int,objects:list,token:bytes = b""):
        operation = bytes.fromhex("2001")
        data = b""
        data += objects_type.to_bytes(4,byteorder="big")
        data += len(objects).to_bytes(4,byteorder="big")
        for i in objects:
            data += bytes.fromhex(i)
        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        packet = DMTP_Message().parse(packet)
        data = {
            "objects_type": int(packet["data"][:4].hex(),16),
            "objects_count": int(packet["data"][4:8].hex(),16),
            "objects": []
        }
        offset = 8
        for i in range(data["objects_count"]):
            offset += i*32
            data["objects"].append(packet["data"][offset:offset+32])
        data = {
            "data": data,
            "token": packet["token"]
        }
        return data

class DMTP_packet_DATA:
    def __init__(self):
        pass
    def build(self,objects_type:int,objects:list,token:bytes = b""):
        operation = bytes.fromhex("2003")
        data = b""
        data += objects_type.to_bytes(4,byteorder="big")
        data += len(objects).to_bytes(4,byteorder="big")
        data += b"".join([i for i in objects])
        message = DMTP_Message().build(operation, data,token)
        return message
    def parse(self,packet):
        packet = DMTP_Message().parse(packet)
        object_type = int(packet["data"][:4].hex(),16)
        objects_count = int(packet["data"][4:8].hex(), 16)
        out = [b"" for i in range(objects_count)]
        if object_type == 0x00000001:
            #TODO LOOKING TRANSACTIONS
            data = packet["data"][8:]

            for i in range(objects_count):
                verify_object_type = int(data[:4].hex(), 16)
                if verify_object_type != 0x00000001:
                    printWarning("NOT A TRANSACTION IN DMTP_PACKET_DATA, OBJECT_TYPE: " + str(verify_object_type))
                    continue
                tx_type = int(data[4:6].hex(), 16)
                tx_version = int(data[6:8].hex(), 16)
                if tx_type==0x0000:
                    #TODO LOOKING P2PKH
                    header_size = 8 + 8 + 4
                    inputs_n = int(data[16:18].hex(), 16)
                    outputs_n = int(data[18:20].hex(), 16)

                    out[i] += data[:header_size]
                    data = data[header_size:]
                    for k in range(inputs_n):
                        out[i]+=data[:137]
                        data = data[137:]
                    for k in range(outputs_n):
                        out[i]+=data[:46]
                        data = data[46:]
                elif tx_type==0x0001:
                    #TODO LOOKING Coinbase
                    header_size = 8+8+4
                    inputs_n = int(data[16:18].hex(), 16)
                    outputs_n = int(data[18:20].hex(), 16)
                    out[i] += data[:header_size]
                    data = data[header_size:]
                    for i in range(inputs_n):
                        unlock_script_size = int(data[32+2:32+2+2].hex(), 16)
                        out[i] += data[:32+2+2+unlock_script_size]
                        data = data[32+2+2+unlock_script_size:]
                    for i in range(outputs_n):
                        out[i] += data[:46]
                        data = data[46:]
        elif object_type==0x00000000:
            #TODO LOOKING BLOCKS
            data = packet["data"][8:]
            for i in range(objects_count):
                header_size = 132
                txs_count = int(data[128:132].hex(), 16)
                out[i] += data[:header_size]
                data = data[header_size:]
                for j in range(txs_count):
                    tx_data = b""
                    object_type = data[:4].hex()
                    if object_type != "00000001":
                        print("Object type in 'block.txs' not allowed")
                    tx_type = data[4:6].hex()
                    tx_version = data[6:8].hex()
                    tx_timestamp = int(data[8:16].hex(), 16)
                    tx_data += data[:20]
                    if tx_type == "0000":  # HANDLING P2PKH TRANSACTION
                        inputs_n = int(data[16:18].hex(), 16)
                        outputs_n = int(data[18:20].hex(), 16)
                        tx_data += data[20:20 + inputs_n * 137]
                        data = data[20 + inputs_n * 137:]
                        tx_data += data[:outputs_n * 46]
                        data = data[outputs_n * 46:]
                    elif tx_type == "0001":  # HANDLING P2PKH COINBASE TRANSACTION
                        outputs_n = int(data[18:20].hex(), 16)
                        input_unlock_len = int(data[20 + 32 + 2:20 +32 + 2 + 2].hex(), 16)
                        tx_data += data[20:20 + 32 + 2 + 2]
                        data = data[20 + 32 + 2 + 2:]
                        tx_data += data[:36 + input_unlock_len]
                        data = data[36 + input_unlock_len:]
                        tx_data += data[:outputs_n * 46]
                        data = data[outputs_n * 46:]
                    out[i] += tx_data
        out = {
            "data": out,
            "token": packet["token"],
            "checksum": packet["checksum"]
        }
        return out