import datetime
import time
from io import BytesIO

import base58
import qrcode
from flask import *

from db.db_lib import *
from libs.gfp_library_0 import sha256
from objects.keys import GFP_PrivateKey, GFP_PublicKey

sys.path.append("../..")
from __main__ import app
from __main__ import db_name
def build_response(data,headers,status=200):
    res = make_response(json.dumps(data))
    res.headers['Content-Type'] = 'text/plain'
    res.headers['Server'] = 'Foobar'
    res.headers["Allow-Origin"] = "*"
    res.headers["Access-Control-Allow-Origin"] = "*"
    for i in headers:
        res.headers[i] = headers[i]
    res.status_code = status
    return res

@app.route("/api/user/auth",methods=["POST","GET"])
def api_user_auth():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        password = db_select("SELECT id, password_hash FROM `" + db_name + "`.`users` WHERE username = '"+data["username"]+"'")

        if len(password)==0:
            return build_response({"status": "error","message": "username or password incorrect","api_err_code":0x0002},{},200)
        if password[0]["password_hash"].hex() == data["password_hash"]:

            token = db_select("SELECT token FROM `" + db_name + "`.`tokens` WHERE user_id = '"+str(password[0]["id"])+"'")
            if len(token)==0:
                timestamp = int(time.mktime(datetime.datetime.now().timetuple()))
                token = sha256(data["username"]+password[0]["password_hash"].hex()+str(random.randint(0,10**10))+str(timestamp))
                db_insert("INSERT INTO `" + db_name + "`.`tokens` (user_id,token) VALUES ('"+str(password[0]["id"])+"',X'"+token+"')")
            else:
                token = token[0]["token"].hex()
            return build_response({"status": "ok","data":{"token": token}},{},200)
        else:
            return build_response({"status": "error","message": "username or password incorrect","api_err_code":0x0002},{},200)
    else:
        return build_response({"status": "error"},{},200)
@app.route("/api/user/info",methods=["POST","GET"])
def api_user_info():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        user_info = db_select("SELECT * FROM `" + db_name + "`.`users` WHERE id=(SELECT user_id FROM `" + db_name + "`.`tokens` WHERE token = X'"+data["token"]+"')")
        user_info = user_info[0]
        user_info["password_hash"] = user_info["password_hash"].hex()
        user_info["created_at"] = user_info["created_at"].strftime("%Y-%m-%d %H:%M:%S")
        return build_response({"status": "ok","data":{"user_info": user_info}},{},200)
    else:
        return build_response({"status": "error"},{},200)
@app.route("/api/user/keys",methods=["POST","GET"])
def api_user_keys():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        private_keys = db_select("SELECT * FROM `" + db_name + "`.`keys` WHERE user_id = (SELECT user_id FROM `" + db_name + "`.`tokens` WHERE token = X'"+data["token"]+"') AND type = 0 AND status = 0")
        public_keys = db_select("SELECT * FROM `" + db_name + "`.`keys` WHERE user_id = (SELECT user_id FROM `" + db_name + "`.`tokens` WHERE token = X'"+data["token"]+"') AND type = 1 AND status = 0")

        for i in range(len(private_keys)):
            private_keys[i]["key"] = private_keys[i]["key"].decode("utf-8")
        for i in range(len(public_keys)):
            print(public_keys[i]["key"])
            public_keys[i]["key"] = public_keys[i]["key"].decode("utf-8")
            img = qrcode.make("http://192.168.1.64:3000/user/send?key="+public_keys[i]["key"])
            buffered = BytesIO()
            img.save(buffered, format="PNG")
            img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")

            public_keys[i]["qrcode"] = img_str

        return build_response({"status": "ok","data":{"private_keys": private_keys,"public_keys": public_keys}},{},200)
    else:
        return build_response({"status": "error"},{},200)
@app.route("/api/user/keys/create",methods=["POST","GET"])
def api_user_create_key():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        token = data["token"]
        key_pair_name = data["data"]["name"]
        user_id = db_select("SELECT user_id FROM `" + db_name + "`.`tokens` WHERE token = X'"+token+"'")[0]["user_id"]

        private_key = GFP_PrivateKey().generate()
        public_key = GFP_PublicKey().generate(private_key)

        private_key = private_key.to_GFP()
        public_key = public_key.to_GFP_P2PKH(True)
        print(public_key)
        print(private_key)
        max_key_pair_id = db_select("SELECT MAX(`key_pair_id`) FROM `" + db_name + "`.`keys`")
        if max_key_pair_id[0]["MAX(`key_pair_id`)"] == None:
            max_key_pair_id = 0
        else:
            max_key_pair_id = max_key_pair_id[0]["MAX(`key_pair_id`)"]
        db_insert("INSERT INTO `" + db_name + "`.`keys` (user_id,type,`key`,`name`,`key_pair_id`) VALUES ('"+str(user_id)+"',0,X'"+private_key.hex() + "','"+key_pair_name+"',"+str(max_key_pair_id+1)+"), ('"+str(user_id)+"',1,X'"+public_key.hex()+"','"+key_pair_name+"',"+str(max_key_pair_id+1)+")")

        return build_response({"status": "ok","data":{"token": token}},{},200)
    else:
        return build_response({"status": "error"},{},200)
@app.route("/api/user/keys/delete",methods=["POST","GET"])
def api_user_delete_key():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        token = data["token"]
        public_key = data["data"]["key"]
        user_id = db_select("SELECT user_id FROM `" + db_name + "`.`tokens` WHERE token = X'"+token+"'")[0]["user_id"]

        db_delete("UPDATE `" + db_name + "`.`keys` SET status = 1 WHERE user_id = '"+str(user_id)+"' AND `key` = X'"+public_key.encode("utf-8").hex()+"'")

        return build_response({"status": "ok","data":{"token": token}},{},200)
    else:
        return build_response({"status": "error"},{},200)
@app.route("/api/user/keys/import",methods=["POST","GET"])
def api_user_import_key():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        token = data["token"]
        private_key_raw = data["data"]["key"]
        user_id = db_select("SELECT user_id FROM `" + db_name + "`.`tokens` WHERE token = X'"+token+"'")[0]["user_id"]

        private_key = GFP_PrivateKey().from_GFP(private_key_raw)
        public_key = GFP_PublicKey().generate(private_key).to_GFP_P2PKH(True)

        db_insert("INSERT INTO `" + db_name + "`.`keys` (user_id,type,`key`,`name`,`key_pair_id`) VALUES ('"+str(user_id)+"',0,X'"+private_key.to_GFP().hex() + "','Default'), ('"+str(user_id)+"',1,X'"+public_key.hex()+"','Default',(SELECT MAX(key_pair_id) FROM `" + db_name + "`.`keys` WHERE user_id = '"+str(user_id)+"'))")

        return build_response({"status": "ok","data":{"token": token}},{},200)
    else:
        return build_response({"status": "error"},{},200)