import datetime
import json
import time
from io import BytesIO
from threading import Thread

import base58
import qrcode
from flask import *

from db.db_lib import *
from libs.gfp_library_0 import sha256
from objects.keys import GFP_PrivateKey

from web.server import build_response

sys.path.append("../..")
sys.path.append("../../../../tools/calculate_balance")
from web.backend_tools import *
from __main__ import app
from __main__ import db_name

@app.route("/api/payment/transaction/create",methods=["POST","GET"])
def api_payment_transaction_create():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        token = data["token"]
        data = data["data"]

        #check token
        if token not in [i["token"].hex() for i in db_select("SELECT token FROM `" + db_name + "`.tokens")]:
            return build_response({"status": "error","message": "unauthorized access","api_err_code":0x0004},{},200)

        check_keys = ["address","amount","fee","account_division"]

        for i in check_keys:
            if i not in data.keys():
                return build_response({"status": "error","message": "invalid data","api_err_code":0x0005},{},200)

        timestamp = int(time.mktime(datetime.datetime.now().timetuple()))
        user_id = db_select("SELECT user_id FROM `" + db_name + "`.tokens WHERE token = X'" + token + "'")[0]["user_id"]

        public_key_check = db_select("SELECT `key_pair_id`,`key` FROM `" + db_name + "`.keys WHERE user_id = '" + str(user_id) + "' AND type = 1 AND `key` = X'" + data["account_division"].encode("utf-8").hex() + "'")

        if len(public_key_check) == 0:
            return build_response({"status": "error","message": "invalid data: key pair does not exist","api_err_code":0x0006},{},200)

        # checking utxo
        utxo = db_select("SELECT * FROM `" + db_name + "`.`utxo`")

        my_utxo = []
        for i in utxo:
            for j in json.loads(i["outputs"]):
                if j["lock"] in base58.b58decode(data["account_division"]).hex():
                    my_utxo.append(i["txid"])
        transactions = []
        for i in my_utxo:
            transactions.append(GetTransactionFromChain(db_name,i))

        private_key = db_select("SELECT `key` FROM `"+db_name+"`.keys WHERE user_id = (SELECT user_id FROM `"+db_name+"`.tokens WHERE token = X'" + token + "') AND type = 0 and `key_pair_id` = '"+str(public_key_check[0]["key_pair_id"])+"'")[0]["key"]
        private_key = GFP_PrivateKey().from_GFP(private_key).to_GFP()
        inputs = [{"txid": i["txid"], "vout": 0} for i in transactions]
        outputs = [{"lock": base58.b58decode(data["address"].encode("utf-8")).hex(), "amount": int(data["amount"])}]
        print(json.dumps([{"txid": i["txid"], "outputs": json.loads(i["outputs"])} for i in db_select("SELECT * FROM `"+db_name+"`.`utxo` WHERE txid IN ('" + "','".join(my_utxo) + "')")],indent=4))
        tx_data = build_tx_io([{"txid": i["txid"], "outputs": json.loads(i["outputs"])} for i in db_select("SELECT * FROM `"+db_name+"`.`utxo` WHERE txid IN ('" + "','".join(my_utxo) + "')")], outputs, int(data["fee"]), base58.b58decode(data["account_division"]).hex())
        print(json.dumps(tx_data,indent=4))
        TRANSACTION = GFP_Transaction_P2PKH().create(tx_data["inputs"], tx_data["outputs"],private_key ,transactions)
        a = GFP_Transaction_P2PKH().raw_to_json(TRANSACTION[0])
        # update users transactions
        db_insert("INSERT INTO `" + db_name + "`.`transactions` (user_id,txid,timestamp,inputs,outputs,state,tx_type) VALUES ('" + str(user_id) + "','" + sha256(bytes.fromhex(sha256(TRANSACTION[0]))) + "'," + str(TRANSACTION[1]["timestamp"]) + ",'" + json.dumps(TRANSACTION[1]["inputs"]) + "','" + json.dumps(TRANSACTION[1]["outputs"]) + "','Created',0)")

        # send transaction to node

        t = Thread(target=SendTransactionToNode,args=[TRANSACTION[0],{"ip": "127.0.0.1", "port": 4550},db_name])
        t.start()

        return build_response({"status": "ok"}, {}, 200)
    else:
        return build_response({"status": "error"}, {}, 200)
@app.route("/api/payment/transactions/income",methods=["POST","GET"])
def api_payment_transactions_income():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)


        token = data["token"]
        public_keys = db_select("SELECT `key` FROM `"+db_name+"`.keys WHERE user_id = (SELECT user_id FROM `"+db_name+"`.tokens WHERE token = X'" + token + "') AND type = 1")
        transactions = []
        utxo = db_select("SELECT * FROM `"+db_name+"`.`utxo`")
        for i in utxo:
            for j in json.loads(i["outputs"]):
                if j["lock"] in [base58.b58decode(public_key["key"]).hex() for public_key in public_keys]:
                    transactions.append(GetTransactionFromChain(db_name,i["txid"]))
        for i in range(len(transactions)):
            for j in range(len(transactions[i]["outputs"])):
                transactions[i]["outputs"][j]["lock"] = base58.b58encode(bytes.fromhex(transactions[i]["outputs"][j]["lock"])).decode("utf-8")
        return build_response({"status": "ok","data":{"transactions": transactions}},{},200)
@app.route("/api/payment/transactions/expenses",methods=["POST","GET"])
def api_payment_transactions_expenses():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)


        token = data["token"]
        public_keys = db_select("SELECT `key` FROM `"+db_name+"`.keys WHERE user_id = (SELECT user_id FROM `"+db_name+"`.tokens WHERE token = X'" + token + "') AND type = 1")
        expenses = db_select("SELECT * FROM `" + db_name + "`.`transactions` WHERE user_id = (SELECT user_id FROM `"+db_name+"`.tokens WHERE token = X'" + token + "')")

        transactions = []
        for i in expenses:
            for j in json.loads(i["inputs"]):
                vout = j["vout"]
                txid = j["txid"]
                tx = GetTransactionFromChain(db_name,txid)
                if tx["outputs"][vout]["lock"] in [base58.b58decode(public_key["key"]).hex() for public_key in public_keys]:
                    transactions.append(i)
                    break
        for i in range(len(transactions)):
            if type(transactions[i]["inputs"]) == str:
                transactions[i]["inputs"] = json.loads(transactions[i]["inputs"])
            if type(transactions[i]["outputs"]) == str:
                transactions[i]["outputs"] = json.loads(transactions[i]["outputs"])

        for i in range(len(transactions)):
            for j in range(len(transactions[i]["outputs"])):
                transactions[i]["outputs"][j]["lock"] = base58.b58encode(bytes.fromhex(transactions[i]["outputs"][j]["lock"])).decode("utf-8")

        return build_response({"status": "ok","data":{"transactions": transactions}},{},200)