from threading import Thread

import base58
import qrcode
from flask import *

from db.db_lib import *
from libs.gfp_library_0 import sha256
from objects.keys import GFP_PrivateKey
from web.backend_tools import calculate_balance_in_block

from web.server import build_response
from __main__ import app
from __main__ import db_name


@app.route("/api/system/calculate_balance",methods=["POST","GET"])
def calculate_balance():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)

        block = data["data"]["block"]
        block_height = data["data"]["block_height"]

        addresses = db_select("SELECT * FROM `"+db_name+"`.`keys` WHERE status = 0 AND type = 1")
        addresses = [{"id" : i["id"],"key" : i["key"],"last_balance_check_block" : block_height,"balance":i["balance"]} for i in addresses]

        for i in range(len(addresses)):
            addresses[i]["balance"] += calculate_balance_in_block(bytes.fromhex(block),addresses[i]["key"],[])[0]

        INSERT_TEMPLATE = "INSERT INTO `"+db_name+"`.`keys` (id,balance,last_balance_check_block) VALUES "
        for i in addresses:
            INSERT_TEMPLATE += "('"+str(i["id"])+"','"+str(i["balance"])+"','"+str(i["last_balance_check_block"])+"'),"
        INSERT_TEMPLATE = INSERT_TEMPLATE[:-1]
        INSERT_TEMPLATE += " ON DUPLICATE KEY UPDATE balance = VALUES(balance),last_balance_check_block = VALUES(last_balance_check_block)"
        addresses = [{"id":i["id"],"key":i["key"].decode("utf-8"),"balance":i["balance"],"last_balance_check_block":i["last_balance_check_block"]} for i in addresses]

        db_insert(INSERT_TEMPLATE)
        return build_response({"status":"ok","addresses":addresses},{},200)
@app.route("/api/system/transactions/state/update",methods=["POST"])
def update_transactions_state():
    data = request.data.decode("utf-8")
    data = json.loads(data)
    txid = data["data"]["txid"]
    state = data["data"]["state"]
    db_insert("UPDATE `"+db_name+"`.`transactions` SET state = '"+state+"' WHERE txid in ('"+"','".join(txid)+"')")
    return build_response({"status":"ok"},{},200)