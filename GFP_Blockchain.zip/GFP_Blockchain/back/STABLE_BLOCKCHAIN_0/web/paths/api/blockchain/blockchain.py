import datetime
import time
from io import BytesIO

import base58
import qrcode
from flask import *

from db.db_lib import *
from libs.gfp_library_0 import sha256
from objects.block import Block
from objects.keys import GFP_PrivateKey, GFP_PublicKey

sys.path.append("../..")
from __main__ import app
from __main__ import db_name
def build_response(data,headers,status=200):
    res = make_response(json.dumps(data))
    res.headers['Content-Type'] = 'text/plain'
    res.headers['Server'] = 'Foobar'
    res.headers["Allow-Origin"] = "*"
    res.headers["Access-Control-Allow-Origin"] = "*"
    for i in headers:
        res.headers[i] = headers[i]
    res.status_code = status
    return res


@app.route("/api/blockchain/block",methods=["POST","GET"])
def blockchain_block():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        block_hash = data["data"]["block_hash"]
        data = db_select("SELECT * FROM `" + db_name + "`.`raw_blocks` WHERE hash = X'" + block_hash + "'")
        r_data = data
        if len(data) == 0:
            return build_response({"status": "error","data":{"message": "block not found"}},{},400)
        data = Block().from_raw_to_json(data[0]["data"])
        data["txs"] = [sha256(bytes.fromhex(sha256(bytes.fromhex(i)))) for i in data["txs"]]
        data["height"] = r_data[0]["id"]
        data["size"] = len(r_data[0]["data"])
        data["timestamp"] = datetime.datetime.fromtimestamp(data["timestamp"]).strftime('%Y-%m-%d %H:%M:%S')
        return build_response({"status": "ok","data":{"block": data}},{},200)
    else:
        return build_response({"status": "error"},{},200)
