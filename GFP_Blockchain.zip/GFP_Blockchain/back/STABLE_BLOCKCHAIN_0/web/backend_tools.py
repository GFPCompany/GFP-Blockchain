import asyncio
import json
import socket

import base58

from db.db_lib import db_select, db_insert
from libs.gfp_library_0 import md5, sha256
from objects.block import Block
from objects.transaction import GFP_Transaction_P2PKH, GFP_Transaction_coinbase
from protocols.DMTP.DMTP_protocol import *


def CalculateBalanceInUTXO(db_name,address):
    address = base58.b58decode(address.encode("utf-8")).hex()
    print(address)
    balance = 0
    res = db_select("SELECT * FROM `"+db_name+"`.`utxo`")
    print(res)
    for i in res:
        for j in json.loads(i["outputs"]):
            if j["lock"] == address:
                balance += j["amount"]

    return balance
def UpdateKeysBalances(db_name):
    keys = db_select("SELECT * FROM `"+db_name+"`.`keys` WHERE status = 0 AND type = 1")
    keys = [{"id":i["id"],"key":i["key"],"balance":i["balance"]} for i in keys]
    for i in keys:
        i["balance"] += CalculateBalanceInUTXO(db_name,i["key"].decode("utf-8"))
        db_insert("UPDATE `"+db_name+"`.`keys` SET balance = '"+str(i["balance"])+"',last_balance_check_datetime = NOW() WHERE id = '"+str(i["id"])+"'")
def GetTransactionFromChain(db_name,txid):
    block = db_select("SELECT `data` FROM `"+db_name+"`.`raw_blocks`")
    block = [i["data"] for i in block]
    for i in block:
        i = Block().from_raw_to_json(i)
        for j in i["txs"]:
            if sha256(bytes.fromhex(sha256(bytes.fromhex(j)))) == txid:
                j = bytes.fromhex(j)
                tx_type = int(j[4:6].hex(), 16)
                if tx_type == 0x0000:
                    tx = GFP_Transaction_P2PKH()
                    tx = tx.raw_to_json(j)
                    tx["txid"] = txid
                    return tx
                elif tx_type == 0x0001:
                    tx = GFP_Transaction_coinbase()
                    tx = tx.raw_to_json(j)
                    tx["txid"] = txid
                    return tx

def SendTransactionToNode(tx,node,db_name):
    print("SENDING TRANSACTION TO NODE")
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((node["ip"], node["port"]))
    msg = DMTP_packet_INV().build(0x0001,[sha256(bytes.fromhex(sha256(tx)))],bytes.fromhex(md5(10)))
    client.sendall(msg)

    rcv: bytes = b""

    request = client.recv(12)
    rcv += request

    data_size = int.from_bytes(request[8:12], "big")
    data = client.recv(data_size + 8 + 16)
    rcv += data

    operation = int(rcv[4:8].hex(), 16)
    print("RECEIVED PACKET OPERATION: " + operation.to_bytes(4, byteorder="big").hex())
    if operation == 0x2001:
        rcv = DMTP_packet_GETDATA().parse(rcv)
        # TODO CHECKING

        msg = DMTP_packet_DATA().build(0x0001,[tx],bytes.fromhex(md5(10)))
        client.sendall(msg)
        client.close()

    db_insert("UPDATE `"+db_name+"`.`transactions` SET state = 'Sent to Node' WHERE txid = '"+sha256(bytes.fromhex(sha256(tx)))+"'")
    print("TRANSACTION SENT TO NODE")
def calculate_balance_in_block(block:bytes,address,utxo):
    block = Block().from_raw_to_json(block)
    block = block["txs"]

    decoded_address = base58.b58decode(address).hex()
    balance = 0
    #TODO LOOKING RECEIVED TRANSACTIONS
    for i in block:
        i = bytes.fromhex(i)
        object_type = int(i[:4].hex(),16)
        tx_type = i[4:6].hex()
        tx_version = i[6:8].hex()

        if int(tx_type,16) == 0x0000:
            tx = GFP_Transaction_P2PKH()

            tx = tx.raw_to_json(i)
            for out in tx["outputs"]:
                if out["lock"] == decoded_address:
                    balance += out["amount"]
                    if sha256(bytes.fromhex(sha256(i))) not in utxo:
                        utxo.append(sha256(bytes.fromhex(sha256(i))))
        elif int(tx_type,16) == 0x0001:
            tx = GFP_Transaction_coinbase()

            tx = tx.raw_to_json(i)
            for out in tx["outputs"]:
                if out["lock"] == decoded_address:
                    balance += out["amount"]
                    if sha256(bytes.fromhex(sha256(i))) not in utxo:
                        utxo.append(sha256(bytes.fromhex(sha256(i))))
    #TODO LOOKING SENT TRANSACTIONS
    for i in block:
        i = bytes.fromhex(i)
        object_type = int(i[:4].hex(), 16)
        tx_type = i[4:6].hex()
        tx_version = i[6:8].hex()

        if int(tx_type, 16) == 0x0000:
            tx = GFP_Transaction_P2PKH()
            tx = tx.raw_to_json(i)

            for inp in tx["inputs"]:

                if inp["txid"] in utxo:
                    for out in tx["outputs"]:
                        print(out["amount"])
                        balance -= out["amount"]
    return [balance,utxo]