import datetime
import json
import os
import random
import time

from flask import Flask, make_response, request
from flask_cors import CORS

from db.db_lib import db_select, db_insert
from libs.gfp_library_0 import sha256

app = Flask(__name__)
cors = CORS(app)


config_file = open("web/server-config.json", "r")
config = json.load(config_file)
config_file.close()
db_name = config["db_name"]
def build_response(data,headers,status=200):
    res = make_response(json.dumps(data))
    res.headers['Content-Type'] = 'text/plain'
    res.headers['Server'] = 'Foobar'
    res.headers["Allow-Origin"] = "*"
    res.headers["Access-Control-Allow-Origin"] = "*"
    for i in headers:
        res.headers[i] = headers[i]
    res.status_code = status
    return res

@app.route('/')
def hello_world():
    return 'Hello World!'

@app.route('/blockchain/get_blocks')
def blockchain_get_blocks():
    blocks = db_select("SELECT hash FROM `" + db_name + "`.`raw_blocks`")
    blocks = [i["hash"].hex() for i in blocks]
    blocks = {
        "blocks": blocks
    }
    res = make_response(json.dumps(blocks))
    res.headers['Content-Type'] = 'text/json'
    res.headers['Server'] = 'Foobar'
    res.headers["Allow-Origin"] = "*"
    res.headers["Access-Control-Allow-Origin"] = "*"
    res.headers["Cross-Origin-Embedder-Policy"] = "*"
    return res

@app.route("/api/blockchain/create_transaction",methods=["POST","GET"])
def blockchain_create_transaction():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        print(json.dumps(data,indent=4))
        return build_response({"status": "ok"},{},200)
    else:
        return build_response({"status": "error"},{},400)


@app.route("/api/user/register",methods=["POST","GET"])
def api_user_register():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        username = data["username"]
        if username in [i["username"] for i in db_select("SELECT username FROM `" + db_name + "`.`users`")]:
            return build_response({"status": "error","message": "username already exists","api_err_code":0x0003},{},200)
        password_hash = data["password_hash"]
        print(username,password_hash)
        db_insert("INSERT INTO `" + db_name + "`.`users` (username,password_hash,first_name,last_name,sur_name) VALUES ('"+username+"',X'"+password_hash+"','"+data["first_name"]+"','"+data["last_name"]+"','"+data["sur_name"]+"')")
        user_id = db_select("SELECT id FROM `" + db_name + "`.`users` WHERE username = '"+username+"'")[0]["id"]
        token = db_select("SELECT token FROM `" + db_name + "`.`tokens` WHERE user_id = '" + str(user_id) + "'")
        if len(token) == 0:
            timestamp = int(time.mktime(datetime.datetime.now().timetuple()))
            token = sha256(
                data["username"] + password_hash + str(random.randint(0, 10 ** 10)) + str(
                    timestamp))
            db_insert("INSERT INTO `" + db_name + "`.`tokens` (user_id,token) VALUES ('" + str(
                user_id) + "',X'" + token + "')")
        else:
            token = token[0]["token"].hex()
        return build_response({"status": "ok","token": token},{},200)
    else:
        return build_response({"status": "error"},{},200)
@app.route("/api/users/count")
def api_users_count():
    return build_response({"status": "ok","users_count": len(db_select("SELECT id FROM `" + db_name + "`.`users`"))},{},200)

#


import paths.api.user.user
import paths.api.payment.payment
import paths.api.system.system
import paths.api.blockchain.blockchain

if __name__ == '__main__':
    app.run(port=8920,host="192.168.1.64")
