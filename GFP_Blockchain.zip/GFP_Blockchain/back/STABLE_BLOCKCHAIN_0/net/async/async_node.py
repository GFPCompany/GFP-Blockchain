import asyncio, socket

import db.db_lib
from libs.beauti_cli import printInfo
from libs.gfp_library_0 import *
from protocols.DMTP.DMTP_Message import *
from db.db_lib import *
def ip_to_bytes(ip):
    return socket.inet_aton(ip)
def ip_from_int(ip):
    return socket.inet_ntoa(ip)
def translate_version(version):
    return int("".join([str(int(i)) for i in version.split(".")]))
NODE_CONFIG = {
    "software_version": "0.0.1",
    "minimal_version": "0.0.1",
    "address": "127.0.0.1",
    "port": 5000,
    "services": 0,
    "height": 0,
    "token":sha512(1)
}
NODES_LIST = ["127.0.0.1:4550","127.0.0.1:4551","127.0.0.1:4552"]
def config_to_bytes(config):
    data = {
        "software_version":translate_version(config["software_version"]).to_bytes(4,byteorder="big"),
        "address":ip_to_bytes(config["address"]),
        "port":config["port"].to_bytes(2,byteorder="big"),
        "services":config["services"].to_bytes(8,byteorder="big"),
        "height":config["height"].to_bytes(8,byteorder="big"),
        "token":bytes.fromhex(config["token"])
    }
    return data
async def handle_client(client):
    loop = asyncio.get_event_loop()

    packet:bytes = b""

    request = (await loop.sock_recv(client, 12))
    packet += request

    data_size = int.from_bytes(request[8:12], "big")
    data = (await loop.sock_recv(client, data_size+8))
    operation = int(packet[4:8].hex(),16)
    packet += data

    printInfo("RECEIVED PACKET OPERATION: " + str(hex(operation)),light=True)

    if operation == 0x1000:
        print("ping")
        DMTP_packet_PING().parse(packet)
        await loop.sock_sendall(client, DMTP_packet_PONG().build())
    elif operation == 0x1004:
        print("getaddr")
        DMTP_packet_GETADDR().parse(packet)
        await loop.sock_sendall(client, DMTP_packet_ADDR().build([{"ip": 0, "port": 0}, {"ip": 0, "port": 0}]))
    elif operation == 0x1002:
        print("version")
        NODE_DATA = DMTP_packet_VERSION().parse(packet)
        if NODE_DATA["software_version"]<translate_version(NODE_CONFIG["minimal_version"]):
            await loop.sock_sendall(client, DMTP_packet_VERDEC().build())
            return
        self_data = config_to_bytes(NODE_CONFIG)
        version_packet = DMTP_packet_VERSION().build(self_data["software_version"],self_data["address"],self_data["port"],self_data["services"],self_data["height"],self_data["token"])
        await loop.sock_sendall(client, version_packet)


        data = await recv_packet(client)
        print(data)
        if data["operation"] == 0x1011:
            # ANOTHER NODE DECLINE MY VERSION
            print("verdec")
            return
        # VERSION SUCCESS: ADDING NODE TO LIST
        print(NODE_DATA)
        db.db_lib.db_insert("INSERT INTO peers(address,port,version,height,token) VALUES("+str(NODE_DATA["address"])+","+str(NODE_DATA["port"])+","+str(NODE_DATA["software_version"])+","+str(NODE_DATA["height"])+",'"+NODE_DATA["token"].hex()+"')")
    elif operation == 0x1007:
        print("inv")
        data = DMTP_packet_INV().parse(packet)
        if data["objects_type"] == 0x01:
            mempool_txids = db_select("SELECT txid FROM mempool")
            mempool_txids = [i["txid"] for i in mempool_txids]
            tx_to_ask = []
            for i in data["objects"]:
                if i not in mempool_txids:
                    tx_to_ask.append(i)
            print(tx_to_ask)
        elif data["objects_type"] == 0x02:
            print("block")
        print(data)
    elif operation == 0x1010:
        print("tx")
        print(DMTP_packet_TX().parse(packet))
        #TODO VALIDATING TX

        # PROPAGATING TX
        for i in NODES_LIST:
            addr = (i.split(":")[0],int(i.split(":")[1]))
            another_node = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            another_node.connect(addr)
            another_node.sendall(packet)
            another_node.close()
    client.close()
async def recv_packet(client):
    loop = asyncio.get_event_loop()

    packet: bytes = b""

    request = (await loop.sock_recv(client, 12))
    packet += request

    data_size = int.from_bytes(request[8:12], "big")
    data = (await loop.sock_recv(client, data_size + 8))
    operation = int(packet[4:8].hex(), 16)
    packet += data

    return DMTP_Message().parse(packet)

async def run_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('localhost', 5000))
    server.listen(8)
    server.setblocking(False)

    loop = asyncio.get_event_loop()

    while True:
        client, _ = await loop.sock_accept(server)
        loop.create_task(handle_client(client))

asyncio.run(run_server())
