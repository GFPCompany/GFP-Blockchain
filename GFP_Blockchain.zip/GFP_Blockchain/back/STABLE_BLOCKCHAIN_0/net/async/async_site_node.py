import asyncio
import json
import os
import random
import socket
import sys
import time
from threading import Thread

import base58



sys.path.append("../../")
sys.path.append("../../../")
sys.path.append("../")
sys.path.append("../../libs/")
sys.path.append("../../protocols/")
sys.path.append("../../db")
sys.path.append("../../db/scripts")
sys.path.append("../../objects")

from db.db_lib import *
from libs.beauti_cli import *
from libs.gfp_library_0 import sha512
from protocols.DMTP.DMTP_protocol import *
from objects.block import Block

def ip_to_bytes(ip):
    return socket.inet_aton(ip)
def ip_from_int(ip):
    return socket.inet_ntoa(ip)
def translate_version(version):
    return int("".join([str(int(i)) for i in version.split(".")]))
def config_to_bytes(config):
    data = {
        "software_version":translate_version(config["software_version"]).to_bytes(4,byteorder="big"),
        "address":ip_to_bytes(config["address"]),
        "port":config["port"].to_bytes(2,byteorder="big"),
        "services":config["services"].to_bytes(8,byteorder="big"),
        "height":config["height"].to_bytes(8,byteorder="big"),
        "token":bytes.fromhex(config["token"]),
        "dns_seed":"127.0.0.1:4040"
    }
    return data
class GFP_Async_Node:
    def __init__(self,NODE_CONFIG:dict,token):
        self.NODE_CONFIG = NODE_CONFIG
        self.NODES_LIST = []
        self.token = token

        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.setup_env()
        self.setup_site_env()
        self.mempool = []
    def bind(self,ip,port):
        self.server_socket.bind((ip, port))
        self.server_socket.listen(100)
        self.server_socket.setblocking(False)
    async def run(self):
        loop = asyncio.get_event_loop()
        await self.ask_dns_seed()
        printOk("NODE STARTED ON " + ip_from_int(self.NODE_CONFIG["address"].to_bytes(4,byteorder="big")) + ":" + str(self.NODE_CONFIG["port"]),light=True)
        printOk("LISTENING CLIENTS")
        while True:
            client, _ = await loop.sock_accept(self.server_socket)
            loop.create_task(self.handle_client(client))
    async def handle_client(self,client:socket.socket):
        loop = asyncio.get_event_loop()

        packet:bytes = await self.recv_packet(client)
        operation = int(packet[4:8].hex(), 16)

        printInfo("RECEIVED PACKET OPERATION: " + operation.to_bytes(4,byteorder="big").hex(), light=True)

        if operation == 0x0000:
            print("ping")
            await loop.sock_sendall(client, DMTP_packet_PONG().build(self.token))
        elif operation == 0x0002:
            print("version")
            NODE_DATA = DMTP_packet_VERSION().parse(packet)
            await loop.sock_sendall(client, DMTP_packet_VERSION().build(
                self.NODE_CONFIG["software_version"],
                self.NODE_CONFIG["protocol_version"],
                self.NODE_CONFIG["address"],
                self.NODE_CONFIG["port"],
                self.NODE_CONFIG["services"],
                self.NODE_CONFIG["height"],
                self.token
            )
                                    )
            data = await self.recv_packet(client)

            if int(data[4:8].hex(), 16) == 0x0004:
                print("verdec")
                return
            elif int(data[4:8].hex(), 16) == 0x0003:
                print("verack")
                if self.NODE_CONFIG["software_version"] > NODE_DATA["software_version"]:
                    await loop.sock_sendall(client, DMTP_packet_VERDEC().build(self.token)) #sending verdec
                    return
                #sending verack
                msg = DMTP_packet_VERACK().build(self.token)
                await loop.sock_sendall(client, msg)
                return
        elif operation == 0x0005:
            print("getaddr")
            DMTP_packet_GETADDR().parse(packet)
            await loop.sock_sendall(client, DMTP_packet_ADDR().build([{"ip": 0, "port": 0}, {"ip": 0, "port": 0}], self.token))
            #TODO send addresses
        elif operation == 0x2000:
            print("inv")
            data = DMTP_packet_INV().parse(packet)

            if data["data"]["objects_type"] == 0x0000:  # 0x0000 = block
                BLOCKS_IN_LOCAL_COPY = db_select("SELECT hash FROM `gfp_node_"+self.token.hex()+"`.`raw_blocks`")
                BLOCKS_IN_LOCAL_COPY = [i["hash"] for i in BLOCKS_IN_LOCAL_COPY]

                requires_blocks = []
                for i in data["data"]["objects"]:
                    if i not in BLOCKS_IN_LOCAL_COPY:
                        requires_blocks.append(i)

                printInfo("ASKING FOR BLOCKS    "+" | ".join([i.hex() for i in requires_blocks]),light=True)
                if len(requires_blocks) == 0:
                    printWarning("NO BLOCKS REQUIRED TO ASK AFTER INV",light=True)
                    msg = DMTP_packet_GETDATA().build(0x0000, [], self.token)
                    await loop.sock_sendall(client, msg)
                    return
                msg = DMTP_packet_GETDATA().build(0x0000, [i.hex() for i in requires_blocks], self.token)
                await loop.sock_sendall(client, msg)
                data = await self.recv_packet(client)
                if int(data[4:8].hex(), 16) == 0x2003:
                    print("data")
                    data = DMTP_packet_DATA().parse(data)
                    blocks_insert_template = "INSERT INTO `gfp_node_" + self.token.hex() + "`.`raw_blocks`(`hash`,`data`) VALUES "
                    for i in data["data"]:
                        object_type = i[:4]
                        if int(object_type.hex(), 16) == 0x0000:
                            block_hash = i[4:36]
                            blocks_insert_template += "(X'" + block_hash.hex() + "',X'" + i.hex() + "'),"
                    blocks_insert_template = blocks_insert_template[:-1]
                    if not blocks_insert_template.endswith("VALUE"):
                        db_insert(blocks_insert_template)
                        printOk("BLOCKS ADDED TO DATABASE")
            elif data["data"]["objects_type"] == 0x0001: # 0x0001 = transaction
                print("transaction")
                requires_transactions = []
                self_mempool_transactions = [sha256(bytes.fromhex(sha256(i))) for i in self.mempool]
                for i in data["data"]["objects"]:
                    if i not in self_mempool_transactions:
                        requires_transactions.append(i)
                        print(i)

                if len(requires_transactions) == 0:
                    printWarning("NO TRANSACTIONS REQUIRED TO ASK AFTER INV",light=True)
                    msg = DMTP_packet_GETDATA().build(0x0001, [], self.token)
                    await loop.sock_sendall(client, msg)
                    return
                msg = DMTP_packet_GETDATA().build(0x0001, [i.hex() for i in requires_transactions], self.token)
                await loop.sock_sendall(client, msg)

                data = await self.recv_packet(client)
                if int(data[4:8].hex(), 16) == 0x2003:
                    print("data")
                    data = DMTP_packet_DATA().parse(data)
                    for i in data["data"]:
                        object_type = i[:4]
                        if int(object_type.hex(), 16) == 0x0001:
                            self.mempool.append(i)
                            await self.mempool_agent()
                printOk("TRANSACTIONS ADDED TO MEMPOOL COUNT: " + str(len(requires_transactions))+" MEMPOOL SIZE: "+str(len(self.mempool)),light=True)
        client.close()

    async def ask_dns_seed(self):
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.settimeout(0.5)
        try:
            client_socket.connect((self.NODE_CONFIG["dns_seed"].split(":")[0], int(self.NODE_CONFIG["dns_seed"].split(":")[1])))
        except:
            printError("DNS SEED OFFLINE",light=True)
            return

        msg = DMTP_packet_VERSION().build(
            self.NODE_CONFIG["software_version"],
            self.NODE_CONFIG["protocol_version"],
            self.NODE_CONFIG["address"],
            self.NODE_CONFIG["port"],
            self.NODE_CONFIG["services"],
            self.NODE_CONFIG["height"],
            self.token
        )

        client_socket.send(msg)
        data = await self.recv_packet(client_socket)
        client_socket.sendall(DMTP_packet_VERACK().build(self.token))
        data = await self.recv_packet(client_socket)
        print(data)

        client_socket.close()
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((self.NODE_CONFIG["dns_seed"].split(":")[0], int(self.NODE_CONFIG["dns_seed"].split(":")[1])))
        client_socket.sendall(DMTP_packet_GETADDR().build(self.token))
        data = await self.recv_packet(client_socket)
        print(data.hex())
        print(DMTP_packet_ADDR().parse(data))
        self.NODES_LIST = DMTP_packet_ADDR().parse(data)["data"]["address"]

        return data

    async def recv_packet(self,client):
        loop = asyncio.get_event_loop()

        rcv: bytes = b""

        request = (await loop.sock_recv(client, 12))
        rcv += request

        data_size = int.from_bytes(request[8:12], "big")
        data = (await loop.sock_recv(client, data_size + 8+16))
        rcv += data
        return rcv
    def utxo_agent(self,block):
        printInfo("UTXO AGENT CALLED",light=True)

        block = Block().from_raw_to_json(block)
        txs = block["txs"]
        transactions = []
        for i in txs:
            i = bytes.fromhex(i)
            tx_type = i[4:6]
            if int(tx_type.hex(), 16) == 0x0000:  # P2PKH
                tx = GFP_Transaction_P2PKH().raw_to_json(i)
                tx["txid"] = sha256(bytes.fromhex(sha256(i)))
                transactions.append(tx)
            elif int(tx_type.hex(), 16) == 0x0001:  # COINBASE
                tx = GFP_Transaction_coinbase().raw_to_json(i)
                tx["txid"] = sha256(bytes.fromhex(sha256(i)))
                transactions.append(tx)
        # TODO CHECKING OLDS UTXO
        UTXO = db_select("SELECT * FROM `gfp_site_node_" + self.token.hex() + "`.`utxo`")
        for i in range(len(UTXO)):
            utxo_txid = UTXO[i]["txid"]
            utxo_outputs = UTXO[i]["outputs"]

            for tx in transactions:
                if utxo_txid in [k["txid"] for k in tx["inputs"]]:
                    used_vout = [k["vout"] for k in tx["inputs"] if k["txid"] == utxo_txid][0]
                    # print("FOUND USED UTXO",utxo_outputs[used_vout])
                    utxo_outputs.pop(used_vout)
            if len(utxo_outputs) == 0:
                UTXO.pop(i)

        # TODO ADDING NEW UTXO
        for i in transactions:
            to_utxo = {}
            to_utxo["txid"] = i["txid"]
            to_utxo["outputs"] = i["outputs"]
            UTXO.append(to_utxo)


        # TODO Adding new utxos

        INSERT_TEMPLATE = "INSERT INTO `gfp_site_node_" + self.token.hex() + "`.`utxo` (txid,type,timestamp,inputs,outputs) VALUES"
        for i in range(len(txs)):
            tx_type = txs[i][4:6]
            if int(tx_type.hex(), 16) == 0x00: #P2PKH
                raw_tx = txs[i]
                txid = sha256(bytes.fromhex(sha256(raw_tx)))
                tx = GFP_Transaction_P2PKH().raw_to_json(txs[i])
                INSERT_TEMPLATE += " ('" + txid + "',0x0000," + str(tx["timestamp"]) + ",'" + json.dumps(tx["inputs"],ensure_ascii=False) + "','" + json.dumps(tx["outputs"],ensure_ascii=False) + "'),"
            elif int(tx_type.hex(), 16) == 0x01: #coinbase
                raw_tx = txs[i]
                txid = sha256(bytes.fromhex(sha256(raw_tx)))
                tx = GFP_Transaction_coinbase().raw_to_json(txs[i])
                INSERT_TEMPLATE += " ('" + txid + "',0x0001," + str(tx["timestamp"]) + ",'" + json.dumps(tx["inputs"],ensure_ascii=False) + "','" + json.dumps(tx["outputs"],ensure_ascii=False) + "'),"

        INSERT_TEMPLATE = INSERT_TEMPLATE[:-1]
        res = db_insert(INSERT_TEMPLATE)
        printInfo("UTXO UPDATED, RESULT: "+str(res),light=True)

    async def mempool_agent(self):
        printInfo("MEMPOOL AGENT CALLED",light=True)
        mempool_data = b""
        for i in self.mempool:
            mempool_data +=i

        if len(mempool_data) >=256:  # 2Kbyte mempool limit
            #start mining
            printInfo("STARTING MINING BECAUSE MEMPOOL IS TOO BIG",light=True)
            b = Block()
            last_hash = db_select("SELECT hash FROM raw_blocks WHERE id=(SELECT MAX(id) FROM raw_blocks)")[0]["hash"]
            b.create(last_hash,0x10000,self.mempool)
            b.mine()
            b.to_db()
            b = b.to_raw()
            self.utxo_agent(b)
            self.mempool = []

            msg = DMTP_packet_INV().build(0x0000,[b[4:36]],self.token)
            printInfo("BLOCK MINED, BROADCASTING")
            for i in self.NODES_LIST:
                client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                client_socket.connect((ip_from_int(i["ip"].to_bytes(4, "big")), i["port"]))
                client_socket.sendall(msg)
                client_socket.close()

    def setup_env(self):
        db_name = "gfp_node_"+self.token.hex()

        databases = db_select("SHOW DATABASES")
        databases = [i["Database"] for i in databases]

        if db_name in databases:
            return

        script = open("../../db/scripts/make_node_env.sql","r")

        script_data = script.read()
        script.close()
        db_script = script_data.replace(":db_name",db_name)

        for i in db_script.split(";"):
            if i != "":
                db_insert(i)
    def setup_site_env(self):
        db_name = "gfp_site_node_"+self.token.hex()

        databases = db_select("SHOW DATABASES")
        databases = [i["Database"] for i in databases]

        if db_name in databases:
            return

        script = open("../../db/scripts/make_site_node_env.sql","r")

        script_data = script.read()
        script.close()
        db_script = script_data.replace(":db_name",db_name)

        for i in db_script.split(";"):
            if i != "":
                db_insert(i)

NODE_CONFIG = {
    "software_version": 1,
    "protocol_version": 0,
    "minimal_version": 1,
    "services": 0,
    "height": 0,
    "token": md5(88),
    "address": int(ip_to_bytes("127.0.0.1").hex(),16),
    "port": 4560,
    "dns_seed": "127.0.0.1:4040"
}
a = GFP_Async_Node(NODE_CONFIG,bytes.fromhex(md5(88)))
a.bind("127.0.0.1", 4560)
asyncio.run(a.run())

