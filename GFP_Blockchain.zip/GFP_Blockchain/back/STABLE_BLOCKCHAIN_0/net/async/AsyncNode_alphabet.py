# Created by Greg Feov, May 2024
# AsyncNode_alphabet.py
# github.com/GFPCompany
import json
import sys

import base58
import requests
from flask import Flask


sys.path.append("../../")
sys.path.append("../../../")
sys.path.append("../")
sys.path.append("../../libs/")
sys.path.append("../../protocols/")
sys.path.append("../../db")
sys.path.append("../../db/scripts")
sys.path.append("../../objects")
import asyncio
import socket

from db.db_lib import db_select
from libs.gfp_library_0 import *
from libs.beauti_cli import *
from objects.block import Block
from objects.transaction import *
from protocols.DMTP.DMTP_protocol import *
from protocols.DMTP.DMTP_protocol import *


def ip_to_bytes(ip):
    return socket.inet_aton(ip)
def ip_from_int(ip):
    return socket.inet_ntoa(ip)
def PickUpTransactionFromChain(db_name,txid):
    block = db_select("SELECT `data` FROM `"+db_name+"`.`raw_blocks`")
    block = [i["data"] for i in block]
    for i in block:
        i = Block().from_raw_to_json(i)
        for j in i["txs"]:
            if sha256(bytes.fromhex(sha256(bytes.fromhex(j)))) == txid:
                j = bytes.fromhex(j)
                tx_type = int(j[4:6].hex(), 16)
                if tx_type == 0x0000:
                    tx = GFP_Transaction_P2PKH()
                    tx = tx.raw_to_json(j)
                    tx["txid"] = txid
                    return j
                elif tx_type == 0x0001:
                    tx = GFP_Transaction_coinbase()
                    tx = tx.raw_to_json(j)
                    tx["txid"] = txid
                    return j

NODE_CONFIG = {
    "network": {
        "name": "TEST",
        "dns_seed": {
            "ip": "127.0.0.1",
            "port": 4040
        }
    },
    "node": {
        "token": md5(int(sys.argv[1])),
        "name": "Alphabet",
        "ip": "127.0.0.1",
        "port": 4550+int(sys.argv[1]),
        "features": [
            "miner",
            "storage",
            "full",
            "site"
        ],
        "miner": {
            "address": ""
        },
        "site":{
            "ip": "192.168.1.64",
            "port": 8920
        },
        "data": {
            "software": {
                "name": "TEST",
                "version": 1,
                "minimal_version": 5,
            },
            "protocol": {
                "version": 0
            }
        }
    }
}


class GFP_AsyncNode_alphabet:
    def bind_socket(self):
        self.socket.bind((self.ip, self.port))
        self.socket.listen(100)

    def setup_env(self):
        databases = db_select("SHOW DATABASES")
        databases = [i["Database"] for i in databases]

        if self.db_name in databases:
            return

        script = open("../db/scripts/make_node_env.sql", "r")

        script_data = script.read()
        script.close()
        db_script = script_data.replace(":db_name", self.db_name)

        for i in db_script.split(";"):
            if i != "":
                db_insert(i)
        printInfo("SETUP->: CREATED MySQL ENVIRONMENT | database: 'gfp_node_" + self.token.hex() + "'", light=True)
    def setup_site_env(self):

        databases = db_select("SHOW DATABASES")
        databases = [i["Database"] for i in databases]

        if self.db_name in databases:
            return

        script = open("../db/scripts/make_site_node_env.sql", "r")

        script_data = script.read()
        script.close()
        db_script = script_data.replace(":db_name", self.db_name)

        for i in db_script.split(";"):
            if i != "":
                db_insert(i)

    def setup_miner_config(self):
        if len(db_select("SELECT JSON_EXTRACT(config,'$.miner') FROM `"+self.db_name+"`.`config`"))==0:
            private_key = GFP_PrivateKey().generate()
            public_key = GFP_PublicKey().generate(private_key).to_GFP_P2PKH(True).decode("utf-8")
            private_key = private_key.to_GFP().decode("utf-8")

            config = {
                "private_key": private_key,
                "public_key": public_key
            }
            #update config with json_set to .miner
            db_insert("INSERT INTO `" + self.db_name + "`.`config` (`config`) VALUES ('{\"miner\": " + json.dumps(config) + "}')")

    def __init__(self, config: dict):
        self.config = config

        self.token = bytes.fromhex(config["node"]["token"])
        self.ip = config["node"]["ip"]
        self.port = config["node"]["port"]
        self.nodes = []
        self.mempool = []

        self.SERVICES = []  # TODO HANDLE THIS

        self.miner_address = config["node"]["miner"]["address"]

        self.db_name = "gfp_node_" + self.token.hex()

        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if "site" in config["node"]["features"]:
            self.setup_site_env()
        else:
            self.setup_env()
        if "miner" in config["node"]["features"]:
            self.setup_miner_config()
        self.bind_socket()




    async def run(self):
        loop = asyncio.get_event_loop()
        await self.ask_dns_seed()
        printOk("NODE STARTED ON " + (self.ip) + ":" + str(self.port), light=True)
        #await self.create_empty_block(100)
        await self.create_empty_block(500)
        while True:
            client, _ = await loop.sock_accept(self.socket)
            loop.create_task(self.handle_client(client))

    async def handle_client(self, client: socket.socket):
        loop = asyncio.get_event_loop()
        packet: bytes = await self.recv_packet(client)
        operation = int(packet[4:8].hex(), 16)

        printInfo("RECEIVED PACKET OPERATION: " + operation.to_bytes(4, byteorder="big").hex(), light=True)

        if operation == 0x0000:
            print("ping")
            await loop.sock_sendall(client, DMTP_packet_PONG().build(self.token))
        elif operation == 0x0002:
            print("version")
            NODE_DATA = DMTP_packet_VERSION().parse(packet)
            await loop.sock_sendall(client, DMTP_packet_VERSION().build(
                self.config["node"]["data"]["software"]["version"],
                self.config["node"]["data"]["protocol"]["version"],
                int(ip_to_bytes(self.config["node"]["ip"]).hex(), 16),
                self.config["node"]["port"],
                1,
                0,
                self.token
            )
                                    )
            data = await self.recv_packet(client)

            if int(data[4:8].hex(), 16) == 0x0004:
                print("verdec")
                return
            elif int(data[4:8].hex(), 16) == 0x0003:
                print("verack")
                if self.config["node"]["data"]["software"]["minimal_version"] > NODE_DATA["software_version"]:
                    await loop.sock_sendall(client, DMTP_packet_VERDEC().build(self.token))  # sending verdec
                    return
                # sending verack
                msg = DMTP_packet_VERACK().build(self.token)
                await loop.sock_sendall(client, msg)
                return
        elif operation == 0x0005:
            print("getaddr")
            DMTP_packet_GETADDR().parse(packet)
            await loop.sock_sendall(client,
                                    DMTP_packet_ADDR().build([{"ip": 0, "port": 0}, {"ip": 0, "port": 0}], self.token))
            # TODO send addresses
        elif operation == 0x2000:
            print("inv")
            data = DMTP_packet_INV().parse(packet)

            if data["data"]["objects_type"] == 0x0000:
                BLOCKS_IN_LOCAL_COPY = db_select("SELECT hash FROM `gfp_node_" + self.token.hex() + "`.`raw_blocks`")
                BLOCKS_IN_LOCAL_COPY = [i["hash"] for i in BLOCKS_IN_LOCAL_COPY]

                requires_blocks = []
                for i in data["data"]["objects"]:
                    if i not in BLOCKS_IN_LOCAL_COPY:
                        requires_blocks.append(i)

                printInfo("ASKING FOR BLOCKS    " + " | ".join([i.hex() for i in requires_blocks]), light=True)
                if len(requires_blocks) == 0:
                    printWarning("NO BLOCKS REQUIRED TO ASK AFTER INV", light=True)
                    msg = DMTP_packet_GETDATA().build(0x0000, [], self.token)
                    await loop.sock_sendall(client, msg)
                    return
                msg = DMTP_packet_GETDATA().build(0x0000, [i.hex() for i in requires_blocks], self.token)
                await loop.sock_sendall(client, msg)
                data = await self.recv_packet(client)
                if int(data[4:8].hex(), 16) == 0x2003:
                    print("data")
                    data = DMTP_packet_DATA().parse(data)
                    blocks_insert_template = "INSERT INTO `gfp_node_" + self.token.hex() + "`.`raw_blocks`(`hash`,`data`) VALUES "
                    for i in data["data"]:
                        object_type = i[:4]
                        if int(object_type.hex(), 16) == 0x0000:
                            block_hash = i[4:36]
                            await self.utxo_agent(i)
                            blocks_insert_template += "(X'" + block_hash.hex() + "',X'" + i.hex() + "'),"
                    blocks_insert_template = blocks_insert_template[:-1]
                    if not blocks_insert_template.endswith("VALUE"):
                        db_insert(blocks_insert_template)
                        printOk("BLOCKS ADDED TO DATABASE")
            elif data["data"]["objects_type"] == 0x0001:
                print("transaction")
                requires_transactions = []
                self_mempool_transactions = [sha256(bytes.fromhex(sha256(i))) for i in self.mempool]
                for i in data["data"]["objects"]:
                    if i not in self_mempool_transactions:
                        requires_transactions.append(i)
                        print(i)

                if len(requires_transactions) == 0:
                    printWarning("NO TRANSACTIONS REQUIRED TO ASK AFTER INV", light=True)
                    msg = DMTP_packet_GETDATA().build(0x0001, [], self.token)
                    await loop.sock_sendall(client, msg)
                    return
                msg = DMTP_packet_GETDATA().build(0x0001, [i.hex() for i in requires_transactions], self.token)
                await loop.sock_sendall(client, msg)

                data = await self.recv_packet(client)
                if int(data[4:8].hex(), 16) == 0x2003:
                    print("data")
                    data = DMTP_packet_DATA().parse(data)
                    for i in data["data"]:
                        object_type = i[:4]
                        if int(object_type.hex(), 16) == 0x0001:
                            self.mempool.append(i)
                            await self.mempool_agent()
                printOk(
                    "TRANSACTIONS ADDED TO MEMPOOL COUNT: " + str(len(requires_transactions)) + " MEMPOOL SIZE: " + str(
                        len(self.mempool)), light=True)
        elif operation == 0x2001:
            print("getdata")
            packet = DMTP_packet_GETDATA().parse(packet)
            if packet["data"]["objects_type"] == 0x0000:
                print("blocks")
                required_blocks = db_select("SELECT hash FROM `gfp_node_" + self.token.hex() + "`.`raw_blocks` WHERE hash IN (" + ", ".join(["X'" + i.hex() + "'" for i in packet["data"]["objects"]]) + ")")
                required_blocks = [db_select("SELECT data FROM `gfp_node_" + self.token.hex() + "`.`raw_blocks` WHERE hash=X'" + i["hash"].hex() + "'")[0]["data"] for i in required_blocks]
                msg = DMTP_packet_DATA().build(0x0,required_blocks, self.token)
                await loop.sock_sendall(client, msg)
            elif packet["data"]["objects_type"] == 0x0001:
                print("transactions")
                txs = []
                for i in packet["data"]["objects"]:
                    tx = PickUpTransactionFromChain(self.db_name,i.hex())
                    if tx:
                        txs.append(tx)
                msg = DMTP_packet_DATA().build(0x1, txs, self.token)
                await loop.sock_sendall(client, msg)
        client.close()

    async def recv_packet(self,client):
        loop = asyncio.get_event_loop()

        rcv: bytes = b""

        request = (await loop.sock_recv(client, 12))
        rcv += request

        data_size = int.from_bytes(request[8:12], "big")
        data = (await loop.sock_recv(client, data_size + 8+16))
        rcv += data
        return rcv
    async def ask_dns_seed(self):
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.settimeout(0.5)
        try:
            client_socket.connect(
                (self.config["network"]["dns_seed"]["ip"], int(self.config["network"]["dns_seed"]["port"])))
        except:
            printError("DNS SEED OFFLINE", light=True)
            return

        msg = DMTP_packet_VERSION().build(
            self.config["node"]["data"]["software"]["version"],
            self.config["node"]["data"]["protocol"]["version"],
            int(ip_to_bytes(self.config["node"]["ip"]).hex(), 16),
            self.config["node"]["port"],
            1,
            0,
            self.token
        )

        client_socket.send(msg)
        data = await self.recv_packet(client_socket)
        client_socket.sendall(DMTP_packet_VERACK().build(self.token))
        data = await self.recv_packet(client_socket)

        client_socket.close()
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect(
            (self.config["network"]["dns_seed"]["ip"], int(self.config["network"]["dns_seed"]["port"])))
        client_socket.sendall(DMTP_packet_GETADDR().build(self.token))
        data = await self.recv_packet(client_socket)
        self.nodes += DMTP_packet_ADDR().parse(data)["data"]["address"]
        printOk("DNS SEED ONLINE: nodes list updated", light=True)
        return data

    async def utxo_agent(self,block):
        printInfo("UTXO AGENT CALLED",light=True)

        UTXO = db_select("SELECT * FROM `gfp_node_" + self.token.hex() + "`.`utxo`")
        UTXO = [{"txid": i["txid"], "outputs": json.loads(i["outputs"])} for i in UTXO]

        block = Block().from_raw_to_json(block)
        txs = block["txs"]
        transactions = []
        for i in txs:
            i = bytes.fromhex(i)
            tx_type = i[4:6]
            if int(tx_type.hex(), 16) == 0x0000:  # P2PKH
                tx = GFP_Transaction_P2PKH().raw_to_json(i)
                tx["txid"] = sha256(bytes.fromhex(sha256(i)))
                transactions.append(tx)
            elif int(tx_type.hex(), 16) == 0x0001:  # COINBASE
                tx = GFP_Transaction_coinbase().raw_to_json(i)
                tx["txid"] = sha256(bytes.fromhex(sha256(i)))
                transactions.append(tx)
        # TODO CHECKING OLDS UTXO
        utxo_remove_indexes = []
        for i in range(len(UTXO)):
            utxo_txid = UTXO[i]["txid"]
            utxo_outputs = UTXO[i]["outputs"]

            for tx in transactions:
                if utxo_txid in [k["txid"] for k in tx["inputs"]]:
                    used_vout = [k["vout"] for k in tx["inputs"] if k["txid"] == utxo_txid][0]
                    # print("FOUND USED UTXO",utxo_outputs[used_vout])
                    try:
                        utxo_outputs.pop(used_vout)
                    except:
                        pass
            if len(utxo_outputs) == 0:
                utxo_remove_indexes.append(i)

        for i in utxo_remove_indexes[::-1]:
            UTXO.pop(i)

        # TODO ADDING NEW UTXO
        for i in transactions:
            print(i)
            to_utxo = {}
            to_utxo["txid"] = i["txid"]
            for k in range(len(i["outputs"])):
                i["outputs"][k]["vout"] = k
            to_utxo["outputs"] = i["outputs"]
            UTXO.append(to_utxo)

        INSERT_TEMPLATE = "INSERT INTO `" + self.db_name + "`.`utxo` (`txid`, `outputs`) VALUES "

        _metrics = 0
        for i in UTXO:
            _metrics += 1
            tempered = json.dumps(i["outputs"], ensure_ascii=False)
            tempered = tempered[1:-1]
            if not tempered.startswith("["):
                tempered = "[" + tempered + "]"
            INSERT_TEMPLATE += "('" + i["txid"] + "','" + str(tempered) + "'),"
        if _metrics > 0:
            INSERT_TEMPLATE = INSERT_TEMPLATE[:-1]
            db_insert("DELETE FROM `" + self.db_name + "`.`utxo`")
            db_insert(INSERT_TEMPLATE)
        printInfo("UTXO AGENT DONE, _METRICS(UTXO WRITEN): " + str(_metrics) + "",light=True)

    async def mempool_agent(self):
        printInfo("MEMPOOL AGENT CALLED",light=True)
        mempool_data = b""
        for i in self.mempool:
            mempool_data += i

        if len(mempool_data) >=40:  # 2Kbyte mempool limit
            #start mining
            printInfo("STARTING MINING BECAUSE MEMPOOL IS TOO BIG",light=True)

            miner_public_address = db_select("SELECT JSON_UNQUOTE(JSON_EXTRACT(config, '$.miner.public_key')) as address FROM `" + self.db_name+ "`.`config`")[0]["address"]
            miner_public_address = base58.b58decode(miner_public_address.encode("utf-8"))
            coinbase_tx = GFP_Transaction_coinbase()
            coinbase_tx = coinbase_tx.create([{"lock":miner_public_address.hex(),"amount":0x64}],b"GFP Miner")[0]

            txs = [coinbase_tx]
            txs += self.mempool

            b = Block()
            last_hash = db_select("SELECT hash FROM `" + self.db_name + "`.`raw_blocks` WHERE id=(SELECT MAX(id) FROM raw_blocks)")
            if len(last_hash) == 0:
                last_hash = b"\x00" * 32
            else:
                last_hash = last_hash[0]["hash"]
            b.create(last_hash,0x10000,txs)
            b.mine()
            printInfo("BLOCK MINED: " + b.hash.hex(),light=True)
            b.to_db(self.db_name)
            b = b.to_raw()
            await self.utxo_agent(b)
            if "site" in self.config["node"]["features"]:
                try:
                    await self.inform_site(b, db_select("SELECT MAX(id) as id FROM raw_blocks")[0]["id"])
                except:
                    pass
            self.mempool = []

            msg = DMTP_packet_INV().build(0x0000,[b[4:36]],self.token)
            printInfo("BLOCK MINED, BROADCASTING")
            for i in self.nodes:
                client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                client_socket.connect((ip_from_int(i["ip"].to_bytes(4, "big")), i["port"]))
                client_socket.sendall(msg)
                client_socket.close()
    async def inform_site(self,block,block_height):
        url = "http://" + self.config["node"]["site"]["ip"] + ":" + str(self.config["node"]["site"][
            "port"]) + "/api/system/calculate_balance"
        data = {
            "data": {
                "block": block.hex(),
                "block_height": block_height
            }
        }

        r = requests.post(url, json=data)

        print(r.text)
    async def create_empty_block(self,reward):
        miner_public_address = db_select(
            "SELECT JSON_UNQUOTE(JSON_EXTRACT(config, '$.miner.public_key')) as address FROM `" + self.db_name + "`.`config`")[
            0]["address"]
        miner_public_address = base58.b58decode(miner_public_address.encode("utf-8"))
        coinbase_tx = GFP_Transaction_coinbase()
        coinbase_tx = coinbase_tx.create([{"lock": miner_public_address.hex(), "amount": reward}], b"GFP Miner")[0]

        txs = [coinbase_tx]

        b = Block()
        last_hash = db_select("SELECT hash FROM `" + self.db_name + "`.`raw_blocks` WHERE id=(SELECT MAX(id) FROM `" + self.db_name + "`.`raw_blocks`)")
        if len(last_hash) == 0:
            last_hash = b"\x00" * 32
        else:
            last_hash = last_hash[0]["hash"]
        b.create(last_hash,0x10000,txs)
        b.mine()
        b.to_db(self.db_name)
        await self.utxo_agent(b.to_raw())
        if "site" in self.config["node"]["features"]:
            try:
                await self.inform_site(b.to_raw(), db_select("SELECT MAX(id) as id FROM raw_blocks")[0]["id"])
            except:
                pass
        b = b.to_raw()
        return b

def start():
    node = GFP_AsyncNode_alphabet(NODE_CONFIG)
    asyncio.run(node.run())

start()