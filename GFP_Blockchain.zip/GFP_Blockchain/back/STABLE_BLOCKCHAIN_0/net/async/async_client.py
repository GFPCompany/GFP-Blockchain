import asyncio, socket

from libs.gfp_library_0 import *
from net.test_client import ip_to_bytes
from protocols.DMTP.DMTP_Message import *


def translate_version(version):
    return int("".join([str(int(i)) for i in version.split(".")]))


NODE_CONFIG = {
    "software_version": "0.0.6",
    "address": "127.0.0.1",
    "port": 5000,
    "services": 0,
    "height": 0,
    "token": sha512(1)
}


def config_to_bytes(config):
    data = {
        "software_version": translate_version(config["software_version"]).to_bytes(4, byteorder="big"),
        "address": ip_to_bytes(config["address"]),
        "port": config["port"].to_bytes(2, byteorder="big"),
        "services": config["services"].to_bytes(8, byteorder="big"),
        "height": config["height"].to_bytes(8, byteorder="big"),
        "token": bytes.fromhex(config["token"])
    }
    return data


async def handle_client(client):
    loop = asyncio.get_event_loop()

    packet: bytes = b""

    request = (await loop.sock_recv(client, 12))
    packet += request

    data_size = int.from_bytes(request[8:12], "big")
    data = (await loop.sock_recv(client, data_size + 8))
    operation = int(packet[4:8].hex(), 16)
    packet += data

    if operation == 0x1000:
        print("ping")
        DMTP_packet_PING().parse(packet)
        await loop.sock_sendall(client, DMTP_packet_PONG().build())
    elif operation == 0x1004:
        print("getaddr")
        DMTP_packet_GETADDR().parse(packet)
        await loop.sock_sendall(client, DMTP_packet_ADDR().build([{"ip": 0, "port": 0}, {"ip": 0, "port": 0}]))
    elif operation == 0x1002:
        print("version")
        NODE_DATA = DMTP_packet_VERSION().parse(packet)
        if NODE_DATA["software_version"] < translate_version(NODE_CONFIG["software_version"]):
            await loop.sock_sendall(client, DMTP_packet_VERDEC().build())
            return
        self_data = config_to_bytes(NODE_CONFIG)
        version_packet = DMTP_packet_VERSION().build(self_data["software_version"], self_data["address"],
                                                     self_data["port"], self_data["services"], self_data["height"],
                                                     self_data["token"])
        await loop.sock_sendall(client, version_packet)

        data = recv_packet(client)
        if data["operation"] == 0x1010:
            # ANOTHER NODE DECLINE MY VERSION
            return
            # VERSION SUCCESS: ADDING NODE TO LIST
        print(NODE_DATA)

    client.close()


async def recv_packet(client):
    loop = asyncio.get_event_loop()

    packet: bytes = b""

    request = (await loop.sock_recv(client, 12))
    packet += request

    data_size = int.from_bytes(request[8:12], "big")
    data = (await loop.sock_recv(client, data_size + 8))
    operation = int(packet[4:8].hex(), 16)
    packet += data

    return DMTP_Message().parse(packet)


async def run_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('localhost', 5000))
    server.listen(8)
    server.setblocking(False)

    loop = asyncio.get_event_loop()

    while True:
        client, _ = await loop.sock_accept(server)
        loop.create_task(handle_client(client))


asyncio.run(run_server())
