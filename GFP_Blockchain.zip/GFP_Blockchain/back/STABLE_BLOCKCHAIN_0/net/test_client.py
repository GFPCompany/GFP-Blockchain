import json
import os
import socket
import time

import base58
import sys



sys.path.append("../")

from libs.beauti_cli import *
from libs.gfp_library_0 import *
from protocols.DMTP.DMTP_Message import *

CONFIG = {
    "software_version": "0.0.1",
    "token":sha512("TEST CLIENT"),
    "minimal_version": "0.0.1"
}
def translate_version(version):
    return int("".join([str(int(i)) for i in version.split(".")]))
def ip_to_bytes(ip):
    return socket.inet_aton(ip)
class Client:
    def __init__(self):
        self.ip = None
        self.port = None
    def connect(self, address,timeout=2):
        self.ip = address.split(":")[0]
        self.port = int(address.split(":")[1])
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.socket.settimeout(timeout)
            self.socket.connect((address.split(":")[0], int(address.split(":")[1])))
            printOk("CONNECTED TO NODE '" + self.ip + ":" + str(self.port) + "'",light=True)
            return True
        except:
            printError("CANT CONNECT TO NODE '" + self.ip + ":" + str(self.port) + "' REASON -> TIMED OUT")
            exit(10)


    def send_data(self, data):
        try:
            self.socket.send(data)
        except:
            printError("CANT SEND DATA TO NODE '" + self.ip + ":" + str(self.port) + "' REASON -> TIMED OUT")
            exit(10)

    def recv_data(self,timeout=2):
        self.socket.settimeout(timeout)
        data = self.socket.recv(1024)
        return data

    def ping(self,timeout=2):
        if timeout!=2:
            printBasic("TRYING TO PING NODE '" + self.ip + ":" + str(self.port) + "' WITH TIMEOUT `" + str(timeout) + "` SEC",light=True)
        else:
            printBasic("TRYING TO PING NODE '" + self.ip + ":" + str(self.port)+"' WITH DEFAULT TIMEOUT '2' SEC",light=True)
        st = time.time()
        data = DMTP_packet_PING().build()
        self.send_data(data)
        data = self.recv_data()
        data = DMTP_Message().parse(data)
        if data["operation"] == 0x1001:
            printBasic("PONG RECEIVED, NODE '" + self.ip + ":" + str(self.port) + "' ANSWERED IN " + str(round((time.time() - st)*1000,3)) + " MS",light=True)
            return True
        else:
            return False

    def inv(self, objects_type,objects):
        data = DMTP_packet_INV().build(objects_type,objects)
        self.send_data(data)
    def version(self):
        printBasic("SENDING VERSION REQUEST TO NODE '" + self.ip + ":" + str(self.port) + "'",light=True)
        data = {
            "command": "version",
            "data": {
                "ip": ip_to_bytes(self.socket.getpeername()[0]),
                "port": self.socket.getpeername()[1].to_bytes(2,byteorder="big"),
                "software_version": translate_version(CONFIG["software_version"]).to_bytes(4,byteorder="big"),
                "height": (0).to_bytes(8,byteorder="big"),
                "services":(12).to_bytes(8,byteorder="big"),
                "token": bytes.fromhex(CONFIG["token"])
            }
        }
        data = DMTP_packet_VERSION().build(data["data"]["software_version"],data["data"]["ip"],data["data"]["port"],data["data"]["services"],data["data"]["height"],data["data"]["token"])
        self.send_data(data)

        data = self.recv_data()
        if DMTP_Message().parse(data)["operation"] == 0x1010:
            print("ANTOHER NODE DECLINE MY VERSION AS MINIMAL")
            return
        NODE_DATA = DMTP_packet_VERSION().parse(data)
        print(NODE_DATA)
        if NODE_DATA["software_version"]<translate_version(CONFIG["software_version"]):
            data = DMTP_packet_VERDEC().build()
            self.send_data(data)
            return
        data = DMTP_packet_VERACK().build()
        self.send_data(data)
    def tx(self,txs):
        printBasic("SENDING 'TX' PACKET TO NODE '" + self.ip + ":" + str(self.port) + "'",light=True)
        data = {
            "command": "tx",
            "data": txs
        }
        self.send_data(data)
        printOk("END OF 'tx' SESSION WITH NODE '" + self.ip + ":" + str(self.port) + "'",light=True)


a = Client()
a.connect("127.0.0.1:5000")
a.inv(1,[sha256(1)])