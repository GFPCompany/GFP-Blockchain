import asyncio
import json
import random
import socket

from libs.gfp_library_0 import *
from libs.beauti_cli import *
from protocols.DMTP.DMTP_protocol import *

def ip_to_bytes(ip):
    return socket.inet_aton(ip)
def ip_from_int(ip):
    return socket.inet_ntoa(ip)
def translate_version(version):
    return int("".join([str(int(i)) for i in version.split(".")]))
NODE_CONFIG = {
    "software_version": 1,
    "minimal_version": 1,
    "protocol_version": 0,
    "address": int(ip_to_bytes("127.0.0.1").hex(),16),
    "port": 4040,
    "services": 0,
    "height": 0,
    "token":sha512(1)
}

def config_to_bytes(config):
    data = {
        "software_version":translate_version(config["software_version"]).to_bytes(4,byteorder="big"),
        "address":ip_to_bytes(config["address"]),
        "port":config["port"].to_bytes(2,byteorder="big"),
        "services":config["services"].to_bytes(8,byteorder="big"),
        "height":config["height"].to_bytes(8,byteorder="big"),
        "token":bytes.fromhex(config["token"])
    }
    return data
class GFP_DNS_SEED:
    def __init__(self,NODE_CONFIG:dict):
        self.NODE_CONFIG = NODE_CONFIG

        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.token = bytes.fromhex(md5(random.randint(1, 4124121412412412)))

        self.NODES_LIST = []
    def bind(self):
        self.server_socket.bind((ip_from_int(NODE_CONFIG["address"].to_bytes(4,byteorder="big")), NODE_CONFIG["port"]))
        self.server_socket.listen(8)
        self.server_socket.setblocking(False)
    async def run(self):
        loop = asyncio.get_event_loop()
        printOk("DNS SEED STARTED",light=True)
        while True:
            client, _ = await loop.sock_accept(self.server_socket)
            loop.create_task(self.handle_client(client))
    async def handle_client(self,client:socket.socket):
        loop = asyncio.get_event_loop()

        packet: bytes = b""

        request = (await loop.sock_recv(client, 12))
        packet += request

        data_size = int.from_bytes(request[8:12], "big")
        data = (await loop.sock_recv(client, data_size + 8))
        operation = int(packet[4:8].hex(), 16)
        packet += data
        packet += (await loop.sock_recv(client, 64))

        printInfo("RECEIVED PACKET OPERATION: " + str(hex(operation)), light=True)

        if operation == 0x0000:
            print("ping")
            await loop.sock_sendall(client, DMTP_packet_PONG().build(self.token))
        elif operation == 0x0005:
            print("getaddr")
            print("SENDING NODES LIST LEN: ",len(self.NODES_LIST))
            checksum = sha256(DMTP_packet_ADDR().build(self.NODES_LIST,self.token))[:8]
            print("CHECKSUM: ",checksum)
            await loop.sock_sendall(client, DMTP_packet_ADDR().build(self.NODES_LIST,self.token))
        elif operation == 0x0002:
            print("version")
            NODE_DATA = DMTP_packet_VERSION().parse(packet)
            await loop.sock_sendall(client, DMTP_packet_VERSION().build(
                self.NODE_CONFIG["software_version"],
                self.NODE_CONFIG["protocol_version"],
                self.NODE_CONFIG["address"],
                self.NODE_CONFIG["port"],
                self.NODE_CONFIG["services"],
                self.NODE_CONFIG["height"],
                self.token
            )
                                    )
            data = await self.recv_packet(client)

            if int(data[4:8].hex(), 16) == 0x0004:
                print("verdec")
                return
            elif int(data[4:8].hex(), 16) == 0x0003:
                print("verack")
                if self.NODE_CONFIG["software_version"] > NODE_DATA["data"]["software_version"]:
                    await loop.sock_sendall(client, DMTP_packet_VERDEC().build(self.token))  # sending verdec
                    return
                # sending verack
                msg = DMTP_packet_VERACK().build(self.token)
                await loop.sock_sendall(client, msg)
                node_check = b""
                node_check += NODE_DATA["data"]["address"].to_bytes(16, byteorder="big")
                node_check += NODE_DATA["data"]["port"].to_bytes(2, byteorder="big")
                node_check = sha512(node_check)
                if node_check not in [sha512(node["ip"].to_bytes(16, byteorder="big") + node["port"].to_bytes(2, byteorder="big")) for node in self.NODES_LIST]:
                    self.NODES_LIST.append({"ip":NODE_DATA["data"]["address"], "port":NODE_DATA["data"]["port"],"token":NODE_DATA["token"]})
                return
        client.close()

    async def recv_packet(self,client):
        loop = asyncio.get_event_loop()

        packet: bytes = b""

        request = (await loop.sock_recv(client, 12))
        packet += request

        data_size = int.from_bytes(request[8:12], "big")
        data = (await loop.sock_recv(client, data_size + 64+4+4))
        operation = int(packet[4:8].hex(), 16)
        packet += data

        return packet
if __name__ == '__main__':
    NODE = GFP_DNS_SEED(NODE_CONFIG)
    NODE.bind()
    asyncio.run(NODE.run())
