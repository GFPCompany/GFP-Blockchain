import json
import socket

import base58

from db.db_lib import db_select
from libs.gfp_library_0 import *
from libs.beauti_cli import *
from objects.block import Block
from objects.transaction import *
from protocols.DMTP.DMTP_protocol import *
from tools.calculate_balance import GetTransactionFromChain


def ip_to_int(ip):
    return int(socket.inet_aton(ip).hex(),16)
class Client:
    def __init__(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.con = False
        self.token = bytes.fromhex(md5(4124121412412412))
    def connect(self, ip, port):
        self.socket.connect((ip, port))
        self.socket.settimeout(2)
        printOk("CONNECTED TO NODE '" + ip + ":" + str(port) + "'",light=True)
        return True
    def recv_packet(self):
        msg = self.socket.recv(12)
        data_size = int.from_bytes(msg[8:12], "big")
        msg += self.socket.recv(data_size+64+8)
        return msg
    def test_PING_PONG_session(self):
        msg = DMTP_packet_PING().build(self.token)
        self.socket.sendall(msg)
        msg = self.socket.recv(1024)
        print(msg)
        msg = DMTP_packet_PONG().parse(msg)
        print(msg)
        self.socket.close()
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    def test_VERSION_SESSION(self):
        configs = {
            "software_version": 1,
            "protocol_version": 1,
            "minimal_version": 1,
            "ip": ip_to_int("127.0.0.1"),
            "port": 45563,
            "token": self.token,
            "services": 0b010101001010100101111010,
            "height": 0
        }
        msg = DMTP_packet_VERSION().build(configs["software_version"],configs["protocol_version"],configs["ip"],configs["port"],configs["services"],configs["height"],configs["token"])
        self.socket.sendall(msg)

        data = self.recv_packet()
        print(data)
        data = DMTP_packet_VERSION().parse(data)
        if data["data"]["software_version"] < configs["software_version"]:
            msg = DMTP_packet_VERDEC().build(self.token)
            print("sending verdec")
            self.socket.sendall(msg)
            return
        print("sending verack")
        msg = DMTP_packet_VERACK().build(self.token)
        self.socket.sendall(msg)

        print("verack sent")
        data = self.recv_packet()
        data = DMTP_packet_VERACK().parse(data)
        print(data)
    def test_INV_SESSION(self):
        objects_type = 0x0000

        block = db_select("SELECT data FROM gfp_db.raw_blocks WHERE id=1")
        block_hash = block[0]["data"][4:36]

        printOk("SENDING BLOCK WITH LENGTH: " + str(len(block)),light=True)
        objects = [block_hash]
        msg = DMTP_packet_INV().build(objects_type,objects,self.token)
        self.socket.sendall(msg)

        data = self.recv_packet()
        print("received getdata")
        data = DMTP_packet_GETDATA().parse(data)
        if len(data["data"]["objects"])==0:
            printWarning("BLOCK NOT REQUIRED BY NODE",light=True)
            return
        print(data)
        print(data["data"]["objects"][0].hex())
        print(data["data"]["objects"][0]==block_hash)
        objects = [block[0]["data"]]
        msg = DMTP_packet_DATA().build(objects_type,objects,self.token)
        self.socket.sendall(msg)

        self.socket.close()
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    def test_INV_SESSION_with_TX(self):
        tx = GFP_Transaction_coinbase().create([{"amount": 1, "lock": "55"*38}],b"Hello World")[0]
        printInfo("TXID: " + sha256(bytes.fromhex(sha256(tx))))
        printInfo(tx.hex())
        msg = DMTP_packet_INV().build(0x0001,[sha256(bytes.fromhex(sha256(tx)))],self.token)
        self.socket.sendall(msg)

        data = self.recv_packet()
        print(data)
        data = DMTP_packet_GETDATA().parse(data)
        if len(data["data"]["objects"])==0:
            printWarning("TX NOT REQUIRED BY NODE",light=True)
            return
        print(data)
        print(data["data"]["objects"][0].hex())
        printInfo("REQUEST FOR "+data["data"]["objects"][0].hex())
        print(data["data"]["objects"][0].hex()==sha256(bytes.fromhex(sha256(tx))))
        msg = DMTP_packet_DATA().build(0x0001,[tx],self.token)
        self.socket.sendall(msg)

        self.socket.close()
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    def test_REAL_TRANSFER(self):
        print(2)
        utxo = db_select("SELECT * FROM `gfp_node_" + md5(0) + "`.`utxo`")
        print(3)
        key_for_search = "6UTu2Mxz42DsVzK43dxkm63ti5RgL7KpRuKckdpjviFBa4fsFoGr"
        key_to_send = "6UULatq8HcC4hgDADxnz4KwS6S4ViTKSkqtL7SQpjBJKk1W7tR3D"
        my_utxo = []
        print(1)
        for i in utxo:
            for o in json.loads(i["outputs"]):
                if o["lock"] == base58.b58decode(key_for_search.encode("utf-8")).hex():
                    my_utxo.append(i)
        required_txs = [i["txid"] for i in my_utxo]
        txs = [GetTransactionFromChain("gfp_node_"+md5(0),i) for i in required_txs]
        tx0 = txs[0]
        print(6)
        real_tx = GFP_Transaction_P2PKH().create(
            [
                {
                    "txid": tx0["txid"],
                    "vout": 0
                }
            ],
            [
                {
                    "lock": base58.b58decode(key_to_send.encode("utf-8")).hex(),
                    "amount": 160
                }
            ],
            GFP_PrivateKey().from_GFP("4AepjMa5QoaCL8NozHt4fRQKEJHhfFwppECiMspRGKU7VHWqaVR4").to_GFP(),
            [tx0]
        )

        inv = DMTP_packet_INV().build(0x0001,[sha256(bytes.fromhex(sha256(real_tx[0])))],self.token)
        print(inv)
        self.socket.sendall(inv)
        print("sent inv")

        data = self.recv_packet()
        print(data)
        data = DMTP_packet_GETDATA().parse(data)
        if len(data["data"]["objects"])==0:
            printWarning("TX NOT REQUIRED BY NODE",light=True)
            return
        print(data)
        print(data["data"]["objects"][0].hex())
        printInfo("REQUEST FOR "+data["data"]["objects"][0].hex())
        print(data["data"]["objects"][0].hex()==sha256(bytes.fromhex(sha256(real_tx[0]))))
        msg = DMTP_packet_DATA().build(0x0001,[real_tx[0]],self.token)
        self.socket.sendall(msg)
for i in range(1):
    a = Client()

    a.connect("127.0.0.1", 4550)
    #a.test_INV_SESSION_with_TX()

    #a.test_PING_PONG_session()

    a.test_REAL_TRANSFER()