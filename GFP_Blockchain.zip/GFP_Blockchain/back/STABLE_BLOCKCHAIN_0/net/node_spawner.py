import os
import pathlib
import sys

for i in range(int(sys.argv[1])):
    print(pathlib.Path().resolve())
    os.system("start cmd /k python "+str(pathlib.Path().resolve())+"/async/AsyncNode_alphabet.py " + str(i) + "")
    #os.system("cd async")
    os.system("python AsyncNode_alphabet.py " + str(i) + "")