import base64
import os

import base58

from db.db_lib import *
from libs.gfp_library_0 import *


def GenerateNodeToken():
    data = os.urandom(4096)
    raw_token = bytes.fromhex(md5(data))
    return raw_token
