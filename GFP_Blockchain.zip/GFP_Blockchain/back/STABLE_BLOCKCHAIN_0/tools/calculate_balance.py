import json

from objects.keys import *
from objects.block import *
from objects.transaction import *


def calculate_balance_in_block(block:bytes,address,utxo):
    block = Block().from_raw_to_json(block)
    block = block["txs"]

    decoded_address = base58.b58decode(address).hex()
    balance = 0
    #TODO LOOKING RECEIVED TRANSACTIONS
    for i in block:
        i = bytes.fromhex(i)
        object_type = int(i[:4].hex(),16)
        tx_type = i[4:6].hex()
        tx_version = i[6:8].hex()

        if int(tx_type,16) == 0x0000:
            tx = GFP_Transaction_P2PKH()

            tx = tx.raw_to_json(i)
            for out in tx["outputs"]:
                if out["lock"] == decoded_address:
                    balance += out["amount"]
                    if sha256(bytes.fromhex(sha256(i))) not in utxo:
                        utxo.append(sha256(bytes.fromhex(sha256(i))))
        elif int(tx_type,16) == 0x0001:
            tx = GFP_Transaction_coinbase()

            tx = tx.raw_to_json(i)
            for out in tx["outputs"]:
                if out["lock"] == decoded_address:
                    balance += out["amount"]
                    if sha256(bytes.fromhex(sha256(i))) not in utxo:
                        utxo.append(sha256(bytes.fromhex(sha256(i))))
    #TODO LOOKING SENT TRANSACTIONS
    for i in block:
        i = bytes.fromhex(i)
        object_type = int(i[:4].hex(), 16)
        tx_type = i[4:6].hex()
        tx_version = i[6:8].hex()

        if int(tx_type, 16) == 0x0000:
            tx = GFP_Transaction_P2PKH()
            tx = tx.raw_to_json(i)

            for inp in tx["inputs"]:

                if inp["txid"] in utxo:
                    for out in tx["outputs"]:
                        print(out["amount"])
                        balance -= out["amount"]
    return [balance,utxo]

def GetBalance(db_name,address):
    block = db_select("SELECT data FROM `"+db_name+"`.`raw_blocks`")
    balance = 0
    block = [i["data"] for i in block]
    utxo = []
    for i in block:
        data = calculate_balance_in_block(i, address, utxo)
        balance += data[0]
        for i in data[1]:
            if i not in utxo:
                utxo.append(i)
    return balance

if __name__ == '__main__':
    print(GetBalance("gfp_node_"+md5(0),"6UTu2Mxz42DsVzK43dxkm63ti5RgL7KpRuKckdpjviFBa4fsFoGr"))
def GetTransactionFromChain(db_name,txid):
    block = db_select("SELECT `data` FROM `"+db_name+"`.`raw_blocks`")
    block = [i["data"] for i in block]
    for i in block:
        i = Block().from_raw_to_json(i)
        for j in i["txs"]:
            if sha256(bytes.fromhex(sha256(bytes.fromhex(j)))) == txid:
                j = bytes.fromhex(j)
                tx_type = int(j[4:6].hex(), 16)
                if tx_type == 0x0000:
                    tx = GFP_Transaction_P2PKH()
                    tx = tx.raw_to_json(j)
                    tx["txid"] = txid
                    return tx
                elif tx_type == 0x0001:
                    tx = GFP_Transaction_coinbase()
                    tx = tx.raw_to_json(j)
                    tx["txid"] = txid
                    return tx

#tx = GetTransactionFromChain("3d019a4e5c7dabe7f167369e59d5646ed9cc6d504485dc0576afadfe3a446f20")
#print(json.dumps(tx, indent=4))
