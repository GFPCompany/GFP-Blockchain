import json
import socket
import sys



sys.path.append("../../")
sys.path.append("../../../")
sys.path.append("../")
sys.path.append("../../libs/")
sys.path.append("../../protocols/")
sys.path.append("../../db")
sys.path.append("../../db/scripts")
sys.path.append("../../objects")
from objects.keys import *
from objects.block import *
from objects.transaction import *
from db.db_lib import db_select
from colorama import *
from protocols.DMTP.DMTP_protocol import *
from tools.calculate_balance import GetTransactionFromChain

def ip_from_int(ip):
    return str(ip >> 24) + "." + str((ip >> 16) & 255) + "." + str((ip >> 8) & 255) + "." + str(ip & 255)

init(autoreset=True)

config = {
    "texts": {
        "help_menu_text": """

        Welcome to the """ + Fore.BLACK + Back.LIGHTWHITE_EX + "GFPDataTool" + Fore.RESET + Back.RESET + """.
        This tool allows you to encrypt, decrypt GFP Blockchain objects, connect to Nodes and get data.

        usage: data_tool.py <command> [options]
        
        Always use """ + Fore.LIGHTGREEN_EX + "'" + Fore.RESET + """ or """ + Fore.LIGHTGREEN_EX + "\"" + Fore.RESET + """ around data, for example : "hello world" or '{\"hello\": \"world\"}'
        
        commands:
        -DATA COMMANDS GROUP:
            --encrypt / -e  [<data> -i <input file> -o <output file>] :""" + Fore.LIGHTYELLOW_EX + """ (One of options [-d, -i] must be used) """ + Fore.RESET + """
                Encrypt data, input formats : JSON, BASE58, File
                Output format is always HEX
            --decrypt / -d  [<data> -i <input file> -o <output file>] :""" + Fore.LIGHTYELLOW_EX + """ (One of options [-d, -i] must be used) """ + Fore.RESET + """
                Decrypt data, input formats : HEX, File
                Output format is always JSON
                """ + Fore.LIGHTCYAN_EX + "(*-_\\ Features /_-*)" + Fore.RESET + """
                    * Autodetect object type and selecting the right decryptor for it
        
        -NETWORK COMMANDS GROUP:
            --connect / -c  <ip> -p <port>
                Connect to a node, uses script PING,VERSION
            --get / -g  <object_type> <hash or txid> [-o <output file>]
                Get one object from the network
            --get-all / -ga  <object_type> <hash or txid list> [-o <output file>]
                Get specified objects from the network by its hash
                When data is hex, then hashes must be separated by comma.
                When data is json, then hashes should under key "hashes"

        -OTHER COMMANDS GROUP:
            --help / -h
                Show this menu
        """
    }
}
NODE_CONFIG = {
    "network": {
        "name": "TEST",
        "dns_seed": {
            "ip": "127.0.0.1",
            "port": 4040
        }
    }
}

def help_menu():
    text = config["texts"]["help_menu_text"]
    print(text)
def recv_packet(s:socket.socket):
    rcv: bytes = b""

    try:
        request = s.recv(12)
    except:
        return False
    rcv += request

    data_size = int.from_bytes(request[8:12], "big")
    try:
        data = s.recv(data_size + 8 + 16)
    except:
        return False
    rcv += data
    return rcv

def parse_args():
    args = sys.argv

    if "-h" in args or "--help" in args:
        help_menu()
        return
    if "-d" in args or "--decrypt" in args:
        if len(sys.argv) < 3:
            print(Fore.RED + "ERROR: Missing arguments")
            return
        data_mode = sys.argv[1]
        if "-i" not in args and "--input" not in args:
            data = sys.argv[2]
            # check if data is hex

        elif "-i" in args or "--input" in args:
            with open(sys.argv[3], "r") as f:
                try:
                    data = json.loads(f.read())
                    if len(data) == 0:
                        print(Fore.RED + "ERROR: Input file is empty")
                        return
                    data = data[0]
                except:
                    data = f.read().replace("\n", "").replace(" ", "")
        print(bytes.fromhex(data))
        if all(char in "0123456789abcdefABCDEF" for char in data):
            data = bytes.fromhex(data)
            object_type = data[0:4]
            if int(object_type.hex(), 16) == 0x0000:
                min_block_size = 132
                if len(data) < min_block_size:
                    print(Fore.RED + "ERROR: Data is too short to block, need at least " + str(
                        min_block_size) + " bytes for Block")
                    return
                _metrics = """
                    \r\tObject type : Block (0x""" + object_type.hex() + """)
                    \r\tBlock version : """ + str(int(data[92:96].hex(), 16)) + """ (0x""" + data[92:96].hex() + """)
                    \r\tBlock size : """ + str(len(data)) + """ (""" + hex(len(data)) + """)
                    \r\tBlock timestamp : """ + str(int(data[52:60].hex(), 16)) + """ (0x""" + data[52:60].hex() + """)
                    \r\tBlock nonce : """ + str(int(data[36:44].hex(), 16)) + """ (0x""" + data[36:44].hex() + """)
                    \r\tBlock transactions count : """ + str(int(data[128:132].hex(), 16)) + """ (0x""" + data[
                                                                                                          128:132].hex() + """)
                    """
                print(Fore.LIGHTYELLOW_EX + "\nMetrics :\n" + Fore.RESET + _metrics)
                block = Block().from_raw_to_json(data)
                print(Fore.LIGHTGREEN_EX + "-+" * 50)
                print(json.dumps(block, indent=4, sort_keys=True, ensure_ascii=False))
                print(Fore.LIGHTGREEN_EX + "-+" * 50)
            elif int(object_type.hex(), 16) == 0x0001:
                tx_type = data[4:6]
                tx_version = data[6:8]
                min_transaction_size = 20
                if len(data) < min_transaction_size:
                    print(Fore.RED + "ERROR: Data is too short to transaction, need at least " + str(
                        min_transaction_size) + " bytes for Transaction")
                    return
                if int(tx_type.hex(), 16) == 0x0000:
                    _metrics = """
                        \r\tObject type : Transaction (0x""" + object_type.hex() + """)
                        \r\tTransaction type : P2PKH (0x""" + tx_type.hex() + """)
                        \r\tTransaction version : 0x""" + tx_version.hex() + """
                        """
                    print(Fore.LIGHTYELLOW_EX + "\nMetrics :\n" + Fore.RESET + _metrics)
                    print(Fore.LIGHTGREEN_EX + "-+" * 50)
                    tx = GFP_Transaction_P2PKH().raw_to_json(data)
                    print(json.dumps(tx, indent=4, sort_keys=True, ensure_ascii=False))
                    print(Fore.LIGHTGREEN_EX + "-+" * 50)
                elif int(tx_type.hex(), 16) == 0x0001:
                    _metrics = """
                                                \r\tObject type : Transaction (0x""" + object_type.hex() + """)
                                                \r\tTransaction type : P2PKH Coinbase (0x""" + tx_type.hex() + """)
                                                \r\tTransaction version : 0x""" + tx_version.hex() + """
                                                """
                    print(Fore.LIGHTYELLOW_EX + "\nMetrics :\n" + Fore.RESET + _metrics)
                    print(Fore.LIGHTGREEN_EX + "-+" * 50)
                    tx = GFP_Transaction_coinbase().raw_to_json(data)
                    print(json.dumps(tx, indent=4, sort_keys=True, ensure_ascii=False))
                    print(Fore.LIGHTGREEN_EX + "-+" * 50)
                else:
                    print(Fore.RED + "ERROR: Transaction type is not recognized, received " + tx_type.hex())
                    return
            else:
                if object_type.hex() == "3f3c2d2d":
                    print("DETECTED DMTP PACKET")
                    operation = int(data[4:8].hex(), 16)
                    if operation == 0x0000:
                        print("Data resolved as PING packet")
                        data = DMTP_packet_PING().parse(data)
                        data["token"] = data["token"].hex()
                        data["checksum"] = data["checksum"].hex()
                        data["data"] = data["data"].hex()
                        print(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                    elif operation == 0x0001:
                        print("Data resolved as PONG packet")
                        data = DMTP_packet_PONG().parse(data)
                        data["token"] = data["token"].hex()
                        data["checksum"] = data["checksum"].hex()
                        data["data"] = data["data"].hex()
                        print(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                    elif operation == 0x0002:
                        print("Data resolved as VERSION packet")
                        data = DMTP_packet_VERSION().parse(data)
                        data["token"] = data["token"].hex()
                        data["checksum"] = data["checksum"].hex()
                        print(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                    elif operation == 0x0003:
                        print("Data resolved as VERACK packet")
                        data = DMTP_packet_VERACK().parse(data)
                        data["token"] = data["token"].hex()
                        data["checksum"] = data["checksum"].hex()
                        data["data"] = data["data"].hex()
                        print(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                    elif operation == 0x0004:
                        print("Data resolved as VERDEC packet")
                        data = DMTP_packet_VERDEC().parse(data)
                        data["token"] = data["token"].hex()
                        data["checksum"] = data["checksum"].hex()
                        data["data"] = data["data"].hex()
                        print(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                    elif operation == 0x0005:
                        print("Data resolved as GET_ADDR packet")
                        data = DMTP_packet_GETADDR().parse(data)
                        data["token"] = data["token"].hex()
                        data["checksum"] = data["checksum"].hex()
                        data["data"] = data["data"].hex()
                        print(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                    elif operation == 0x0006:
                        print("Data resolved as ADDR packet")
                        data = DMTP_packet_ADDR().parse(data)
                        data["token"] = data["token"].hex()
                        data["checksum"] = data["checksum"].hex()
                        data["data"] = [{"ip": ip_from_int(data["data"]["address"][i]["ip"]),
                                         "port": data["data"]["address"][i]["port"],
                                         "token": data["data"]["address"][i]["token"].hex()} for i in
                                        range(len(data["data"]["address"]))]
                        print(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                    elif operation == 0x2000:
                        print("Data resolved as INV packet")
                        data = DMTP_packet_INV().parse(data)
                        print(data)
                        data["token"] = data["token"].hex()
                        data["checksum"] = data["checksum"].hex()
                        data["data"] = [i.hex() for i in data["data"]["objects"]]
                        print(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                    elif operation == 0x2003:
                        print("Data resolved as DATA packet")
                        data = DMTP_packet_DATA().parse(data)
                        print(data)
                        data["token"] = data["token"].hex()
                        data["checksum"] = data["checksum"].hex()
                        data["data"] = [i.hex() for i in data["data"]]
                        print(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                else:
                    print(Fore.RED + "ERROR: Object type is not recognized")
                    return
        else:
            print(Fore.RED + "ERROR: Data is not hex")
            return
        return
    if sys.argv[1] == "-e" or sys.argv[1] == "--encode":
        if len(sys.argv) < 3:
            print("ERROR: Missing argument")
            return
        if sys.argv[2] != "-i":
            base58_symbols = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
            if all(symbol in base58_symbols for symbol in sys.argv[2]):
                data = base58.b58decode(sys.argv[2])
                print("HEX : " + data.hex())
                first_4_bytes = data[:4]
                objects_types = [0x0, 0x1]
                dmtp_start_bytes = b"?<--"
                if first_4_bytes == dmtp_start_bytes:
                    print("Detected DMTP protocol message")
                elif int(first_4_bytes.hex(), 16) in objects_types:
                    print("Detected object")
                    object_type = int(first_4_bytes.hex(), 16)
                    if object_type == 0x0:
                        print("Detected block")
                    elif object_type == 0x1:
                        print("Detected transaction")
                else:
                    print(Fore.RED + "ERROR: Can't encrypt data, not recognized as block,transaction or DMTP message")
                    return
            else:
                try:
                    data = json.loads(sys.argv[2])
                    print("JSON : " + json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                    print(
                        "HEX : " + json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False).encode('utf-8').hex())
                except:
                    print(Fore.RED + "ERROR: Invalid input data format")
    if "-c" in args or "--connect" in args:
        if len(args) < 4:
            print(args)
            print("ERROR: Missing argument")
            return
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        try:
            s.connect((args[2], int(args[3])))
        except:
            printError("ERROR: Maybe NODE `" + args[2] + ":" + args[3] + "` is offline",True)
            return
        printInfo("INFO: Sending PING packet to " + args[2] + ":" + args[3] + "", light=True)
        s.sendall(DMTP_packet_PING().build(bytes.fromhex(md5(1))))
        data = recv_packet(s)
        if data == False:
            printError("ERROR: PONG packet not received, maybe NODE `" + args[2] + ":" + args[3] + "` is damaged or has another problem",True)
            return
        operation_code = DMTP_Message().parse(data)["operation"]
        if operation_code == 0x1:
            print(Fore.LIGHTGREEN_EX+"SUCCESS: PONG packet received | "+Fore.LIGHTWHITE_EX+"node_token='" + DMTP_Message().parse(data)["token"].hex() + "'")
        s.close()

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        try:
            s.connect((args[2], int(args[3])))
        except:
            printError("ERROR: Maybe NODE `" + args[2] + ":" + args[3] + "` is offline",True)
            return
        printInfo("INFO: Sending VERSION packet to " + args[2] + ":" + args[3] + "", light=True)
        data = {
            "software_version": 0,
            "protocol_version": 1,
            "address": 0,
            "port": 0,
            "services": 0,
            "height": 0
        }
        s.sendall(DMTP_packet_VERSION().build(data["software_version"],data["protocol_version"],data["address"],data["port"],data["services"],data["height"],bytes.fromhex(md5(1))))
        data = recv_packet(s)
        print(data)
        if data == False:
            printError("ERROR: VERSION packet not received, maybe NODE `" + args[2] + ":" + args[3] + "` is damaged or has another problem",True)
            return
        operation_code = DMTP_Message().parse(data)["operation"]
        if operation_code == 0x2:
            print(Fore.LIGHTGREEN_EX+"SUCCESS: VERSION packet received | "+Fore.LIGHTWHITE_EX+"node_token='" + DMTP_Message().parse(data)["token"].hex() + "'\nNode data :\n"+json.dumps(DMTP_packet_VERSION().parse(data)["data"], indent=4, sort_keys=True, ensure_ascii=False))
        elif operation_code == 0x4:
            print(Fore.LIGHTGREEN_EX+"SUCCESS: VERDEC packet received | "+Fore.LIGHTWHITE_EX+"node_token='" + DMTP_Message().parse(data)["token"].hex() + "'")
        s.sendall(DMTP_packet_VERDEC().build(bytes.fromhex(md5(1))))
        print(Fore.LIGHTCYAN_EX+"Sending VERDEC packet to " + args[2] + ":" + args[3] + ", because this program is not node")
        s.close()
    if "-g" in args or "--get" in args:
        if len(args) < 4:
            print(args)
            print("ERROR: Missing arguments, required: <object_type> <hash or txid>, use -h for help")
            return
        if args[2]=="block" or args[2]=="0" or args[2]=="0x00000000" or args[2]=="1" or args[2]=="0x00000001" or args[2]=="transaction" or args[2]=="tx":
            printInfo("Asking dns-seed for nodes list",light=True)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            try:
                s.connect((NODE_CONFIG["network"]["dns_seed"]["ip"], int(NODE_CONFIG["network"]["dns_seed"]["port"])))
            except:
                printError("DNS SEED OFFLINE", light=True)
                return
            printInfo("INFO: Sending GETADDR packet to " + NODE_CONFIG["network"]["dns_seed"]["ip"] + ":" + str(NODE_CONFIG["network"]["dns_seed"]["port"]) + "", light=True)
            s.sendall(DMTP_packet_GETADDR().build(bytes.fromhex(md5(1))))
            data = recv_packet(s)
            if data == False:
                printError("ERROR: GETADDR packet not received, maybe DNS SEED is offline or has another problem",True)
                return
            operation_code = DMTP_Message().parse(data)["operation"]
            if operation_code == 0x6:
                print(Fore.LIGHTGREEN_EX+"SUCCESS: GETADDR packet received | "+Fore.LIGHTWHITE_EX+"node_token='" + DMTP_Message().parse(data)["token"].hex() + "', addresses_count=" + str(len(DMTP_packet_ADDR().parse(data)["data"]["address"])))
            else:
                printError("ERROR: GETADDR packet not received, maybe DNS SEED is offline or has another problem",True)
                return
            s.close()
            nodes_list = DMTP_packet_ADDR().parse(data)["data"]["address"]
            for node in nodes_list:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(5)
                node["ip"] = socket.inet_ntoa(node["ip"].to_bytes(4, "big"))
                try:
                    s.connect((node["ip"], int(node["port"])))
                except:
                    printError("ERROR: Can't connect to node, maybe `" + str(node["ip"]) + ":" + str(node["port"]) + "` is offline",True)
                    continue
                printInfo("INFO: Sending GETDATA packet to " + str(node["ip"]) + ":" + str(node["port"]) + "", light=True)
                object_type = None
                if args[2] in ["block","0","0x00000000","0","0x00000000"]:
                    object_type = 0
                elif args[2] in ["transaction","tx","1","0x00000001"]:
                    object_type = 1
                msg = DMTP_packet_GETDATA().build(object_type,[args[3]])
                s.sendall(msg)

                data = recv_packet(s)
                if data == False:
                    printError("ERROR: GETDATA packet not received, maybe node is offline or has another problem",True)
                    continue
                operation_code = DMTP_Message().parse(data)["operation"]
                if operation_code == 0x2003:
                    data = DMTP_packet_DATA().parse(data)
                    print(
                        Fore.LIGHTGREEN_EX + "SUCCESS: DATA packet received | " + Fore.LIGHTWHITE_EX + "node_token='" + "', objects_count=" + str(len(data["data"])))
                    data["token"] = data["token"].hex()
                    data["checksum"] = data["checksum"].hex()
                    data["data"] = [x.hex() for x in data["data"]]
                    print(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
                    if "-o" in args or "--output" in args:
                        path = args[args.index("-o") + 1]
                        f = open(path, "w")
                        f.write(json.dumps(data["data"], indent=4, sort_keys=True, ensure_ascii=False))
                        f.close()
                        print(Fore.LIGHTGREEN_EX + "SUCCESS: Objects from DATA packet packet saved to " + path)
                else:
                    printError("ERROR: DATA packet not received, maybe node is offline or has another problem",True)
                    continue

    else:
        print("ERROR: Unknown option")
        return



parse_args()