CREATE DATABASE `:db_name`;
USE `:db_name`;
CREATE TABLE `:db_name`.`peers`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` bigint NULL DEFAULT NULL,
  `port` bigint NULL DEFAULT NULL,
  `version` bigint NULL DEFAULT NULL,
  `height` bigint NULL DEFAULT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;
CREATE TABLE `:db_name`.`raw_blocks`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `hash` tinyblob NULL,
  `data` mediumblob NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 118 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;
CREATE TABLE `:db_name`.`utxo`  (
  `txid` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `outputs` json NULL,
  PRIMARY KEY (`txid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;
CREATE TABLE `:db_name`.`config` (
    `id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY ,
    `config` json NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;