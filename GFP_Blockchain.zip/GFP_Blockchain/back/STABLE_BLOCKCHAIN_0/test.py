import hashlib
import json

from db.db_lib import db_select
from libs.gfp_library_0 import md5

utxo = db_select("SELECT * FROM gfp_node_93b885adfe0da089cdf634904fd59f71.utxo")

def build_tx_io(utxo,outputs,fee,address):
    out = {
        "inputs":[],
        "outputs":outputs
    }
    outputs_sum = 0

    for i in outputs:
        outputs_sum += i["amount"]

    amount = outputs_sum

    utxo = [{"txid":i["txid"],"outputs":json.loads(i["outputs"])} for i in utxo]

    full_utxo_balance = 0
    for i in utxo:
        full_utxo_balance += i["outputs"][0]["amount"]
    if full_utxo_balance < amount:
        return False

    utxo = sorted(utxo, key=lambda x: x["outputs"][0]["amount"], reverse=False)

    current_inputs_sum = 0
    inputs = []
    for i in range(len(utxo)):
        if current_inputs_sum < amount + fee:
            inputs.append(utxo[i])
            current_inputs_sum += utxo[i]["outputs"][0]["amount"]
        else:
            break
    out["inputs"] = inputs

    change = current_inputs_sum - amount - fee
    if change!=0 and change > 0:
        out["outputs"].append({
            "lock":address,
            "amount":change,
        })

    return out


print(json.dumps(build_tx_io(utxo,[{"lock":"6UK4h5mFbRq3h2vLq6iWtXtYQg4YjySj8","amount":1}],1,"6UK4h5mFbRq3h2vLq6iWtXtYQg4YjySj8"),indent=4))