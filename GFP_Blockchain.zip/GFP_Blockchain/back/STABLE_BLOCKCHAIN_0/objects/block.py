import json
import math
import time
import datetime

import base58
import pymysql

from db.db_lib import *
from libs.beauti_cli import *
from libs.gfp_library_0 import sha256

def is_power_of_two(n):
    return (n != 0) and (n & (n-1) == 0)

class Block:
    def __init__(self):
        self.timestamp=None
        self.version=0
        self.merkle_root=None
        self.bits=None
        self.hash = None
        self.nonce = None
        self.prev_hash = None
        self.object_type = b"\x00\x00\x00\x00"

        self.txs_count = 0
        self.txs = []

        self.raw_data = b""
        self.json_data = {}
    def set_timestamp(self):
        self.timestamp = int(time.mktime(datetime.datetime.now().timetuple()))
        return self

    def create(self,prev_block,bits,txs):
        #TODO check txs
        self.txs_count = len(txs)
        self.txs = txs

        self.gen_merkle_root()

        self.set_timestamp()
        self.prev_hash = prev_block
        self.bits = bits

        return self

    def gen_merkle_root(self):
        txs_txids = []
        for i in self.txs:
            txs_txids.append(bytes.fromhex(sha256(bytes.fromhex(sha256(i)))))
        if is_power_of_two(len(txs_txids)):
            layers = math.log2(len(txs_txids))+1
        else:
            layers = math.log2(len(txs_txids))
            layers = math.ceil(layers)+1
            last_txid = txs_txids[-1]
            for i in range(2**(int(layers-1))-len(txs_txids)):
                txs_txids.append(last_txid)
        layers = int(layers)
        for i in range(layers):
            nodes = []
            for d in range(0,len(txs_txids),2):
                if len(txs_txids) == 1:
                    self.merkle_root = txs_txids[0]
                    break
                nodes.append(bytes.fromhex(sha256(txs_txids[d]+txs_txids[d+1])))
            txs_txids = nodes

        return self
    def to_json(self):
        self.json_data["timestamp"] = self.timestamp
        self.json_data["version"] = self.version
        self.json_data["merkle_root"] = self.merkle_root.hex()
        self.json_data["bits"] = self.bits
        self.json_data["hash"] = self.hash.hex()
        self.json_data["nonce"] = self.nonce
        self.json_data["prev_hash"] = self.prev_hash.hex()
        self.json_data["object_type"] = self.object_type.hex()
        self.json_data["txs_count"] = self.txs_count
        self.json_data["txs"] = []
        for i in self.txs:
            self.json_data["txs"].append(i.hex())
        return self.json_data
    def mine(self):
        self.header_data = b""
        self.header_data += self.object_type
        self.header_data += self.bits.to_bytes(8,"big")
        self.header_data += self.timestamp.to_bytes(8,"big")
        self.header_data += self.prev_hash
        self.header_data += self.version.to_bytes(4,"big")
        self.header_data += self.merkle_root
        self.header_data += self.txs_count.to_bytes(4,"big")
        self.hash = sha256(bytes.fromhex(sha256(self.header_data)))
        self.nonce = 0
        iteration = 0
        while self.hash[:2] != "00":
            self.nonce += 1
            self.hash = sha256(bytes.fromhex(sha256(self.header_data+self.nonce.to_bytes(8,"big"))))
            iteration += 1
            if iteration % 100000 == 0:
                print("ITERATION",iteration)
        self.hash = bytes.fromhex(self.hash)
        return self

    def to_raw(self):
        self.raw_data += self.object_type
        self.raw_data += self.hash
        self.raw_data += self.nonce.to_bytes(8,"big")
        self.raw_data += self.bits.to_bytes(8,"big")
        self.raw_data += self.timestamp.to_bytes(8,"big")
        self.raw_data += self.prev_hash
        self.raw_data += self.version.to_bytes(4,"big")
        self.raw_data += self.merkle_root
        self.raw_data += self.txs_count.to_bytes(4,"big")
        for i in self.txs:
            self.raw_data += i
        data = self.raw_data
        self.raw_data = b""
        return data
    def check_hash(self):
        self.header_data = b""
        self.header_data += self.object_type
        self.header_data += self.bits.to_bytes(8, "big")
        self.header_data += self.timestamp.to_bytes(8, "big")
        self.header_data += self.prev_hash
        self.header_data += self.version.to_bytes(4, "big")
        self.header_data += self.merkle_root
        self.header_data += self.txs_count.to_bytes(4, "big")
        self.header_data += self.nonce.to_bytes(8, "big")
        if self.hash.hex() == sha256(sha256(self.header_data)):
            return True
        return False
    def from_raw(self,data):
        self.raw_data = data
        self.object_type = self.raw_data[:4]
        self.hash = self.raw_data[4:36]
        self.nonce = int.from_bytes(self.raw_data[36:44],"big")
        self.bits = int.from_bytes(self.raw_data[44:52],"big")
        self.timestamp = int.from_bytes(self.raw_data[52:60],"big")
        self.prev_hash = self.raw_data[60:100]
        self.version = int.from_bytes(self.raw_data[100:104],"big")
        self.merkle_root = self.raw_data[104:136]
        self.txs_count = int.from_bytes(self.raw_data[136:140],"big")
        self.txs = []
        for i in range(self.txs_count):
            self.txs.append(self.raw_data[140+i*32:172+i*32])
        return self
    def from_raw_to_json(self,data:bytes):
        object_type = int(data[:4].hex(),16)
        hash = data[4:36].hex()
        nonce = int(data[36:44].hex(),16)
        bits = int(data[44:52].hex(),16)
        timestamp = int(data[52:60].hex(),16)
        prev_hash = data[60:92].hex()
        version = int(data[92:96].hex(),16)
        merkle_root = data[96:128].hex()
        txs_count = int(data[128:132].hex(),16)
        txs = []
        offset = 132
        for i in range(txs_count):
            tx_data = b""
            object_type = data[offset:offset+4].hex()
            if object_type!="00000001":
                print("Object type in 'block.txs' not allowed",object_type)
            tx_type = data[offset+4:offset+6].hex()
            tx_version = data[offset+6:offset+8].hex()
            tx_timestamp = int(data[offset+8:offset+16].hex(),16)
            tx_data += data[offset:offset + 20]
            if tx_type=="0000":  # HANDLING P2PKH TRANSACTION
                inputs_n = int(data[offset+16:offset+18].hex(),16)
                outputs_n = int(data[offset+18:offset+20].hex(),16)
                offset += 20
                tx_data += data[offset:offset+inputs_n*137]
                offset += inputs_n*137
                tx_data += data[offset:offset+outputs_n*46]
                offset += outputs_n*46
            elif tx_type=="0001":  # HANDLING P2PKH COINBASE TRANSACTION
                outputs_n = int(data[offset+18:offset+20].hex(),16)
                offset += 20
                input_unlock_len = int(data[offset+32+2:offset+32+2+2].hex(),16)
                tx_data += data[offset:offset+36+input_unlock_len]
                offset += 36+input_unlock_len
                tx_data += data[offset:offset+outputs_n*46]
                offset += outputs_n*46
            txs.append(tx_data.hex())



        self.json_data = {
            "object_type":object_type,
            "hash":hash,
            "nonce":nonce,
            "bits":bits,
            "timestamp":timestamp,
            "prev_hash":prev_hash,
            "version":version,
            "merkle_root":merkle_root,
            "txs_count":txs_count,
            "txs":txs
        }
        return self.json_data
    def to_db(self,db_name="gfp_db"):
        b_hash = self.hash.hex()
        data = self.to_raw().hex()
        insert_template = "INSERT INTO `"+db_name+"`.raw_blocks(hash,data) VALUES (X'{}',X'{}')".format(b_hash,data)
        db_insert(insert_template)

