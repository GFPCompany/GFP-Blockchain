import datetime
import json
import sys
import time

import pymysql

from db.db_lib import db_insert
from libs.gfp_library_0 import sha256
from objects.keys import GFP_PrivateKey, GFP_PublicKey

sys.path.append("../libs/")
sys.path.append("libs")
sys.path.append("../")

class GFP_Transaction_P2PKH:

    def __init__(self):
        self.object_type = b"\x00\x00\x00\x01"
        self.tx_type = b"\x00\x00"
        self.tx_version = b"\x00\x00"

        self.timestamp = 0

        self.raw_data = b""
        self.json_data = {}

    def create(self,inputs,outputs,gfp_private_key,required_txs):
        gfp_private_key = GFP_PrivateKey().from_GFP(gfp_private_key)
        gfp_public_key = GFP_PublicKey().generate(gfp_private_key)

        self.timestamp = int(time.mktime(datetime.datetime.now().timetuple()))

        self.raw_data += self.object_type
        self.raw_data += self.tx_type
        self.raw_data += self.tx_version
        self.raw_data += self.timestamp.to_bytes(8,"big")
        self.raw_data += int.to_bytes(len(inputs),2,"big")
        self.raw_data += int.to_bytes(len(outputs),2,"big")

        self.json_data["timestamp"] = self.timestamp
        self.json_data["inputs"] = inputs
        self.json_data["outputs"] = outputs

        for i in inputs:
            input_index = inputs.index(i)
            if i["txid"] not in [j["txid"] for j in required_txs]:
                print("CANT FIND TRANSACTION '"+i["txid"]+"' IN REQUIRED TRANSACTIONS")
                return False

            suitable_tx = [j for j in required_txs if j["txid"] == i["txid"]][0]
            suitable_output = suitable_tx["outputs"][i["vout"]]
            if suitable_output["lock"] != gfp_public_key.to_GFP_P2PKH().hex():
                print("OUTPUT OF TRANSACTION '"+i["txid"]+"' NOT LOCKED BY YOUR KEY '"+gfp_public_key.to_GFP_P2PKH().hex()+"'")
                return False

            self.raw_data += bytes.fromhex(i["txid"])
            self.raw_data += int.to_bytes(i["vout"],2,"big")

            output_instance = b"\x00\x00\x00\x01"
            output_instance += b"\x00\x00"
            output_instance += b"\x00\x00"
            output_instance += suitable_tx["timestamp"].to_bytes(8,"big")
            output_instance += len(suitable_tx["inputs"]).to_bytes(2,"big")
            output_instance += len(suitable_tx["outputs"]).to_bytes(2,"big")
            for input in suitable_tx["inputs"]:
                output_instance += bytes.fromhex(input["txid"])
                output_instance += int.to_bytes(input["vout"],2,"big")
                output_instance += bytes.fromhex(input["unlock"])
            output_instance += bytes.fromhex(suitable_output["lock"])
            output_instance += suitable_output["amount"].to_bytes(8,"big")

            sig = gfp_private_key.sign(output_instance)

            self.raw_data += sig
            self.raw_data += gfp_public_key.to_GFP()

            self.json_data["inputs"][input_index]["unlock"] = sig.hex()+gfp_public_key.to_GFP().hex()
        for i in outputs:
            self.raw_data += bytes.fromhex(i["lock"])
            self.raw_data += i["amount"].to_bytes(8,"big")
        return [self.raw_data,self.json_data]
    def verify(self,tx:dict,required_tx:list):
        outputs_flags = []
        for i in tx["inputs"]:
            suitable_tx = [j for j in required_tx if j["txid"] == i["txid"]][0]
            suitable_output = suitable_tx["outputs"][i["vout"]]
            lock = suitable_output["lock"]
            sig = bytes.fromhex(i["unlock"][:128])
            public_key = GFP_PublicKey().from_GFP(bytes.fromhex(i["unlock"][128:]))

            output_instance = b"\x00\x00\x00\x01"
            output_instance += b"\x00\x00"
            output_instance += b"\x00\x00"
            output_instance += suitable_tx["timestamp"].to_bytes(8, "big")
            output_instance += len(suitable_tx["inputs"]).to_bytes(2, "big")
            output_instance += len(suitable_tx["outputs"]).to_bytes(2, "big")
            for input in suitable_tx["inputs"]:
                output_instance += bytes.fromhex(input["txid"])
                output_instance += int.to_bytes(input["vout"], 2, "big")
                output_instance += bytes.fromhex(input["unlock"])
            output_instance += bytes.fromhex(suitable_output["lock"])
            output_instance += suitable_output["amount"].to_bytes(8, "big")

            data = output_instance
            outputs_flags.append(public_key.verify(data,sig))
        if len(outputs_flags) != len(tx["inputs"]):
            return False
        return True
    def raw_to_json(self,tx):
        data = {
            "object_type":int(tx[0:4].hex(),16),
            "tx_type":int(tx[4:6].hex(),16),
            "tx_version":int(tx[6:8].hex(),16),
            "timestamp":int.from_bytes(tx[8:16],"big"),
            "inputs":[],
            "outputs":[]
        }
        offset = 16
        inputs_n = int.from_bytes(tx[offset:offset+2],"big")
        outputs_n = int.from_bytes(tx[offset+2:offset+4],"big")
        offset += 4
        for i in range(inputs_n):
            data["inputs"].append({
                "txid":tx[offset:offset+32].hex(),
                "vout":int.from_bytes(tx[offset+32:offset+34],"big"),
                "unlock":tx[offset+34:offset+137].hex()
            })
            offset += 137
        for i in range(outputs_n):
            data["outputs"].append({
                "lock":tx[offset:offset+38].hex(),
                "amount":int.from_bytes(tx[offset+38:offset+46],"big")
            })
            offset += 46
        return data
    def raw_to_db(self,tx):
        txid = sha256(bytes.fromhex(sha256(tx)))
        data = {
            "object_type":tx[0:4].hex(),
            "tx_type":tx[4:6].hex(),
            "tx_version":tx[6:8].hex(),
            "timestamp":int.from_bytes(tx[8:16],"big"),
            "inputs_n":int.from_bytes(tx[16:18],"big"),
            "outputs_n":int.from_bytes(tx[18:20],"big"),
            "inputs":tx[20:20+int.from_bytes(tx[16:18],"big")*137].hex(),
            "outputs":tx[20+int.from_bytes(tx[16:18],"big")*137:20+int.from_bytes(tx[16:18],"big")*137+int.from_bytes(tx[18:20],"big")*46].hex()
        }
        insert_template = "INSERT INTO transactions (txid,tx_type,tx_version,timestamp,inputs_n,outputs_n,inputs,outputs) VALUES "
        insert_template += "('{}','{}','{}','{}','{}','{}','{}','{}')".format(
            txid,
            data["tx_type"],
            data["tx_version"],
            data["timestamp"],
            data["inputs_n"],
            data["outputs_n"],
            data["inputs"],
            data["outputs"]
        )
        try:
            db_insert(insert_template)
        except pymysql.err.IntegrityError as e:
            if e.args[0] == 1062:
                pass
            else:
                raise e
def build_tx_io(utxo,outputs,fee,address):
    out = {
        "inputs":[],
        "outputs":outputs
    }
    outputs_sum = 0

    for i in outputs:
        outputs_sum += i["amount"]

    amount = outputs_sum

    #utxo = [{"txid":i["txid"],"outputs":json.loads(i["outputs"])} for i in utxo]

    full_utxo_balance = 0
    for i in utxo:
        full_utxo_balance += i["outputs"][0]["amount"]
    if full_utxo_balance < amount:
        return False

    utxo = sorted(utxo, key=lambda x: x["outputs"][0]["amount"], reverse=False)

    current_inputs_sum = 0
    inputs = []
    for i in range(len(utxo)):
        if current_inputs_sum < amount + fee:
            print(utxo[i])
            inputs.append(utxo[i])
            current_inputs_sum += utxo[i]["outputs"][0]["amount"]
        else:
            break

    formed_inputs = []
    for i in range(len(inputs)):
        for j in inputs[i]["outputs"]:
            if j["lock"] == address:
                formed_inputs.append({"txid":inputs[i]["txid"],"vout":j["vout"]})
                break
    out["inputs"] = formed_inputs

    change = current_inputs_sum - amount - fee
    if change!=0 and change > 0:
        out["outputs"].append({
            "lock":address,
            "amount":change
        })

    return out

class GFP_Transaction_coinbase:
    def __init__(self):
        self.object_type = b"\x00\x00\x00\x01"
        self.tx_type = b"\x00\x01"
        self.tx_version = b"\x00\x00"

        self.timestamp = 0

        self.inputs = [{
            "txid": "00" * 32,
            "vout": 0xffff
        }]
        self.outputs = []

        self.raw_data = b""
        self.json_data = {}
    def create(self,outputs:list,data:bytes):
        self.timestamp = int(time.mktime(datetime.datetime.now().timetuple()))
        self.json_data["timestamp"] = self.timestamp
        self.json_data["outputs"] = outputs
        self.inputs[0]["unlock"] = data.hex()

        self.raw_data += self.object_type
        self.raw_data += self.tx_type
        self.raw_data += self.tx_version

        self.json_data["object_type"] = self.object_type.hex()
        self.json_data["tx_type"] = self.tx_type.hex()
        self.json_data["tx_version"] = self.tx_version.hex()

        self.raw_data += self.timestamp.to_bytes(8,"big")
        self.raw_data += len(self.inputs).to_bytes(2,"big")
        self.raw_data += len(outputs).to_bytes(2,"big")
        for i in self.inputs:
            self.raw_data += bytes.fromhex(i["txid"])
            self.raw_data += i["vout"].to_bytes(2,"big")
            self.raw_data += len(bytes.fromhex(i["unlock"])).to_bytes(2,"big")
            self.raw_data += bytes.fromhex(i["unlock"])

            self.json_data["inputs"] = []
            self.json_data["inputs"].append({
                "txid":i["txid"],
                "vout":i["vout"],
                "unlock":i["unlock"]
            })
            break

        for i in outputs:
            self.raw_data += bytes.fromhex(i["lock"])
            self.raw_data += i["amount"].to_bytes(8,"big")
        return [self.raw_data,self.json_data]
    def raw_to_json(self,tx):
        data = {
            "object_type":int(tx[0:4].hex(),16),
            "tx_type":int(tx[4:6].hex(),16),
            "tx_version":int(tx[6:8].hex(),16),
            "timestamp":int.from_bytes(tx[8:16],"big"),
            "inputs":[],
            "outputs":[]
        }
        offset = 16
        inputs_n = int.from_bytes(tx[offset:offset+2],"big")
        outputs_n = int.from_bytes(tx[offset+2:offset+4],"big")
        offset += 4


        for i in range(inputs_n):
            data["inputs"].append({
                "txid":tx[offset:offset+32].hex(),
                "vout":int.from_bytes(tx[offset+32:offset+34],"big"),
                "unlock":tx[offset+36:offset+36+int(tx[offset+34:offset+36].hex(),16)].hex()
            })
            offset += 32+2+2+int(tx[offset+34:offset+36].hex(),16)
        for i in range(outputs_n):
            data["outputs"].append({
                "lock":tx[offset:offset+38].hex(),
                "amount":int(tx[offset+38:offset+46].hex(),16)
            })
            offset += 46
        data["txid"] = sha256(bytes.fromhex(sha256(tx)))
        return data
    def raw_to_db(self,tx):
        txid = sha256(bytes.fromhex(sha256(tx)))
        data = {
            "object_type":tx[0:4].hex(),
            "tx_type":tx[4:6].hex(),
            "tx_version":tx[6:8].hex(),
            "timestamp":int.from_bytes(tx[8:16],"big"),
            "inputs_n":int.from_bytes(tx[16:18],"big"),
            "outputs_n":int.from_bytes(tx[18:20],"big"),
            "inputs":"",
            "outputs":""
        }

        offset = 20
        for i in range(data["inputs_n"]):
            data["inputs"] += tx[offset:offset+32+2+2+int(tx[offset+34:offset+36].hex(),16)].hex()
            offset += 32+2+2+int(tx[offset+34:offset+36].hex(),16)
        for i in range(data["outputs_n"]):
            data["outputs"] += tx[offset:offset+38].hex()
            data["outputs"] += tx[offset+38:offset+46].hex()
            offset += 46
        insert_template = "INSERT INTO transactions (txid,tx_type,tx_version,timestamp,inputs_n,outputs_n,inputs,outputs) VALUES "
        insert_template += "('{}','{}','{}','{}','{}','{}','{}','{}')".format(
            txid,
            data["tx_type"],
            data["tx_version"],
            data["timestamp"],
            data["inputs_n"],
            data["outputs_n"],
            data["inputs"],
            data["outputs"]
        )
        try:
            db_insert(insert_template)
        except pymysql.err.IntegrityError as e:
            if e.args[0] == 1062:
                pass
            else:
                raise e
def test_p2pkh():
    k = GFP_PrivateKey()
    k.generate()


    a = {
        "txid": sha256(1),
        "timestamp": 0x012034,
        "inputs": [
            {
                "txid": sha256(24),
                "vout": 0,
                "unlock": "22" * 103
            }
        ],
        "outputs": [
            {
                "lock": GFP_PublicKey().generate(k).to_GFP_P2PKH().hex(),
                "amount": 0x123456
            }
        ]
    }
    b = {
        "txid": sha256(12),
        "timestamp": 0x012034,
        "inputs": [
            {
                "txid": sha256(1),
                "vout": 0,
            }
        ],
        "outputs": [
            {
                "lock": GFP_PublicKey().generate(k).to_GFP_P2PKH().hex(),
                "amount": 0x10
            }
        ]
    }
    t = GFP_Transaction_P2PKH()
    d = t.create(b["inputs"], b["outputs"], k.to_GFP(), [a])
    print(len(d[0]))
    print(d[0].hex())
    print(json.dumps(d[1], indent=4))
    print(len(d[1]["inputs"][0]["unlock"]))
    print(t.verify(d[1], [a]))
    print(json.dumps(GFP_Transaction_P2PKH().raw_to_json(d[0]), indent=4))

#test_p2pkh()

def test():
    a = GFP_Transaction_coinbase()
    d = a.create([{"lock": "22" * 38, "amount": 0x1}], b"hello world, GFP Blockchain is now online!")
    print(json.dumps(d[1], indent=4))
    print(len(d[0]))
    for i in bytes.fromhex(d[1]["inputs"][0]["unlock"]):
        print(chr(i), end="")
#test()