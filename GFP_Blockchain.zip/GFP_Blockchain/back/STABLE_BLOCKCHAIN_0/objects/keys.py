import base58
import ecdsa
from libs.beauti_cli import *
from libs.gfp_library_0 import *

CONFIG = {
    "PRIVATE_KEY_PREFIX" : "1567", # hex
    "PRIVATE_KEY_CHECKSUM_LENGTH" : 4,  # in bytes
    "PRIVATE_KEY_CHECKSUM_ALGO" : "md5",

    "PUBLIC_KEY_PREFIX":"1244", # hex
    "PUBLIC_KEY_CHECKSUM_LENGTH" : 4,  # in bytes
    "PUBLIC_KEY_CHECKSUM_ALGO" : "md5",

    "PUBLIC_KEY_P2PKH_PREFIX":"2500",
}

ERRORS = {
    0x10 : "Private key not generated",
    0x11 : "Private key checksum algo not supported",
    0x12 : "Raw private key not valid",
    0x13 : "Private key prefix not valid",
    0x14 : "Private key checksum not valid",


    0xf0 : "Public key not generated",
    0xf1 : "Public key checksum algo not supported",
    0xf2 : "Raw public key not valid",
    0xf3 : "Public key prefix not valid",
    0xf4 : "Public key checksum not valid",
}

class GFP_PrivateKey:

    def __init__(self):
        self.key = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)
        self.FLAG_GENERATED = False

    def generate(self):
        self.key = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)
        self.FLAG_GENERATED = True
        return self
    def to_raw(self):
        if self.FLAG_GENERATED == False:
            err_code = 0x10
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
        return self.key.to_string()
    def to_GFP(self):
        prefix = bytes.fromhex(CONFIG["PRIVATE_KEY_PREFIX"])
        key = self.to_raw()

        if CONFIG["PRIVATE_KEY_CHECKSUM_ALGO"] == "md5":
            checksum = md5(key)[:CONFIG["PRIVATE_KEY_CHECKSUM_LENGTH"]*2]
        elif CONFIG["PRIVATE_KEY_CHECKSUM_ALGO"] == "sha256":
            checksum = sha256(key)[:CONFIG["PRIVATE_KEY_CHECKSUM_LENGTH"]*2]
        else:
            err_code = 0x11
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
        checksum = bytes.fromhex(checksum)

        total = prefix + key + checksum
        total = base58.b58encode(total)

        return total
    def from_raw(self,raw):
        try:
            self.key = ecdsa.SigningKey.from_string(raw, curve=ecdsa.SECP256k1)
            self.FLAG_GENERATED = True
            return 1
        except:
            err_code = 0x12
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
    def from_GFP(self,key):
        key = base58.b58decode(key).hex()
        prefix = key[:len(CONFIG["PRIVATE_KEY_PREFIX"])]
        if prefix != CONFIG["PRIVATE_KEY_PREFIX"]:
            err_code = 0x13
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
        raw_key = key[len(CONFIG["PRIVATE_KEY_PREFIX"]):-CONFIG["PRIVATE_KEY_CHECKSUM_LENGTH"]*2]

        checksum = key[-CONFIG["PRIVATE_KEY_CHECKSUM_LENGTH"]*2:]

        if CONFIG["PRIVATE_KEY_CHECKSUM_ALGO"] == "md5":
            if checksum != md5(bytes.fromhex(raw_key))[:CONFIG["PRIVATE_KEY_CHECKSUM_LENGTH"]*2]:
                err_code = 0x14
                printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
                exit(1)
        elif CONFIG["PRIVATE_KEY_CHECKSUM_ALGO"] == "sha256":
            if checksum != sha256(bytes.fromhex(raw_key))[:CONFIG["PRIVATE_KEY_CHECKSUM_LENGTH"]*2]:
                err_code = 0x14
                printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
                exit(1)
        else:
            err_code = 0x11
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
        self.from_raw(bytes.fromhex(raw_key))
        return self
    def sign(self,data:bytes):
        if self.FLAG_GENERATED == False:
            err_code = 0x10
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
        return self.key.sign(data,hashfunc=hashlib.sha256)

class GFP_PublicKey:
    def __init__(self):
        self.key = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1).get_verifying_key()
        self.FLAG_GENERATED = False
    def generate(self,private_key):
        if type(private_key) == str:
            private_key = bytes.fromhex(private_key)
            self.key = ecdsa.SigningKey.from_string(private_key, curve=ecdsa.SECP256k1).get_verifying_key()
        elif type(private_key) == bytes:
            self.key = ecdsa.SigningKey.from_string(private_key, curve=ecdsa.SECP256k1).get_verifying_key()
        elif type(private_key) == GFP_PrivateKey:
            self.generate(private_key.to_raw())
        self.FLAG_GENERATED = True
        return self
    def to_GFP(self,base58_enc=False):
        if self.FLAG_GENERATED == False:
            err_code = 0xf0
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
        key = bytes.fromhex(CONFIG["PUBLIC_KEY_PREFIX"]) + self.key.to_string(encoding="compressed")
        key += bytes.fromhex(md5(key))[:CONFIG["PUBLIC_KEY_CHECKSUM_LENGTH"]]
        if base58_enc == True:
            key = base58.b58encode(key)
        return key
    def to_GFP_P2PKH(self,base58_enc=False):
        if self.FLAG_GENERATED == False:
            err_code = 0xf0
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
        key = bytes.fromhex(CONFIG["PUBLIC_KEY_P2PKH_PREFIX"]) + bytes.fromhex(sha256(self.key.to_string(encoding="compressed")))
        key += bytes.fromhex(md5(key))[:CONFIG["PUBLIC_KEY_CHECKSUM_LENGTH"]]
        if base58_enc == True:
            key = base58.b58encode(key)
        return key
    def to_raw(self):
        if self.FLAG_GENERATED == False:
            err_code = 0xf0
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
        return self.key.to_string()
    def from_raw(self,raw):
        try:
            self.key = ecdsa.VerifyingKey.from_string(raw, curve=ecdsa.SECP256k1)
            self.FLAG_GENERATED = True
            return 1
        except:
            err_code = 0xf2
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
    def from_GFP(self,key):
        try:

            self.key = ecdsa.VerifyingKey.from_string(key[2:-4], curve=ecdsa.SECP256k1)
            self.FLAG_GENERATED = True
            return self
        except:
            err_code = 0x12
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
    def verify(self,data:bytes,signature:bytes):
        if self.FLAG_GENERATED == False:
            err_code = 0x10
            printError(f"{str(hex(err_code))}:"+ERRORS[err_code])
            exit(1)
        try:
            return self.key.verify(signature, data, hashfunc=hashlib.sha256)
        except Exception as e:
            if str(e)== "Signature verification failed":
                return False
            else:
                raise e


import ecdsa

Private_key = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)


Public_key = Private_key.get_verifying_key()