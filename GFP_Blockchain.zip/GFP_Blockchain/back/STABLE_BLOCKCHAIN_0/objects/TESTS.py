import json

from db.db_lib import db_select, db_insert
from libs.beauti_cli import printOk
from libs.gfp_library_0 import *

import base58

from objects.block import Block
from objects.keys import GFP_PrivateKey, GFP_PublicKey
from objects.transaction import GFP_Transaction_P2PKH, GFP_Transaction_coinbase
from tools.calculate_balance import GetTransactionFromChain, GetBalance


def test_p2pkh_transaction_in_block():


    coinbase_tx = GFP_Transaction_coinbase().create([{"lock": base58.b58decode("6UTXnE3vVHAHq7iCdo8Gke3BoYWUvSDhnuWkHEXnQtvuqLmidj6g").hex(), "amount": 200}], b"hello world, GFP Blockchain is now online!")
    coinbase_block = Block()

    print("COINBASE TXID: ", sha256(bytes.fromhex(sha256(coinbase_tx[0]))))
    COINBASE_TXID = sha256(bytes.fromhex(sha256(coinbase_tx[0])))
    coinbase_block.create(b"\x00" * 32, 200, [coinbase_tx[0]])
    coinbase_block.mine()
    coinbase_block.to_db()

    block = db_select("SELECT data FROM raw_blocks")
    block = [i["data"] for i in block][0]
    if COINBASE_TXID in block.hex():
        printOk("COINBASE TX FOUND",True)

    tx = GetTransactionFromChain(COINBASE_TXID)
    print(tx)
    k = GFP_PrivateKey().from_GFP(b"4AfKQVgFWyAGBwD7aMHBb5gTwxUycg7taBy6c1pDdbLzGrEgCkJf")

    _new_tx = {
        "inputs": [
            {
                "txid":COINBASE_TXID,
                "vout":0,
            }
        ],
        "outputs": [
            {
                "lock": "11" * 38,
                "amount": 99
            }
        ]
    }
    t = GFP_Transaction_P2PKH()
    d = t.create(_new_tx["inputs"], _new_tx["outputs"], k.to_GFP(), [tx])

    b = Block()
    b.create(bytes.fromhex(sha256(1)), 0x123456, [d[0]])
    b.mine()
    b.to_db()
# CLEARING CHAIN
def a():
    db_insert("DELETE FROM raw_blocks")
    db_insert("ALTER TABLE raw_blocks AUTO_INCREMENT = 0")
    # print(GetBalance("6UTXnE3vVHAHq7iCdo8Gke3BoYWUvSDhnuWkHEXnQtvuqLmidj6g"))
    test_p2pkh_transaction_in_block()
    print(GetBalance("6UTXnE3vVHAHq7iCdo8Gke3BoYWUvSDhnuWkHEXnQtvuqLmidj6g"))


def test_block():
    k = GFP_PrivateKey()
    k.from_GFP("4AfKQVgFWyAGBwD7aMHBb5gTwxUycg7taBy6c1pDdbLzGrEgCkJf")
    a = {
        "txid": sha256(12),
        "timestamp": 0x012034,
        "inputs": [
            {
                "txid": sha256(24),
                "vout": 0,
                "unlock": "22" * 103
            }
        ],
        "outputs": [
            {
                "lock": base58.b58decode("6UTXnE3vVHAHq7iCdo8Gke3BoYWUvSDhnuWkHEXnQtvuqLmidj6g").hex(),
                "amount": 0x123456
            }
        ]
    }
    b = {
        "txid": sha256(126),
        "timestamp": 0x012034,
        "inputs": [
            {
                "txid": sha256(12),
                "vout": 0,
            }
        ],
        "outputs": [
            {
                "lock": "01" * 38,
                "amount": 0x10
            }
        ]
    }
    t = GFP_Transaction_P2PKH()
    d = t.create(b["inputs"], b["outputs"], k.to_GFP(), [a])

    a = Block()
    a.create(b"\x05" * 32, 0x123456, [d[0]])
    a.gen_merkle_root()

    a.mine()
    print(json.dumps(a.from_raw_to_json(a.to_raw()), indent=4))
    print(a.from_raw_to_json(a.to_raw())["txs"][0])
    print(d[0].hex())
    a.to_db()
test_block()
def create_coinbase_block():
    a = "6UTXnE3vVHAHq7iCdo8Gke3BoYWUvSDhnuWkHEXnQtvuqLmidj6g"
    a = base58.b58decode(a).hex()
    coinbase_tx = GFP_Transaction_coinbase()
    d=coinbase_tx.create([{"lock": a, "amount": 200}], b"hello world, GFP Blockchain is now online!")

    last_hash = "SELECT hash FROM raw_blocks WHERE id=(SELECT MAX(id) FROM raw_blocks)"
    last_hash = db_select(last_hash)
    if len(last_hash) == 0:
        last_hash = b"\x00" * 32
    else:
        last_hash = last_hash[0]["hash"]

    a = Block()
    a.create(last_hash, 0x123456, [d[0]])
    a.mine()
    a.to_db()
#create_coinbase_block
coinbase_tx = GFP_Transaction_coinbase().create([{"lock": base58.b58decode("6UTXnE3vVHAHq7iCdo8Gke3BoYWUvSDhnuWkHEXnQtvuqLmidj6g").hex(), "amount": 200}], b"hello world, GFP Blockchain is now online!")
print(coinbase_tx[0].hex())