from objects.keys import *
from objects.block import *
from objects.transaction import *

# CREATEING GENESIS BLOCK
sk0 = GFP_PrivateKey().generate()
pk0 = GFP_PublicKey().generate(sk0)
cbtx0 = GFP_Transaction_coinbase().create([{"lock": pk0.to_GFP_P2PKH().hex(), "amount": 0x10}], b"hello world, GFP Blockchain is now online!")[0]
cbtx0_txid = sha256(bytes.fromhex(sha256(cbtx0)))
cbtx0_json = GFP_Transaction_coinbase().raw_to_json(cbtx0)
cbtx0_json["txid"] = cbtx0_txid

b0 = Block()
b0.create(b"\x00"*32,0x10000,[cbtx0])
b0.mine()
br0 = b0.to_raw()
# END OF GENESIS BLOCK CREATION

# CREATING FIRST BLOCK
sk1 = GFP_PrivateKey().generate()
pk1 = GFP_PublicKey().generate(sk1)
cbtx1 = GFP_Transaction_coinbase().create([{"lock": pk1.to_GFP_P2PKH().hex(), "amount": 0x11}], b"FIRST BLOCK")[0]
cbtx1_txid = sha256(bytes.fromhex(sha256(cbtx1)))
p2pkhtx1 = GFP_Transaction_P2PKH().create([{"txid": cbtx0_txid, "vout": 0}], [
    {"lock": pk1.to_GFP_P2PKH().hex(), "amount": 0x10}],sk0.to_GFP(),[cbtx0_json])

b1 = Block()
b1.create(br0[4:36],0x10000,[cbtx1,p2pkhtx1[0]])
b1.mine()
br1 = b1.to_raw()
#print(br1)
# END OF FIRST BLOCK CREATION

UTXO = []

"""
[
    {
        "txid":"0000000000000000000000000000000000000000000000000000000000000000",
        "outputs":
            [
                {
                    "vout":0,
                    "lock":"0000000000000000000000000000000000000000000000000000000000000000",
                    "amount":0x10
                }
            ]
    }
]
"""
def utxo_issue(block,UTXO):
    # TODO FORMING DATA
    block = Block().from_raw_to_json(block)
    txs = block["txs"]
    transactions = []
    for i in txs:
        i = bytes.fromhex(i)
        tx_type = i[4:6]
        if int(tx_type.hex(),16) == 0x0000: # P2PKH
            tx = GFP_Transaction_P2PKH().raw_to_json(i)
            tx["txid"] = sha256(bytes.fromhex(sha256(i)))
            transactions.append(tx)
        elif int(tx_type.hex(),16) == 0x0001: # COINBASE
            tx = GFP_Transaction_coinbase().raw_to_json(i)
            tx["txid"] = sha256(bytes.fromhex(sha256(i)))
            transactions.append(tx)
    # TODO CHECKING OLDS UTXO

    for i in range(len(UTXO)):
        utxo_txid = UTXO[i]["txid"]
        utxo_outputs = UTXO[i]["outputs"]

        for tx in transactions:
            if utxo_txid in [k["txid"] for k in tx["inputs"]]:
                used_vout = [k["vout"] for k in tx["inputs"] if k["txid"] == utxo_txid][0]
                #print("FOUND USED UTXO",utxo_outputs[used_vout])
                utxo_outputs.pop(used_vout)
        if len(utxo_outputs) == 0:
            UTXO.pop(i)


    # TODO ADDING NEW UTXO
    for i in transactions:
        to_utxo = {}
        to_utxo["txid"] = i["txid"]
        to_utxo["outputs"] = i["outputs"]
        UTXO.append(to_utxo)
    return UTXO